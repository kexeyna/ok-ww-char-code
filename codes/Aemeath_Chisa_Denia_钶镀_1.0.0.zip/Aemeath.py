import time

from src.char.BaseChar import BaseChar, SwitchPriority


class Aemeath(BaseChar):
    LIBERATION_COOLDOWN = 25
    LIBERATION_FORCE_DURATION = 30
    LIB2_PREPARE_WINDOW = 8
    INTRO_LIBERATION_DELAY = 14

    PERFORM_WINDOW = 2.0
    PERFORM_WAIT_WINDOW = 4.5
    POST_LIB_CONCERTO_WAIT = 1.5
    HEAVY_HOLD_MIN = 0.6
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.should_wait = False
        self.last_liber = -1
        self.last_enhance_e = -1
        self.intro_liberation_time = -1
        self.pending_lib2 = False
        self.last_lib_was_lib2 = False

    def lib2_cooldown_anchor(self):
        if self.last_liber >= 0:
            return self.last_liber
        combat_start = getattr(self.task, 'combat_start', -1)
        return combat_start if combat_start > 0 else -1

    def lib2_cooldown_left(self):
        anchor = self.lib2_cooldown_anchor()
        if anchor < 0:
            return 0
        elapsed = self.time_elapsed_accounting_for_freeze(anchor)
        return max(0, self.LIBERATION_COOLDOWN - elapsed)

    def liberation_cooldown_left(self):
        if self.last_liber < 0:
            return 0
        elapsed = self.time_elapsed_accounting_for_freeze(self.last_liber)
        return max(0, self.LIBERATION_COOLDOWN - elapsed)

    def lib1_unlock_anchor(self):
        if self.last_liber >= 0:
            return self.last_liber
        return getattr(self.task, 'combat_start', -1)

    def record_intro_liberation(self):
        self.intro_liberation_time = time.time()

    def intro_lib1_ready(self):
        return self.intro_liberation_time >= 0 and (
                self.time_elapsed_accounting_for_freeze(self.intro_liberation_time)
                <= self.INTRO_LIBERATION_DELAY)

    def lib1_unlocked(self):
        if self.intro_lib1_ready():
            return True
        anchor = self.lib1_unlock_anchor()
        return anchor >= 0 and (
                self.time_elapsed_accounting_for_freeze(anchor) >= self.LIBERATION_FORCE_DURATION)

    def can_cast_lib1(self):

        return self.liberation_available() and not self.lib2_available()

    def can_cast_liberation(self):
        return self.can_cast_lib1()

    def lib2_available(self):
        return bool(self.task.find_one('aemeath_lib2', threshold=0.7))

    def preparing_lib2(self):
        return self.lib2_cooldown_anchor() >= 0 and (
                self.lib2_cooldown_left() < self.LIB2_PREPARE_WINDOW)

    def should_wait_for_lib2(self):
        return self.pending_lib2 or self.preparing_lib2()

    def should_wait_for_enhance_e(self):
        return self.time_elapsed_accounting_for_freeze(self.last_enhance_e) > 12

    def record_enhance_e(self):
        self.last_enhance_e = time.time()

    def record_heavy_liberation(self):
        self.pending_lib2 = True

    def record_liberation(self, is_lib2):
        self.last_lib_was_lib2 = is_lib2
        if is_lib2:
            self.pending_lib2 = False
            self.last_liber = time.time()
            self.last_enhance_e = self.last_liber
        else:
            self.intro_liberation_time = -1

    def do_perform(self):
        self.should_wait = False
        if self.has_intro:
            self.record_intro_liberation()
            self.continues_normal_attack(0.8)
        self.perform_everything()
        self.switch_next_char()

    def lib(self):
        is_lib2 = self.lib2_available()
        if not is_lib2 and not self.can_cast_lib1():
            return False
        if not self.click_liberation(wait_if_cd_ready=0):
            return False
        self.record_liberation(is_lib2)
        self.f_break()
        return True

    def perform_everything(self):
        start = time.time()
        self.should_wait = self.should_wait_for_lib2() or self.should_wait_for_enhance_e()
        if not self.should_wait:
            self.should_wait = self.has_intro and self.liberation_cooldown_left() < 12
        while self.time_elapsed_accounting_for_freeze(start) < self.PERFORM_WINDOW or (
                self.should_wait and self.time_elapsed_accounting_for_freeze(start) < self.PERFORM_WAIT_WINDOW):
            self.cycle_start()
            if self.handle_heavy():
                self.f_break()
                start = time.time()
                self.should_wait = self.should_wait_for_lib2()
                self.task.next_frame()
                continue
            if self.lib():
                start = time.time()
                self.should_wait = self.should_wait_for_lib2()
                if self.last_lib_was_lib2:
                    t = time.time()
                    while self.time_elapsed_accounting_for_freeze(t) < self.POST_LIB_CONCERTO_WAIT and not self.is_con_full():
                        self.click(after_sleep=0.1)
                    return self.switch_next_char()
            elif self.enhance_e_available():
                if self.click_resonance(has_animation=True, send_click=True, animation_min_duration=0.5,
                                        time_out=1.5)[0]:
                    self.record_enhance_e()
                    self.click_echo(time_out=0)
                    self.f_break()
                    self.continues_normal_attack(0.9)
                    self.task.next_frame()
                if self.has_long_action():
                    start = time.time()
                else:
                    self.click(after_sleep=0.01)
                    return
            else:
                self.click()
            self.cycle_sleep()

    def lib_cd_eminent(self):
        cd = self.task.get_cd('liberation')
        return self.lib1_unlocked() and (0 < cd < 1.5 or self.liberation_available())

    def enhance_e_available(self):
        return self.task.find_one('aemeath_e1', threshold=0.7) or self.task.find_one('aemeath_e2',
                                                                                     threshold=0.7)

    def heavy_wait_highlight_down(self):
        self.task.mouse_down()
        if self.has_long_action():
            ret = self.task.wait_until(lambda: not self.has_long_action(), time_out=1.2)
        else:
            self.sleep(self.HEAVY_HOLD_MIN, check_combat=False)
            ret = True
        self.task.mouse_up()
        self.sleep(0.01)
        return ret

    def heavy_button_lit(self):
        if self.lib2_available() or self.can_cast_lib1():
            return False
        return bool(self.task.find_one('aemeath_human_heavy', threshold=0.7))

    def handle_heavy(self):
        if not self.has_long_action() and not self.heavy_button_lit():
            return False
        prepares_lib2 = self.preparing_lib2()
        if self.heavy_wait_highlight_down():
            if prepares_lib2:
                self.record_heavy_liberation()
            return True
        return False

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        if has_intro and current_char and current_char.char_name == 'char_denia':
            return SwitchPriority.MUST
        if self.should_wait_for_lib2():
            return SwitchPriority.MUST
        return super().get_switch_priority(current_char, has_intro, target_low_con)
    def on_combat_end(self, chars):
        self.switch_other_char()
