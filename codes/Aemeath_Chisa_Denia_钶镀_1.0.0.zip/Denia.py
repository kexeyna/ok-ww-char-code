import time

from src.char.BaseChar import BaseChar, SwitchPriority


class Denia(BaseChar):

    SEG2_TIMEOUT = 4.0
    SEG1_LIB_WAIT = 3.0
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.pending_e2 = False

    def reset_state(self):
        super().reset_state()
        self.pending_e2 = False

    def do_perform(self):
        self.check_f_on_switch = True
        if self.has_intro:
            self.wait_intro(1.2)
            self.click()
        if self.flying() and not self.liberation_available() and not self.resonance_available():
            self.wait_down()

        if self.pending_e2:

            self.click_resonance(has_animation=True, animation_min_duration=0.3, time_out=1.2)
            self.click_echo(time_out=0)
            start = time.time()
            while self.time_elapsed_accounting_for_freeze(start) < self.SEG2_TIMEOUT and not self.is_con_full():
                if self.liberation_available():
                    self.click_liberation()
                self.click(after_sleep=0.1)
            self.pending_e2 = False
            return self.switch_next_char()

        self.click_resonance(time_out=0.5)
        self.click_echo(time_out=0)
        start = time.time()
        while self.time_elapsed_accounting_for_freeze(start) < self.SEG1_LIB_WAIT and not self.liberation_available():
            self.click(after_sleep=0.1)
        if self.click_liberation():

            if self.click_resonance(has_animation=True, animation_min_duration=0.3, time_out=1.2)[0]:
                self.pending_e2 = True
            else:
                self.continues_normal_attack(1.2)
        else:
            self.continues_normal_attack(1.2)
        return self.switch_next_char()
    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        if self.pending_e2:
            return SwitchPriority.MUST + 1
        if has_intro and current_char and current_char.char_name == 'char_chisa':
            return SwitchPriority.MUST
        if has_intro:
            return SwitchPriority.NO
        elif self.has_buff():
            return SwitchPriority.LOW
        else:
            return super().get_switch_priority(current_char, has_intro, target_low_con)
