from src.char.BaseChar import BaseChar, SwitchPriority, forte_white_color


class Linnai(BaseChar):
    RES_CHECK_THRESHOLD = 0.6
    INTRO_RES_WAIT = 1.0
    AEMEATH_INTRO_RES_WAIT = 1.6

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.last_heavy = 0

    def do_perform(self):
        if self.has_intro and self.check_res():
            self.continues_normal_attack(1.33)
        else:
            self.charge_heavy()
        if self.liberation_available():
            self.click_liberation()
        return self.switch_next_char()

    def charge_heavy(self):
        self.continues_normal_attack(1)
        self.click_echo(time_out=0)
        if not self.is_con_full():
            self.click_liberation()
        if not self.is_mouse_forte_full():
            self.click_resonance()
        self.task.wait_until(self.is_mouse_forte_full, post_action=self.click, time_out=2)
        self.task.mouse_down()
        if self.task.wait_until(lambda: not self.is_mouse_forte_full(), time_out=5):
            self.task.mouse_up()
            self.sleep(0.4)
            self.perform_under_intro()
        else:
            self.task.mouse_up()

    def perform_under_intro(self):
        if not self.wait_for_accelerate_ready():
            self.logger.debug(f'Linnai fails entering accelerate mode!')
            return False
        self.task.wait_until(lambda: self.is_color_full() or self.is_con_full(), post_action=self.click,
                             time_out=1)
        if self.task.wait_until(lambda: not self.is_forte_full(),
                                post_action=self.task.jump, time_out=3):
            if self.task.wait_until(lambda: self.click_resonance()[0],
                                    post_action=self.click, time_out=2):
                self.wait_after_resonance_kick()
                second_kick = False

                def click_second_resonance():
                    nonlocal second_kick
                    if self.is_con_full():
                        return True
                    second_kick = self.click_resonance()[0]
                    return second_kick

                self.task.wait_until(click_second_resonance, post_action=self.click, time_out=3)
                if second_kick:
                    self.wait_after_resonance_kick()
        if not self.is_con_full() and self.click_liberation():
            self.task.wait_until(self.is_con_full, post_action=self.click_with_interval, time_out=1.2)
        return True

    def wait_after_resonance_kick(self):
        self.sleep(0.3)
        self.wait_down()

    def wait_for_accelerate_ready(self):
        if self.check_res():
            return True
        time_out = self.INTRO_RES_WAIT
        if self.has_intro and self.check_outro() in {'char_aemeath'}:
            time_out = self.AEMEATH_INTRO_RES_WAIT
        return self.task.wait_until(self.check_res, post_action=self.click_with_interval, time_out=time_out)

    def get_target_names(self):
        if hasattr(self.task, 'get_target_names'):
            return self.task.get_target_names()
        return 'has_target', 'no_target'

    def find_target_status_in_box(self, box_name):
        try:
            box = self.task.get_box_by_name(box_name)
            return self.task.find_best_match_in_box(box, list(self.get_target_names()),
                                                    threshold=self.RES_CHECK_THRESHOLD)
        except Exception as e:
            self.logger.debug(f'Linnai check res skipped {box_name}: {e}')
            return None

    def check_res(self):
        if not self.task.in_team_and_world():
            return False
        best = self.find_target_status_in_box('target_box_long2')
        if not best:
            best = self.find_target_status_in_box('box_target_enemy_long')
        if not best:
            try:
                best = self.task.find_one('target_box_short', threshold=self.RES_CHECK_THRESHOLD)
            except Exception as e:
                self.logger.debug(f'Linnai check res skipped target_box_short: {e}')
                best = None
        self.logger.debug(f'check res {best}')
        return best

    def is_color_full(self):
        box = self.task.box_of_screen_scaled(5120, 2880, 2846, 2602, 2889, 2690, name='color_full', hcenter=True)
        white_percent = self.task.calculate_color_percentage(forte_white_color, box)
        self.logger.debug(f'forte_color_percent {white_percent}')
        return white_percent > 0.06

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        if current_char is None or self is current_char:
            return super().get_switch_priority(current_char, has_intro, target_low_con)
        nxt = {'Suisui': 'Linnai', 'Linnai': 'Hiyuki', 'Hiyuki': 'Suisui'}.get(current_char.__class__.__name__)
        if nxt:
            return SwitchPriority.MUST if self.__class__.__name__ == nxt else SwitchPriority.NO
        return super().get_switch_priority(current_char, has_intro, target_low_con)
