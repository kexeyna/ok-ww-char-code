import time

from src.Labels import Labels
from src.char.BaseChar import BaseChar, SwitchPriority


class Suisui(BaseChar):
    FILL_ROUTE_TIME = 10.0
    CONCERTO_WAIT = 4.0

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.last_forte3_switch = -1

    @staticmethod
    def _axis_first(task):
        combat = getattr(task, 'combat_start', None)
        if getattr(task, '_wsv_combat', None) != combat:
            task._wsv_combat = combat
            task._wsv_first = True
        return bool(getattr(task, '_wsv_first', True))

    def do_perform(self):
        first = self._axis_first(self.task)
        if self.has_intro:
            self.wait_down()
        if first:
            self.task.wait_until(lambda: bool(self.task.find_one(Labels.suisui_e1)),
                                 post_action=self.click, time_out=self.FILL_ROUTE_TIME)
            self.try_e()
            self.task._wsv_first = False
        self.click_resonance(send_click=False, time_out=0)
        self._fill_to_forte3()
        self.click_echo(time_out=0)
        if self.forte3_available():
            self.click_liberation(wait_if_cd_ready=0)
        self.task.wait_until(self.is_con_full, post_action=self.click_with_interval, time_out=self.CONCERTO_WAIT)
        self.switch_next_char()

    def _fill_to_forte3(self):
        self.task.wait_until(self.forte3_available, post_action=self.click, time_out=self.FILL_ROUTE_TIME)

    def forte3_available(self):
        return bool(self.task.find_one(Labels.suisui_forte3, threshold=0.75))

    def forte2_available(self):
        return bool(self.task.find_one(Labels.suisui_forte2, threshold=0.75))

    def try_e(self):
        if self.task.find_one(Labels.suisui_e1):
            start = time.time()
            while self.task.find_one(Labels.suisui_e1) and self.time_elapsed_accounting_for_freeze(start) < 2:
                self.send_resonance_key()
                self.sleep(0.05)
            return True
        return False

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        if current_char is None or self is current_char:
            return super().get_switch_priority(current_char, has_intro, target_low_con)
        nxt = {'Suisui': 'Linnai', 'Linnai': 'Hiyuki', 'Hiyuki': 'Suisui'}.get(current_char.__class__.__name__)
        if nxt:
            return SwitchPriority.MUST if self.__class__.__name__ == nxt else SwitchPriority.NO
        return super().get_switch_priority(current_char, has_intro, target_low_con)
