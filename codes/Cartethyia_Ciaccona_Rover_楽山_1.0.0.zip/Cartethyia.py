import ctypes
import threading
import time

from ok import Box
from src.char.BaseChar import SwitchPriority
from src.char.Cartethyia import Cartethyia as NativeCartethyia

CIACCONA_NAMES = {'char_ciaccona'}
ROVER_NAMES = {'char_rover', 'char_rover_male'}

# ==================== 物理 F 键监视 ====================
# opener_blocked_by() 靠 task._f_last_press 区分"玩家按 F 重开了一局"和"战斗判定
# 抖了一下"(抖动不会有人按 F): 按过就直接放行, 不用干等 OPENER_MIN_GAP。
#
# 【为什么写在角色文件里】: 这个时间戳原来由 src/ 下的代码写, v3.5.32 的更新用
# git 检出把 src/ 整个盖回官方版, 写入方一行都没剩。configs/custom_teams/ 不受
# 更新影响, 也是唯一能跟着"导出队伍"一起走的地方。
#
# 【为什么要单开一个线程】: 玩家按 F 是在【战斗开始之前】, 那一刻角色代码一行都
# 没在跑。也不能用 GetAsyncKeyState 的低位("上次调用之后按过没有") ——
# get_switch_priority 会被框架对每个候选反复调用, 标志位会被前一次调用吃掉。
#
# 【为什么读得到玩家、读不到宏】: GetAsyncKeyState 读硬件键盘状态; 框架和宏发的键
# 走 PostMessage 直接投递给窗口, 不经过硬件层。
F_VK = 0x46
F_POLL_INTERVAL = 0.05
F_LOG_DEBOUNCE = 1.0
F_TASK_NAME = 'FStartCombatTask'


def f_settings(task):
    """读界面上的(开关, F 之后等待秒数)。没装那张卡片就返回默认值(开, 0 秒)。"""
    executor = getattr(task, 'executor', None)
    for group in ('trigger_tasks', 'onetime_tasks'):
        for other in getattr(executor, group, None) or ():
            if type(other).__name__ == F_TASK_NAME:
                try:
                    return bool(other.enabled), float(getattr(other, 'f_start_delay', 0) or 0)
                except Exception:
                    return True, 0.0
    return True, 0.0


def start_f_watch(task, logger=None):
    """把【物理】F 键按下的墙钟时间记到 task._f_last_press。每个 task 只启一次。"""
    if getattr(task, '_f_watch_started', False):
        return
    task._f_watch_started = True
    if not hasattr(task, '_f_last_press'):
        # 【初值取 -1 不是 0】: 读取方是 `f_press > self.last_opener`, 而
        # last_opener 的"没跑过"也是 -1。给 0 的话开局第一次判定恒成立
        task._f_last_press = -1

    def watch():
        try:
            user32 = ctypes.windll.user32
            user32.GetAsyncKeyState.restype = ctypes.c_short
        except Exception as e:
            task._f_watch_started = False
            if logger:
                logger.error(f'f watch: GetAsyncKeyState unavailable ({e})')
            return
        last_log = 0
        was_down = False
        while True:
            try:
                down = bool(user32.GetAsyncKeyState(F_VK) & 0x8000)
                if down and not was_down and f_settings(task)[0]:
                    now = time.time()
                    task._f_last_press = now
                    # 【本线程是和框架的唯一交接点】: 框架 CombatCheck.note_f_key()
                    # 自己调 GetAsyncKeyState 用的是【低位】—— 读一次就清、整个进程
                    # 共享。本线程 50ms 轮询会把低位清光, 框架那边永远读到 0。
                    # 改成一个读者: 本线程读键, 顺手把框架要的时间戳也写了
                    task._f_pressed_at = now
                    if logger and now - last_log >= F_LOG_DEBOUNCE:
                        last_log = now
                        logger.info('physical F pressed, opener re-armed')
                was_down = down
                time.sleep(F_POLL_INTERVAL)
            except Exception:
                return


    threading.Thread(target=watch, name='ok_ww_f_watch', daemon=True).start()


class Cartethyia(NativeCartethyia):
    """卡夏风队(卡提希娅/夏空/风主·气动)里的卡提希娅, 兼【整条轴的持宏者】。

    非本队时一行不改, 整套走原版。

    ================= 这条轴长什么样 =================
    启动轴(卡提在场, 由她自己起跑):
        R 变身芙露德莉斯 -> R 切回小卡 -> 平A 到出神权剑 -> 满协奏变奏风主
      开局那一发变身 R 的用处是【把 12 秒显化状态存起来】: 显化计时在小卡形态下
      是暂停的, 所以立刻切回小卡等于把这 12 秒原封不动存到后面要用的时候。

    循环轴(入口是风主, 由 Rover.py 调进来), 一圈 4 次 R、2 次下落:
        风主 4A -> E(升空) -> E(下落) -> 落的那一刻切夏空
        夏空 攒 1 格回路 -> E -> 声骸Q -> 切回风主
        风主 4A -> 平A 攒满能量 -> R 大招 -> 演出完接强化E
        强化E 的动画里切卡提 -> 卡提 E(升空, +人权剑) -> 空中切夏空
        夏空 再攒 1 格回路 -> 切回风主 -> E 把协奏顶满 -> 变奏夏空
        夏空 变奏(+第 3 格回路) -> 强化重击 -> R 大招 -> 满协奏变奏卡提
        卡提 变奏(+异权剑) -> 跳+A 下落(三剑转成剑效果) -> R 切大卡
        芙 两段E -> 平A 到巨剑下砸 -> R 切回小卡
        小卡 A4(+神权剑) -> E(+人权剑) -> 重击(+异权剑) -> 跳+A 下落
        R 切大卡 -> 平A 到决意满 -> R 芙大招 -> 小卡平A 出一把剑 -> 变奏风主

    ================= 三条总纲 =================
    1) 【窗口锚在派生帧, 不是动作结束帧】。官方帧表(《鸣潮动作数据汇总》"角色-女")
       每个动作有"发生帧/派生帧/动作结束帧"三个数, 能接下一个动作的时刻是【派生帧】,
       动作结束帧是演完。整条轴所有 *_DERIVE / *_TO_* 常量都是派生帧 /60 得来的,
       旁边注了原始帧数, 改之前先回去查表。
    2) 【能读屏的状态一律读屏, 读不到的才计时】。剑之影数、决意满没满、回路几格、
       强化E 亮没亮、大招演出结不结束都有可靠信号 —— 这些每轮都在变, 计时必错。
       固定时间只留给"没有信号"的那几段: 变奏入场的输入锁、技能起手到出伤。
    3) 【演出期间的按键是被丢掉的、不排队】。所以永远是"连发盖住一段", 不是
       "算准某一帧发一次"; 而连发多个键必须分段, 混着发前一个键会被后一个的演出吃掉。

    ================= 改这个文件之前先读的几条 =================
    - **【启动轴和循环轴必须分开处理】**(用户 2026-08-31 明确要求, 我栽过好几次)。
      seg1/seg2/seg3 的代码两条轴【是共用的】, 所以"照用户说的改一个数"往往会
      把另一条轴一起改掉 —— 用户说"循环轴慢了"我却动了启动轴, 反复发生。
      【流程看着一样不代表能共用一个数】: 交棒过来的状态不同(风主站着还是已经在
      天上)、上一格留下的资源不同、后面接的动作也可能不同。
      所以凡是"这一格两条轴都会走"的参数, 一律拆成 _OPENER / _LOOP 两档,
      用 self.first_loop 分流。改之前先问自己: 用户说的是哪一条轴。
    - 【交棒不能落在大招演出里】: 大招演出期间 has_target() 读不到目标, 控制权一还
      回去就判 target lost -> 3 秒后脱战 -> 重进战斗 -> 启动轴又跑一遍, 循环轴
      永远轮不到。所以每一发大招后面都必须接一个"等演出结束"的循环。
    - 【click_resonance() 返回三元组】(clicked, duration, animated), 不是 bool。
    - 【自定义 __init__ 里跟内置版取值不同的字段会被打回内置值】: CharFactory 换类时
      先 desired_cls(...) 建新实例, 紧接着 replacement.__dict__.update(char.__dict__)
      把内置实例的同名字段全盖回去。新加的字段不受影响, 要改内置字段就在 reset_state()
      里重申一遍。
    - 【f_break() 会撞掉切人】: 击破动画带全局时停 + 队伍 HUD 消失, 切人循环读到
      not in_team 直接判脱战。所以全程 check_f_on_switch = False, 处决自己按。
    """

    # ==================== 引擎参数 ====================

    A_INTERVAL = 0.12            # 连点普攻的间隔。再密下去只是白发, 游戏不吃
    A_INTERVAL_FAST = 0.06       # 要抢"能出招的第一帧"时用
    F_BURST = 0.20               # 单独发处决键的窗口(不点击)。
                                 # 【只发键, 不调 f_break()】—— 那个是阻塞的:
                                 # 0.5 秒起步、最长 5 秒, 期间还一直发左键
    F_BURST_INTERVAL = 0.07
    F_DETECT = 0.40              # 【已不用】发键和检测合成一个循环了, 见 spam_f
    F_ANIM_TIME_OUT = 5.0        # 处决动画的等待上限(角色不同, 0.5~5 秒都有)
    F_ANIM_TAIL = 0.20           # 处决演完之后再补这么点连点。
                                 # 【别设太小】: 演完那一刻还在收招, 紧接着的 R 会被吞
    USE_F_BREAK = True           # 【一键关掉处决】: 处决动画带全局时停, 真要是
                                 # 怎么都对不齐, 把这个改成 False 就整条轴不打处决
    KEY_INTERVAL = 0.10          # 连发技能键的间隔

    SWITCH_TIME_OUT = 2.5        # 超过这个还没切过去就是撞在动画里了, 记一笔往下走
    SWITCH_KEY_DOWN_TIME = 0.02  # 按住更久没用而且更慢(send_key 会阻塞整个按住时长)
    SWITCH_KEY_INTERVAL = 0.0    # 每轮都重发数字键: 游戏在动作期间会拒绝切人,
                                 # 只有一直按着才能在它放行的第一帧生效
    SWITCH_SETTLE = 0.0
    UNTRUSTED_CONFIRM = 3        # in_team() 的 count 不达标时, 同一个 index 连读到
                                 # 这么多次也认 —— 一票否决会在特效盖住槽位时假失败
    TRACE_SWITCH = False         # 排查"键发了却不换人"时打开
    SWITCH_CD = 0.88             # 换人 CD(自己记账, 不读头像上那个 OCR 数字)

    LIB_FIRE_WINDOW = 0.6        # 按 R 的重试窗口。【给短】: 判据失灵时这里会一直按 R,
                                 # 把后面轮到的那一发大招白按掉
    LIB_KEY_INTERVAL = 0.05
    LIB_READ_EVERY = 3           # 每发这么多次 R 才读一次屏(读屏 0.04s, 挂一起等于把
                                 # 重试周期翻倍, 而 R 被接受只跟按键落下的时刻有关)
    LIB_ANIM_TIME_OUT = 9.0
    LIB_ANIM_TAIL = 0.15         # HUD 回来那一刻角色多半还在收招里, 那几下照样被吞
    HUD_NO_ANIM_GRACE = 0.8      # 连着这么久都读到在场 = 这一次压根没有演出

    CON_ENOUGH = 0.99            # 协奏读到这个就算满(会在 0.99 上卡一下再跳满)
    CON_POLL_INTERVAL = 0.03
    CON_WAIT_TIME_OUT = 2.5
    CON_STALL_GIVE_UP = 0.8      # 读数一动不动就别等满超时了
    CON_SAMPLE_MAX = 40
    # 0.08 -> 0.15 (用户 2026-08-30: 重击没打完就 R 了)。
    # 长按左键会【先打出几下普攻再蓄力】, 那几下每下涨 0.02~0.03, 攒两三下就够
    # 触发 0.08 —— 而强化重击一下给 25 点(=0.25), 阈值抬到 0.15 才分得开
    CON_RISE_THRESHOLD = 0.15    # "协奏涨了"的判据

    OPENER_MIN_GAP = 60.0        # 防重入: 战斗判定抖一下不该让启动轴重跑

    # ==================== 一段普攻多长(秒) ====================
    # 【这是"打出第 n 段"用的估值, 不是帧表数】: 连点时游戏自己按连段节奏推进,
    # 单段派生帧只是下界。实测/录像量出来的平均段长填在这里。
    SEG_CART = 0.42              # 小卡 A1->A2->A3->A4
    SEG_FLEUR = 0.40             # 芙露德莉斯 A1..A5
    SEG_ROVER = 0.55             # 【已不用】风主的地面连段长度。他两次上场都是
                                 # E 升空 -> 空中4下, 没有地面连段了。保留作标定记录
    SEG_CIAC = 0.45              # 夏空 A1..A4

    A_LEAD = 0.20                # 最后一段只要【递出去】就行, 它的动画会在切人之后
                                 # 继续演(合轴), 所以不给它留时长, 只留这一点点保证
                                 # 有一下落在能出招的第一帧

    # ==================== 官方帧数据(60fps, 帧/60=秒) ====================
    # 出处: 《鸣潮动作数据汇总》sheet"角色-女"。卡提希娅 r3994-r4090、
    # 芙露德莉斯 r4091-r4180、风主 r2091-r2134、夏空 r2135-r2223。
    # 【取的都是"派生帧"】—— 那才是能接下一个动作的时刻。

    # ---- 卡提希娅(小卡) ----
    CART_INTRO_LOCK = 0.88       # QTE 第53F前不响应输入(第41F前不能切人)
    CART_INTRO_TO_SWORD = 1.10   # QTE-异权剑 发生65F: 变奏入场自带一把剑
    CART_A_TO_SWORD_CAP = 2.60   # 从站桩连点到 A4 出神权剑的上限。A4-神权剑 发生45F,
                                 # 但前面要先走完 A1(派生17F)+A2(46F)+A3(60F)
    CART_E_TO_SWORD = 0.75       # E-人权剑 发生43F。E 的位置状态是"地转空", 放完人在空中
    CART_E_DERIVE = 0.90         # E-击飞 结束54F: 这之后 E 这一套才算递完
    # ---- 小卡这一串按用户 2026-08-29 的流程: A到A4(起长按) -> 自动接重击
    #      -> 跳跃取消重击后摇 -> E -> 闪避取消E后摇 -> A 下落 ----
    # 0.70 -> 1.20 (用户 2026-08-30: "重击接早了, 晚0.5s长按重击")。
    # 长按开始的时刻就是这一段结束的时刻, 所以推后它 = 重击晚出来。
    # 【连带影响: 跳跃也会跟着晚 0.5 秒】—— 松手时刻 = 这个数 + CART_A4_HOLD,
    # 而跳跃锚在松手上。这是对的(重击整体后移, 取消它后摇的跳跃当然也要后移);
    # 要是跳跃因此反而不对了, 单独减 CART_A4_HOLD, 别回头动这个数
    CART_A_TO_A4 = 1.40          # 切回小卡之后连点到 A4 的窗口(形态切换已经走了 A2)
                                 # 0.70 -> 1.20 -> 1.40 (用户 2026-08-30: 重击再慢 0.2 秒)
    # 1.60 -> 1.03 (用户 2026-08-30 实机量: 跳跃该提前 0.57 秒)。
    # 跳跃的绝对时刻 = 长按开始 + 这个数 + CART_HEAVY_TO_JUMP, 所以提前跳就是减它。
    # 【说明重击比帧表估的早】: 我按 A4-神权剑45F + 地面重击-异权剑56F 估的 1.60,
    # 实机 1.03 就够 —— 前面 CART_A_TO_A4 那段连点已经把连段推得更远了
    CART_A4_HOLD = 1.03          # 从 A4 起长按左键, 一直按到重击出异权剑
    # 【跳跃只发一次】(用户 2026-08-30: "只能跳一次")—— 连发会二段跳。
    # 所以这一格【没有"被吞了就补一发"的余地】, 只能靠时机: 下面这个数就是
    # "长按松手之后隔多久跳", 实机对着日志里的 跳@... 调
    # 0.0 -> 0.20 (用户 2026-08-30: 重击后延 0.5 秒那个时间之前调对了, 现在又不对)。
    # 【是我上一轮删东西删出来的回归】: 松手和跳跃之间原来夹着一句
    # wait_swords(2, poke=False, cap=0.20) —— 它读不到剑就跑满 0.20 秒, 而实机
    # 那三把剑的模板【从来读不到】, 所以它每一轮都稳定地贡献 0.20 秒延迟。
    # 用户就是在【有这 0.20 秒】的前提下把 CART_A4_HOLD 调到 1.03 的。
    # 我把那句删掉(它确实是个假动作), 整段跳跃/E/闪避/下落就一起提前了 0.20 秒。
    # 现在把这 0.20 秒明写成常量补回来: 时机跟调好时一致, 但它变成了一个
    # 【可调的数】, 不再是某个读不到的判据碰巧跑满上限
    CART_HEAVY_TO_JUMP = 0.20    # 松手 -> 跳跃 的间隔
    CART_JUMP_SPAM = 0.18        # 【已不用】跳跃连发窗口, 保留作标定记录
    CART_JUMP_INTERVAL = 0.06    # 【已不用】
    CART_JUMP_TO_E = 0.15        # 跳跃 -> 按 E
    # 0.75 -> 0.0 (用户 2026-08-30: "E了马上接闪避A 不需要等")。
    # 原来按帧表的 E-人权剑 43F(0.72s) 等出剑再闪避 —— 但技能【递出去就会结算】,
    # 人不用留在原地等那把剑。这跟 seg2 那几处"放了技能就马上切"是同一条。
    # 【真丢剑的话症状在这】: 下一步的下落攻击吃不满三把剑, 日志 三剑(?/3)
    CART_E_TO_DODGE = 0.0        # E 之后隔多久闪避取消后摇
    CART_DODGE_TO_FALL = 0.0     # 【已不用】闪避之后立刻接普攻, 不留间隔。
                                 # E 是"地转空", 人还在空中, 这一次的下落攻击不用再跳
    # 0.30 -> 0.60 (用户 2026-08-30: "闪避接A还是没到位, 正确的应该是只能看到
    # 一点闪避的动作就A打断了")。
    # 【0.30 为什么等于没点】: 帧表 卡提 闪避-前 发生1F 持续21F 结束21F(0.35s),
    # 极限闪避-前 派生16F(0.27s) —— 也就是【前 0.27~0.35 秒的点击全被闪避吃掉】。
    # 窗口只有 0.30 的话, 所有点击都落在被吃的区间里, 窗口一结束就进
    # macro_wait(CART_FALL_TO_LAND) 那 0.55 秒【不点击】的等待 ——
    # 结果就是闪避动作完整播完、A 一下都没打出来。
    # 窗口必须【跨过闪避的派生帧】, 才有点击落在"能出手的第一帧"上
    CART_FALL_A_SPAM = 0.60      # 下落攻击的连点窗口
    CART_HEAVY_HOLD = 0.55       # 【已不用】旧的独立重击长按, 保留作标定记录
    CART_HEAVY_TO_SWORD = 1.00   # 地面重击-异权剑 发生56F、派生60F
    CART_FALL_TO_LAND = 0.55     # 空中攻击-下落 结束32F
    CART_LAND_DERIVE = 0.30      # 空中攻击-N剑落地 派生18F: 落地后这么久就能接下一步
    CART_LIB_RETRY_CAP = 1.20    # 变身 R 没放出去时边点边等能量的上限。
                                 # 【处决之后特别需要】: 处决动画演完那一刻角色还在
                                 # 收招里, 第一发 R 十有八九被吞
    CART_TRANSFORM_ANIM = 3.40   # 大招-隐藏HUD 持续203F(第196F前不能切人)。只当兜底,
                                 # 真正的判据是 HUD 回没回来
    CART_FORM_IN = 0.80          # 芙->小卡的形态切换走的是卡提 A2, 派生46F
    CART_FORM_CD = 1.55          # 形态切换"冷却1.5秒"(帧表备注), 留一点余量

    # ---- 芙露德莉斯(大卡) ----
    FLEUR_FORM_IN = 0.80         # 小卡->芙的形态切换走的是芙 A2, 派生46F
    # 【EE 是连放的, 不等派生帧】(用户 2026-08-29: "你EE那里按慢了" -> 改成 0.15
    # 之后仍然"EE又没连放出来")。
    # 【为什么两次都没成】: 我一直是用【两个独立的连发窗口】发的 —— 第一发 press_e
    # 在 0.20 秒里发三次, 第二发又发三次。连发的语义是"盖住一段动画, 总有一下落进去",
    # 【次数本身没有意义】; 而这一格要的是【两次独立的按键】, 连发会把两发挤成一发
    # (第二、三次落在第一发的动画里被丢掉), 表现出来就是只放出一个 E。
    # 正确的原语是 spam_key(presses=2): 只发两次, 按 interval 铺开
    # 【实机证据】(2026-08-30 日志): form(芙)@22.89 -> 芙EE(x2)@23.03 ——
    # 【两发键都发出去了】, 所以不是"没按", 是【游戏没接第二发】。
    # 帧表: 芙 E1-1 发生5F 持续30F, E1-2 发生42F、【派生55F】(0.92s) ——
    # 第二发落在 E1 的动作里就是被丢掉。0.12 必然吞, 而原来那版
    # (press_e 0.20 窗口 + 等 0.95) 实际间隔 1.15 秒, 所以用户说"按慢了"。
    # 【改成高频连发盖住整段】(用户 2026-08-30: "多按几下频率高一下呢,
    # 反正进CD了也不会有失误")—— 这条是对的, 而且比我前面两版都对:
    #   presses=2 精确发两次: 第二次落在 E1 动作里被丢掉, 而且【没有第二次机会】;
    #   固定间隔猜派生帧: 猜早了同上, 猜晚了就是"按慢了"。
    # 芙的 E 是【充能制】, 多按的那几下落在没充能的时候就是空操作, 没有代价。
    # 所以正确形状是连发盖住 E1 的整段动作: 第一发被接受 -> 中间的按键在动画里
    # 被丢掉 -> E1 派生的那一帧, 下一次按键立刻变成第二发。
    # 【窗口下界】= E1-2 的派生帧 55F(0.92s), 给到 1.20 留余量
    # 【实机标定】(用户 2026-08-30): 第一发 E 按下 42S96 -> 第二发按下 41S98,
    # 期间一直在连按 —— 【两发之间稳定 0.98 秒】。
    # 跟帧表对得上: E1-2 的派生帧是 55F = 0.92 秒, 也就是第二发就是在 E1 一派生
    # 的那一帧被接受的, 中间那十几次连按全被动画丢掉(不花钱)。
    # 所以窗口只要盖住 0.98 + 一点余量; 给 1.80 的话第二发进去之后还要空发 0.8 秒,
    # 那不是"无代价", 是把后面的 A345 整个推后
    FLEUR_EE_WINDOW = 1.15       # 连发窗口(正常情况)
    FLEUR_EE_RETRY = 1.10        # 【保底】: 窗口跑完还读不到"两格都用掉"就再来一轮
    FLEUR_EE_DONE = 0.90         # "两格充能都用掉了"的读数阈值。
                                 # 【要实机标定】: 对着日志里的 芙E充能X.XX 调
    FLEUR_EE_INTERVAL = 0.07     # 连发间隔
    FLEUR_EE_GAP = 0.55          # 【已不用】两发之间的固定间隔, 保留作标定记录
    FLEUR_E1_TO_E2 = 0.95        # 【已不用】E1-2 派生55F, 保留作标定记录
    # 1.30 -> 1.10 (用户 2026-08-30: "EE之后又愣了一下才A", 而且 A5 被挤没了)。
    # 【这个数是从 EE 窗口【结束】起算的, 不是从第二发 E 按下起算】——
    # 实机第二发在 0.98 秒进去, 而窗口是 1.15, 所以窗口结束时 E2 已经走了 0.17 秒。
    # 帧表 E2-下落37F + E2-落地3 派生40F = 1.28 秒, 减掉那 0.17 就是 1.10
    FLEUR_E2_TO_A = 1.10         # EE 窗口结束 -> 能接普攻
    # 2.20 -> 2.80 (用户 2026-08-30: "打大卡没A到位就变小卡了")。
    # 【上界在哪】: 决意一到 120, 下一发 R 就变成芙大招而不是切回小卡 ——
    # 那样后面攒的三把剑和第二次下落全部落空。所以这个数只能一点一点往上试,
    # 症状是"R>小卡 那一下直接放了大招"(日志里 form(小卡) 前面会先出现 HUD 消失)
    FLEUR_A1_WINDOW = 0.35       # 【已不用】处决改放 R2 之后, 保留作标定记录
    # 0.50 -> 0.35: 发键和检测合并之后, 这个数就是【没处决时的全部开销】。
    # 每轮里发一次 F + 读一帧, 0.35 秒够发三四次, 有处决的话早就读到了
    F_AFTER_R2 = 0.35            # R2 之后连发处决键的窗口
    # 2.20 -> 2.80 -> 1.52 (用户 2026-08-30 实机量: A5 打出来之后到切小卡
    # 还多等了 1.28 秒)。合并连点之后 A5 稳定出得来了, 这 1.28 秒就是纯多余的。
    # 【只减这一个数, 别动 FLEUR_E2_TO_A】: 那 1.10 是等 E2 落地的部分,
    # 减了 A 的起点就提前到落地之前, A5 反而又打不出来。
    # 【顺带的好处】: 少打这一段决意也少涨, R>小卡 更不容易误变成芙大招
    FLEUR_A_TO_A5_CAP = 1.60     # 连点到 A5(巨剑下砸)的上限, A5-2 派生48F
    # 0.30 -> 0.60 (用户 2026-08-30: "R2前最后1A伤害没到就R2了")。
    # 【为什么图标亮了伤害还没到】: 决意是 A5-1(核心回收1 +10)推满的, 而这一段的
    # 大头伤害在 A5-2 —— 帧表 A5-2 发生58F、持续12F, 比图标亮的那一帧晚将近一秒
    # 1.20 -> 2.20 (用户 2026-08-30: "大卡A5还是没出来")。
    # 【为什么要这么长】: 第二次进芙形态时连段是从头起的 —— 形态切换本身走的是
    # 芙的 A2, 之后还要 A3(4段) -> A4(5段) 才轮得到 A5。帧表累计:
    # A2-4 派生46F + A3-4 派生54F + A4-5 派生54F = 154F(2.6s), 再加 A5-2 的 58F。
    # 而 wait_lib_big 是【决意一满就返回】的, 决意在 A3/A4 阶段就可能满了,
    # 剩下这一段才是真正把连段推到 A5 的部分
    # 1.20 -> 2.20 -> 2.10 -> 1.71 (用户 2026-08-30 实机量: 该缩短 0.39 秒)。
    # 到这一版 A5 已经打得出来了, 剩下的是 R2 开晚了 —— 缩的是 A5 出伤之后
    # 那段多余的连点
    FLEUR_A5_TO_R2 = 1.71        # 【当前不用】决意图标亮 -> 开 R2 之间继续连点的窗口。
                                 # 用户 2026-08-30 改成"能放就直接放", 这一段被去掉了;
                                 # 数值保留, 要恢复"等 A5 出伤再开"就把那句 macro_spam
                                 # 加回 wait_lib_big 和 fire_fleur_lib 之间
    FLEUR_LIB_ANIM = 5.10        # 大招-隐藏HUD 持续300F(第202F解除显化、清空决意)

    # ---- 风主·气动 ----
    ROVER_INTRO_LOCK = 1.42      # QTE 第85F前不响应输入(第67F前不能切人)
    ROVER_E1_TO_E2 = 0.95        # 地面E-2 派生57F。地面E 的位置状态是"地转空"
                                 # (只有 seg2 那格单发 E 顶协奏时还用得到)
    # ---- 风主上场那一整格(用户 2026-08-28 确认的顺序): E -> 空中4下 -> E -> 落 -> 切 ----
    # 【E 必须第一个按】: 帧表里地面E-1 的位置状态是"地转空" —— 是 E 把人送上空中的,
    # 不是打完 4A 才 E。空中普攻(空中A1/A2 各给 25 点核心回收1)是强化E 那 60 点充能的
    # 唯一来源, 人不在空中这一整格就白打了
    # 【这一段要连点, 不要把点击铺开】(用户 2026-08-29 纠正)。
    # 我先前按视频里量到的落点间隔(0.53/0.75/0.53)去铺点击, 那是【动画本身的长度】,
    # 不是他按键的节奏 —— 玩家是一直在点的。铺开的后果是每一段都要等下一次点击才
    # 起手, 四下打完比该有的慢一大截。
    # 正确的形状跟这条轴其它地方一样: 【打出几段由窗口长度决定, 不由单次点击的时机
    # 决定】—— 动画期间的点击被丢掉、不排队, 连点保证总有一下落在动画刚结束的瞬间。
    # 【要调就调窗口】: 短了第四下出不来, 长了他已经落地。别去改点击间隔。
    # 【这一段现在是"点几下"说了算, 不再有独立的窗口长度】(用户 2026-08-29:
    # "A的间隔太长了, 再密集一点")。原来窗口和点击数是两个数, 点完还要把窗口剩下的
    # 时间干等完 —— 间隔一压密, 那段干等就成了纯浪费。
    # 现在 段长 = 点击数 x 间隔 + 尾巴, 压密间隔整段自然跟着变短。
    ROVER_AIR_A_CLICKS = 4       # 【已不用】改成两次上场各自的段数, 见下
    # 【两次上场打到的段数不一样】(用户 2026-08-30 的流程):
    #   第一次(变奏入场自带升空): "直接a到a4下落攻击" -> 4 段
    #   第二次(E 升空):          "ea到a3(3/4回路)"   -> 3 段
    # 【第一次上场的两种情形段数不一样, 必须分开】(用户 2026-08-30:
    #  "是把一开头E A4切夏空那里也改了")。
    # 我按"切夏空要快0.8s"把段数从 4 减到 2, 但那两种情形共用了同一个数:
    #   循环圈交棒过来 -> 人【已经在天上】, 直接 A, 要的就是快 -> 2 段
    #   启动轴交棒过来 -> 人是站着的, 先 E 升空【再】A4 -> 4 段, 减了就是"没A几下就切"
    # 交棒时刻 = 段数 x ROVER_AIR_A_STEP + ROVER_FALL_TO_SWITCH,
    # 而 STEP 已经贴着派生帧(空中A1 22F / 空中A2 24F), 再压就打不出段数
    # 【点击数和间隔一起翻倍/减半, 总长不变】(用户 2026-08-30: "能不能连点8下,
    # 总体时间一样")。段长 = 点击数 x 间隔, 所以 4x0.38 和 8x0.19 是同样长的一段,
    # 但后者【每一下之间只隔 0.19】—— 某一段要是比帧表的派生帧提前结束,
    # 密的那一版能立刻接上, 稀的那一版还要干等到下一次点击。
    # 动画期间多出来的点击是被丢掉的、不花钱, 所以密点本身没有代价。
    # 【唯一的风险】: 段数【提前打完】之后, 剩下那几下会捅出"空中普攻-下落",
    # 人提前落地、后面那发 E 就不是空中E 了。症状就是这个, 出现了就减点击数
    ROVER_A_CLICKS_LIFT = 8      # E 升空那次(启动轴): 8 x 0.19 = 1.52, 总长不变
    ROVER_A_CLICKS_AIR = 4       # 已经在天上那次(循环圈): 4 x 0.19 = 0.76, 总长不变
    # 3 -> 8 (用户 2026-08-30 确认: "第二次风主E上天没打够回路就R了")。
    # 【这是我上一轮减半 ROVER_AIR_A_STEP 时漏掉的】: STEP 0.38->0.19 之后
    # _LIFT 和 _AIR 都跟着翻了倍, 只有这个没有 —— 于是这一格从 1.14 秒
    # 悄悄变成了 0.57 秒, 回路当然攒不够。
    # 【这一格的 A 是攒回路的】: 强化E 吃 60 点核心回收1, 而空中普攻每段给 25,
    # 攒不够的话大招放完强化E 就亮不起来
    # 8 -> 5 (用户 2026-08-30: "这里接R再快0.5s")。5 x 0.19 = 0.95, 比 1.52 快 0.57。
    # 【敢减是因为下面有保底】: 打完读一次回路, 没满就再补 ROVER_A_CLICKS_2_EXTRA 段。
    # 所以主路径快、只有回路真不够的轮次才多花那 0.76 秒 —— 比"每轮都按最坏情况打满"
    # 划算。日志里 风主回路满/未满 就是在告诉你这一轮走的哪条
    # 【第二次上场的段数, 启动轴那圈和循环圈分开】(用户 2026-08-31 指出我总把两者
    # 混着改)。这一格的代码是两边共用的, 只能靠 first_loop 分档。
    ROVER_A_CLICKS_2_OPENER = 8  # 启动轴带出来的那一圈: 8 x 0.19 = 1.52 秒
                                 # 6 -> 8 (用户 2026-08-31: "启动轴不对, 太快了,
                                 # 要回到原来的")。
                                 # 【为什么 6 还是太快】: 同一轮我还把 A 段里的
                                 # 【逐段读屏】去掉了(那是给循环轴提速用的) ——
                                 # 原来 5 段的实际耗时是 0.95 + 5 次读屏 ≈ 1.5 秒,
                                 # 读屏一撤, 光靠段数就得给到 8 才补得回来。
                                 # 【教训】: 改"怎么打"和改"打多久"是两件事,
                                 # 前者会悄悄改掉后者
    ROVER_A_CLICKS_2_LOOP = 5    # 循环圈: 5 x 0.19 = 0.95 秒 —— 这几轮调的都是它
    ROVER_A_CLICKS_2 = 5         # 【已不用】保留作标定记录
    ROVER_A_CLICKS_2_EXTRA = 4   # 【已不用】改成打满就 R, 不再读回路补段
    # A 打满 -> 按 R 之间再打这么久(微调旋钮)。段数是 0.19 一档、太粗,
    # 想动零点几秒就调这里。【也按圈分开】—— 见类文档"两条轴必须分开"那条
    ROVER_FORTE_TO_R_OPENER = 0.0
    ROVER_FORTE_TO_R_LOOP = 0.05  # 用户 2026-08-31: 循环轴 R 再慢 0.05 秒
    ROVER_FORTE_TO_R = 0.0       # 【已不用】两轴共用的那一版, 保留作标定记录
    ROVER_A_CLICKS_3 = 2         # 【已不用】第三次上场现在不打 A, 见 ROVER_E_TO_SWITCH
    # 0.22 -> 0.38: 【这个数的含义变了】—— 不再是"两次点击的间隔"(那一版卡顿),
    # 而是【一段空中普攻占多长】, 用来把段数换算成连点窗口。
    # 帧表: 空中A1 派生22F(0.37s)、空中A2 派生24F(0.40s), 取 0.38。
    # 【打不出那么多段就减它, 提前落地就也减它】—— 两种症状都是窗口相对段数太长
    ROVER_AIR_A_STEP = 0.19      # 【两下之间的间隔】。0.38 -> 0.19(点击数同时翻倍,
                                 # 总长不变)。帧表的派生帧是 22F/24F(0.37/0.40),
                                 # 比它密的那几下会被动画丢掉 —— 不花钱, 而且万一
                                 # 某段提前派生就能立刻接上
                                 # 【下界在哪】: 帧表的空中普攻派生帧是 22F/24F
                                 # (0.37/0.40), 比它还密的话多出来的输入会被动画丢掉 ——
                                 # 而这里点击数是封顶的, 丢一下就【少一段】。
                                 # 看到"某一下没出来"就往回调, 别加点击数
                                 # (加点击数只会提前捅出下落攻击)
    ROVER_AIR_A_TAIL = 0.20      # 【已不用】老版本点完 N 下还要把窗口剩下的时间
                                 # 干等完, 那一段就是"空中A卡顿"的来源。现在窗口
                                 # 严格等于点击总时长, 点完立刻走
    ROVER_AIR_A_WINDOW = 1.30    # 【已不用】保留作标定记录
    ROVER_AIR_A_ECHO_AT = 0.45   # 【已不用】声骸不再插在连段中间, 见 rover_air_burst
    # 【E 自带两下, 这期间一下都不能点】(用户 2026-08-29: "按E他会升空自动打两下,
    # 你应该按完E再A")。帧表对得上: 地面E-1 发生20F、地面E-2 发生37F 是两段伤害,
    # 而能接下一个动作的时刻是 地面E-2 的【派生帧 57F】= 0.95 秒。
    # 在这之前点的每一下都是白给 —— 更糟的是它们会把空中的段数用光,
    # 于是"A4 还没出来就下落了"
    # 0.95 -> 0.83 (用户 2026-08-30: "循环轴会在E之后a的时候卡顿一下")。
    # 【0.95 是【地面E】的派生帧, 这一格用的其实是【空中E】】: 循环轴这次风主是从
    # 卡提 A4 击飞那一刻交棒过来的, 他【继承了浮空】—— 所以按下去的是空中E 而不是
    # 地面E。帧表两者不一样:
    #   地面E-1 发生20F / 地面E-2 发生37F, 派生57F = 0.95
    #   空中E-1 发生 9F / 空中E-2 发生38F, 派生【50F = 0.83】
    # 多等的那 0.12 秒就是卡顿。启动轴那次不明显是因为它前面还压着换人硬直
    # 0.95(地面E派生57F) -> 0.83(空中E派生50F) -> 0.40 (用户 2026-08-30: 干等太长)。
    # 【0.40 比帧表的派生帧短, 是故意的】: 地面E-2 发生37F(0.62)、空中E-2 发生38F,
    # 所以 A 的头几下会落在 E 的第二段伤害里被吞 —— 但现在这一段是【密点】
    # (间隔 0.19、段数封顶 8), 被吞的那几下不花钱, 而 E 一派生立刻就有下一次
    # 点击接上, 比干等到 0.83 再开始点更早出手。
    # 【要是看到 E 的第二下伤害被 A 顶掉了】, 就把这个数往回加
    ROVER_E_AUTO_HITS = 0.40
    ROVER_AIR_A_ECHO_AT = 0.45   # 声骸插在这一刻(视频里 Q 的 CD 是在第1、2下之间跳的)
    ROVER_Q_WINDOW = 0.25        # 【已不用】声骸改成发一次就走, 不再有窗口。
                                 # 【第二次上场要把它补回来】: 第一次上场中间夹了这一发,
                                 # 发键期间照旧连点, 所以那一格的空中段实际是
                                 # WINDOW + 这个; 第二次没有声骸, 不补的话就短一截
                                 # (实机 1.57s vs 1.30s)。用户要求两次保持一致
    # 【这是从"按下第二发 E"到"发出切人数字键"的【总预算】】, 不是额外等待 ——
    # 发 E 的连发窗口和那次读协奏都算在里面。用户 2026-08-29 实测这一格慢 0.2 秒,
    # 根因就是原来这三样是【串起来加】的: 0.20(发E) + 读协奏 + 0.25(等) ≈ 0.5 秒
    # 【这一格没有第二发 E 了】(用户 2026-08-29 纠正: "E都进入cd了还没下落",
    # "正好E最后一下结束再A正好是下落攻击")。让他砸下来的是【空中连段打完之后再点一下】,
    # 不是再放一次 E。那发多余的 E 还把第二次上场要用的充能烧掉了
    # (实机: 第二次上场 风主E(x5) 一直发不出去, 后面 风主回路未满 / R_NOFIRE 全是连锁)。
    # 0.80 -> 0.30 (用户 2026-08-29 实机: 快 0.5 秒)。
    # 【0.30 是"人还在往下掉"的时候就交棒, 不是等他落地】—— 跟攻略上"下落的瞬间
    # 切夏空"对得上, 而且夏空要的就是【继承浮空】(她接手走的是空中出场技,
    # 见 CIAC_AIR_INTRO_TO_E)。等他落地(0.80)的话夏空是站在地上出来的。
    # 【代价, 要盯一下】: 帧表里 空中普攻-下落 的伤害在 34F(0.57s)、落地那一下
    # 协奏回收 9.6 —— 0.30 会把这两笔切掉。日志里的 con^0 变多就是这个,
    # 那说明夏空吃不到变奏入场(少一格回路)
    # 0.30 -> 0.18 (用户 2026-08-30: "风主都落到地上了才切夏空")。
    # 【这两个数是一对, 要一起看】: ROVER_FALL_A_SPAM 是连点窗口, 而交棒最早也只能
    # 在连点结束之后 —— 所以【连点窗口就是交棒的下限】, 只减 TO_SWITCH 是没用的。
    # 下落攻击本身 34F(0.57s)才落地, 0.18 交棒时人还在半空, 夏空才继承得到浮空
    ROVER_FALL_TO_SWITCH = 0.18
    ROVER_E2_TO_SWITCH = 1.92    # 【已不用】保留作标定记录
    ROVER_E2_TO_FALL_A = 0.70    # 【已不用】
    ROVER_E2_WINDOW = 0.14       # 【已不用】第二发 E 的连发窗口
    # 【下落攻击是点出来的, 不是自动的】(用户 2026-08-29: "为什么风主不打下落攻击了")。
    # 我原来在 E2 之后整段不点普攻, 理由写的是"人在空中点击会变成下落攻击" ——
    # 那句话本身没错, 错在【下落攻击正是这一格要的东西】: 帧表里
    # 空中普攻-落地 削韧120、协奏回收9.6, 是这一整格协奏的大头, 漏了它夏空就吃不到变奏入场。
    # 【下落攻击要连点盖出来, 单发会被吞】: 动画期间的输入被丢掉、不排队,
    # 实机试过单发 —— 日志里 风主下落A_end(x1) 键发了, 人没动
    # 0.40 -> 0.25: 这个窗口【本身就是交棒的下限】—— ROVER_FALL_TO_SWITCH(0.30)
    # 是从连点开始算的总预算, 连点比它还长的话预算就没有意义了。
    # 第一下被接受就出下落攻击, 后面几下只是防被吞的保险, 0.25 够了
    ROVER_FALL_A_SPAM = 0.15     # 下落攻击的连点窗口。【它是交棒的下限】——
                                 # 0.15 / 0.06 间隔 = 2~3 下, 够把下落攻击递进去了
    ROVER_E2_TO_FALL = 0.85      # 【已不用】空中E-2 派生50F。保留作标定记录
    # 0.80 -> 0.05 (用户 2026-08-30: "强化E能不能按下马上切卡提, 实机上你还是慢了")。
    # 【我把帧表那句读反了】: 「强化E1-压暗特效 第48F后, 处于【切人滞留状态】时
    # 自动派生强化E2」—— "切人滞留状态"是【切人指令已经发出去、角色正在滞留】的状态,
    # 不是"等到48F再去切人"。所以切人键要【立刻发】, 游戏让她滞留, 到 48F 自己
    # 把强化E2 派生出来, 然后才真正换人。等满 48F 再切等于白站 0.8 秒。
    ROVER_FE1_TO_SWITCH = 0.05   # 【原注释见下, 结论已反转】
                                 # 强化E1-压暗特效 备注: "第48F后, 处于切人滞留状态时
                                 # 自动派生强化E2"。也就是强化E1 放出去 0.8 秒后切人,
                                 # 强化E2 会自己接上 —— 所以这里【不能等它打完再切】,
                                 # 等满了就是白站着, 切早了强化E2 不会派生
    ROVER_LIB_ANIM = 3.55        # 大招-隐藏HUD 持续210F(第211F前不能切人)
    ROVER_LIB_RETRY_CAP = 1.20   # R 没放出去时补普攻攒能量的上限(正常轮次用不到)
    # 0.30 -> 0.10 (用户 2026-08-30: "风主R完还会A1-2下才按强化E")。
    # 【为什么不能直接设 0】: poke_until_hud_back 的判据是队伍 HUD 回来, 而帧表里
    # 大招-伤害 是 发生148F 持续66F(到214F才打完)、第211F前不能切人 ——
    # HUD 回来那一刻他还在收招里, 一点缓冲都不留的话强化E 会被吞。
    # 0.10 大约就是一下点击的量
    ROVER_LIB_TO_FE = 0.10       # 大招演出结束 -> 强化E。【这一段在点普攻, 不是干等】
    ROVER_E_TO_SWITCH = 0.30     # 第三次上场: 从按下 E 到发切人键的【总预算】
                                 # (发 E 的窗口算在里面)。这一格不打 A、不读协奏
    ROVER_E_CON_CAP = 1.15       # 【已不用】"边发E边盯协奏"那一版的上限
    ROVER_E_RESEND_CAP = 0.40    # "E 升空"那一发的重发上限。【单发会被吞】——
                                 # 用户 2026-08-29 实测第二次上场那发 E 就没出去

    # ---- 夏空 ----
    CIAC_INTRO_LOCK = 1.17       # 【地面】变奏入场: QTE 第70F前不响应输入、不能切人
                                 # (第40F触发上一角色延奏)
    # 【这条轴上夏空三次上场都是从空中接手的】: 交棒的那一刻上一个角色都在空中
    # (风主放完 E、卡提放完 E 都是"地转空"), 接手的人继承浮空状态, 走的是空中出场技。
    # 帧表: 空中A2-下落 结束34F -> 空中A2-落地 派生12F, 合计 46F。
    # 【提前按 E 的后果】(用户 2026-08-29 实测): 那一发要么被下落动画整个吞掉,
    # 要么把落地那一下的伤害顶掉 —— 而落地那下正是 音影 铺场的来源
    CIAC_AIR_INTRO_TO_E = 0.80
    # 取消过一次又加回来了(用户 2026-08-29: "夏空下落攻击后还是要A一下 再eq")。
    # 她三次上场都是空中出场技落地, 落地之后都补这一下
    CIAC_LAND_A_TO_E = 0.30
    # 【放完技能就交棒, 别等动画】(用户 2026-08-29: "后面的切人也都慢了,
    # 放了技能就马上切 别等")。技能一旦递出去, 后续的伤害和资源结算不需要人留在场上,
    # 留着只是白站。这一格只留一点点, 保证技能键先于数字键落地
    SKILL_TO_SWITCH = 0.10
    # 【E 和 Q 连着放, 中间不留间隔】(用户 2026-08-29: "你eq不要有间隔啊 一起放啊")。
    # 原来这里按 E-伤害 的派生帧 32F 等了 0.55 秒 —— 声骸是独立于普攻连段的,
    # 不需要等 E 派生完才能按
    CIAC_E_DERIVE = 0.0          # 【已不用】E-伤害 派生32F, 保留作标定记录
    CIAC_HEAVY_HOLD = 0.50          # 兜底用的重击长按时长(正常走 heavy_click_forte,
                                 # 那个是按住到强化重击标记消失为止, 比定长可靠)
    CIAC_HEAVY_TO_LIB = 1.60     # 等协奏涨的上限(涨了就提前走)。
                                 # 【比帧表的 60F 给得宽】: 60F(1.0s)是强化重击的
                                 # 发生帧, 协奏还要等结算飞过去才涨
    CIAC_HEAVY_MIN_BEFORE_R = 0.55  # 这之前一律不判"协奏涨了"。
                                 # 帧表: 强化重击-地面 发生60F(1.0s)才出伤, 而
                                 # heavy_click_forte 的判据(标记消失)掉得早得多
    CIAC_LIB_ANIM = 3.35         # 大招-隐藏HUD 持续198F(第223F前不能切人)
    CIAC_LIB_RETRY_CAP = 2.30    # R 没放出去时边点边等能量的上限。
                                 # 【为什么是 2.3】: 强化重击的大招回收大头(7.47)
                                 # 挂在"爆炸"上, 而爆炸要等聚怪的 120F(2秒)走完才生成
    CIAC_FORTE_CAP = 1.60        # 攒一格回路的上限(A4-1 才给 核心1+1)
    CIAC_FORTE_CONFIRM = 0.25    # 只做确认时的上限(不补刀, 读不到也往下走)
    # 【长按左键预输入重击】(用户 2026-08-30): 空中出场技落地【之前】就按住,
    # 游戏会缓存这个输入, 一落地直接进重击 —— 比"等落地再按"快一整个落地硬直
    CIAC_FALL_A_SPAM = 0.30      # 回路不够时那一发下落攻击的连点窗口
    CIAC_HOLD_HEAVY_CAP = 2.20   # 按住等协奏涨的上限(涨了就提前松手)
    CIAC_HOLD_HEAVY_MIN = 0.85   # 这之前一律不判。帧表: 强化重击-地面 发生60F(1.0s)
                                 # 才出伤 —— 0.55 太早, 长按前半段的普攻就把判据顶了
    # 0.35 -> 0(用户 2026-08-29: "EQ 直接切风主")。
    # 【当初加这 0.35 秒的理由已经不成立了】: 那三轮 >Rov 跑满 2.5 秒超时, 根因是
    # 上游切人失败之后 self.cur 没对齐, 整段发在了错的人身上; 加了失败重对齐之后,
    # 实机这一格是 >Rov(0.06) —— 游戏并没有拒绝切人, 那 0.35 秒是白等的
    CIAC_Q_TO_SWITCH = 0.0

    # ==================== 各步的判据上限 ====================
    # 【启动轴收尾这一段整体是 2.1 秒】(视频量的: 按 R 切回小卡 -> 交棒给风主)。
    # 这条链上每一格都不许干站着 —— 加起来超了就是"小卡多A一轮、风主进场晚"
    # 1.60 -> 0.80 (用户 2026-08-29 量的: 这一格该缩短 0.80 秒)。
    # 【实机日志显示神权剑那个判据在这一格没生效】: 21:17 那轮是
    # 神权剑(cap,x12,absent1,1.61s) —— absent1 说明"剑不在"读到了(模板没坏),
    # 但整个窗口里一次都没读到"剑出现"。所以这一格现在【实际是纯计时】,
    # 交棒时刻 = O_CART_A_TO_SWITCH + CART_A4_SWORD_TO_SWITCH + 切人耗时。
    # 要快慢就调这两个数; 等哪天日志里出现 神权剑(出,...) 了再回来重估
    # 0.80 -> 0.90 (用户 2026-08-29: 这一格要慢 0.1 秒)。
    # 【加在这一段, 不加在 CART_A4_SWORD_TO_SWITCH】: 这 0.9 秒她是在连点普攻的,
    # 多给的时间会变成伤害, 而且离"真的打出 A4"更近一步; 那边那 0.45 秒是干站着
    O_CART_A_TO_SWITCH = 0.90

    # 【交棒给风主的窗口只有 0.32 秒】—— 见 switch_on_a4_launch 的说明。
    # 用户 2026-08-28 实测: 晚 0.53 秒风主出来就是站在地上, 整套空中连段打不出来。
    CART_A4_LAUNCH = 0.32        # A4-击飞 发生47F -> 结束66F, 她跟着一起浮空的那一段
    SWORD2_POLL_CAP = 1.60       # 只盯神权剑那一把的轮询上限
    # 【0.75 + 上半截模板是错的, 已回退】(2026-08-29 实机日志):
    # 那样匹的是【图标的空框】, 判据第一帧就成立 —— 日志里是 神权剑(出,x1,0.02s),
    # 只点了一下就交棒, A4 压根没打出去。这也是"加多少延迟都不见往后退"的根因:
    # 锚点本身钉死在一个固定的早点上, 后面加的秒数只是从那个错点往后挪。
    SWORD2_THRESHOLD = 0.85
    # 【必须先看到"剑不在"才认"剑出现"】: 上一把没消掉的剑会让判据一进来就成立。
    # 【还要压一个最短连点时间】: 从站桩到 A4 至少要走完 A1->A2->A3, 比这更早成立
    # 的一定是误判 —— 有这一条, 就算读图再出问题也不会退化成"点一下就切人"
    # 1.15 -> 0.50: 启动轴那一格的整个窗口才 0.80 秒, 门槛设在 1.15 等于
    # 把判据彻底关死。压到 0.50 只挡"点一下就成立"那种误判
    SWORD2_MIN_A = 0.50
    # 【看到剑之后再等这么久才发切人键】(用户 2026-08-29: 放低阈值之后反而快了 0.2 秒)。
    # 【要调时机就调这个, 别再动阈值】: 阈值改的是"图标画到几成算数", 跟时间不是线性的,
    # 调一次要重测一次; 这个是实打实的秒数, 加多少就晚多少。
    # 【这段不许点击】: 她正跟着 A4-击飞 浮在空中, 点一下就变成下落攻击, 把剑之影吃光
    # 一格一格试出来的: 0.20 -> 0.35 -> 0.45 (用户 2026-08-29)。
    # 【参考】帧表里 A4-击飞 是 47F 起、66F 结束(0.32 秒), 神权剑 45F 生成 ——
    # 0.45 已经越过那段的结束帧了, 说明她被击飞之后【还会继续滞空一会儿】,
    # 帧表上的"动作结束帧"不等于"落地"。这一格的真实上界只能实机试,
    # 判据是风主出来还在不在空中(看日志里 风主回路 满/未满)
    CART_A4_SWORD_TO_SWITCH = 0.45
    # 【还嫌晚的话就动这个】: 轮询跑过这么久之后, 一边等剑一边【提前发切人数字键】。
    # 游戏在角色动作期间会拒绝切人, 所以早按是安全的 —— 它会在游戏放行的第一帧
    # 生效, 而那一帧正好就是 A4 的派生/击飞。
    # 【代价】: 万一在 A4 之前就被放行, 这一圈的神权剑就没了(下一圈少一把剑)。
    # 所以默认关闭(-1), 要开就填个略小于"从起手到出剑"的秒数, 比如 0.9
    SWORD2_KEY_LEAD_AFTER = -1.0
    # 【已废弃】O_CON_WAIT / L_CON_WAIT: 原来在交棒前先等协奏满, 那 0.4~0.6 秒正好
    # 把上面这个窗口吃光。协奏改成【提前读好】再交棒(assume_con), 见 switch_on_a4_launch

    SWORD_WAIT_CAP = 3.00        # 等剑之影到位的上限, 到了就往下走, 不把轴卡死
    LIB_BIG_WAIT_CAP = 3.50      # 等芙露德莉斯决意满(lib_cartethyia_big 亮)的上限
    FORM_CONFIRM_CAP = 0.55      # 按完 R 之后确认形态真的变了的上限。
                                 # 【这一格不许干站着】: 它只是个确认, 读不到也照样往下走,
                                 # 所以等的期间要继续点普攻 —— 原来 1.2 秒纯发呆, 两次
                                 # 形态切换就白扔 2.4 秒, 表现出来就是风主进场晚了一轮
    FALL_READY_CAP = 1.00        # 起跳【之前】等"下落攻击可用"的上限(check_ready=True 时)
    CART_JUMP_TO_ATTACK = 0.10   # 起跳到按下落攻击的间隔。【别调大】: 用户的描述是
                                 # "跳跃再马上接一个下落攻击", 跳完等太久人就开始往下掉了
    CART_INTRO_SWORD_CAP = 0.20  # 入场后确认三把剑的上限。【给短】: 这一格不补普攻,
                                 # 等下去就是纯发呆, 读不到也照跳
    ROVER_FORTE_CAP = 2.50       # 等强化E 亮起的上限

    # ==================== 生命周期 ====================

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.opener_armed = True
        self.last_opener = -1
        self.macro_t0 = 0.0
        self.macro_marks = []
        self.cur = None              # 宏执行期间"现在场上是谁", 交接记账要用
        self.holding_attack = False  # 长按要跨过切人, 按下和松开不在同一个方法里
        self.poking = False          # 【持续普攻】总开关: 打开之后所有间隙自动变连点
        self.last_form_switch = -1   # 上一次按 R 切形态的时刻(形态切换有 1.5 秒 CD)
        self.lib_press_at = 0.0      # 最近一次按大招键的时刻, fire_lib 里落笔
        self.jump_count = 0          # 这一圈跳了几次(每次跳都记进时间轴)
        # 【风主上场时到底在不在天上】(用户 2026-08-30 指出):
        #   启动轴交棒过去 -> 他是站着的, 要自己 E 升空
        #   循环圈交棒过去 -> 已经在天上, 【直接 A】, 再等 E 那两下就是干卡一下
        # 两边走的都是 switch_on_a4_launch, has_intro 也都是 False, 分不出来 ——
        # 所以由交棒方自己在切之前打这个标记
        self.rover_needs_lift = True
        # 【这一圈是"启动轴带出来的第一圈"还是"循环圈"】(用户 2026-08-31: "你总是会把启动轴和循环轴搞混")。
        # 【为什么必须显式分开】: seg1/seg2 的代码两边【是共用的】, 而 rover_needs_lift 管的是
        # "风主要不要自己 E 升空", 语义不一样 —— 拿它当"第几圈"用迟早出错
        self.first_loop = True
        self._sword2_mat = None      # 神权剑图标的上半截模板(提前判据), 见 sword2_probe
        self._sword2_box = None

    def reset_state(self):
        super().reset_state()
        self.opener_armed = True
        self.cur = None
        self.poking = False
        self.last_form_switch = -1
        self.rover_needs_lift = True
        self.first_loop = True
        # 物理 F 键监视挂在 task 上, 每个 task 只启一次。放这里是因为 reset_state
        # 每次重读队伍都会跑, 而 __init__ 里设的字段会被 apply_team_char_classes 的
        # __dict__.update 打回内置值(线程是副作用, 不受影响)
        start_f_watch(self.task, self.logger)

    # ==================== 队伍判定 ====================

    @property
    def is_in_cart_cycle(self) -> bool:
        team_members = 0
        for char in self.task.chars:
            if char is not None and char.name in {'Ciaccona', 'Rover'}:
                team_members += 1
        return team_members == 2

    def teammate(self, name):
        for char in self.task.chars:
            if char is not None and char.name == name:
                return char
        return None

    def opener_pending(self):
        return self.opener_blocked_by() is None

    def opener_blocked_by(self):
        """启动轴不跑的原因; 返回 None 表示该跑。

        【这里不查任何"某个技能可用"】: BaseChar.available() 对场上/场下用的是两套
        机制 —— 场下读的是该角色【上次在场时 OCR 到的 CD 记录】, 而大招是能量门控、
        图标上没有 CD 数字, 场下那条路读的是残值。防重入靠 opener_armed +
        OPENER_MIN_GAP 就够。
        """
        if not self.is_in_cart_cycle:
            return 'team is not cartethyia/ciaccona/rover'
        if not self.opener_armed:
            return 'already armed-down (ran once this combat)'
        # 玩家按过 F 就当成"真的重开了一局"直接放行: 60 秒门槛分不清"战斗判定抖动"
        # 和"玩家重开副本", 而物理 F 键正好能分 —— 抖动不会有人按 F
        f_press = getattr(self.task, '_f_last_press', -1)
        if f_press > self.last_opener:
            waited = time.time() - f_press
            delay = f_settings(self.task)[1]
            if waited < delay:
                return f'F pressed {waited:.2f}s ago, waiting {delay:.2f}s for the mobs'
            return None
        if self.last_opener >= 0 and time.time() - self.last_opener < self.OPENER_MIN_GAP:
            return f'ran {time.time() - self.last_opener:.1f}s ago (< {self.OPENER_MIN_GAP:.0f}s)'
        if not self.task.use_liberation:
            return 'task.use_liberation is off'
        return None

    # ==================== 宏原语 ====================

    def macro_wait(self, sec):
        """精确等待, 【不点击】。

        不走 executor.sleep —— 它每 0.4 秒无条件插一次 next_frame 截图, 插入位置
        不可控, 而这条轴的容错在 ±0.1 秒级。
        """
        if sec <= 0:
            self.task.executor.check_enabled(check_pause=False)
            return
        end = time.time() + sec
        while True:
            left = end - time.time()
            if left <= 0:
                return
            time.sleep(min(0.1, left))
            self.task.executor.check_enabled(check_pause=False)

    def poll_wait(self, sec, tag=None):
        """等一段时间, 【不点击, 但一直刷新画面】。

        跟 macro_wait 的区别只有 next_frame: 纯 macro_wait 期间画面是冻的,
        战斗判定线程拿到的是旧帧, 容易误判 target lost(2026-08-30 实机在变奏入场
        那段静默期脱战过)。要"这段别出手"又不想让判定线程瞎, 就用这个。
        """
        start = time.time()
        while time.time() - start < sec:
            self.task.next_frame()
            self.macro_wait(0.02)
        if tag:
            self.macro_mark(f'{tag}({time.time() - start:.2f}s)')

    def macro_gap(self, sec, tag=None):
        """间隙。【持续普攻打开时自动变成连点】—— 这就是"我没说停就一直A"。"""
        if sec <= 0:
            return 0
        if not self.poking:
            self.macro_wait(sec)
            return 0
        return self.macro_spam(sec, self.A_INTERVAL, tag=tag or 'gapA')

    def macro_start(self):
        self.macro_t0 = time.time()
        self.macro_marks = []

    def macro_mark(self, name):
        self.macro_marks.append(f'{name}@{time.time() - self.macro_t0:.2f}')

    def macro_timeline(self, since=0):
        return ' '.join(self.macro_marks[since:])

    def macro_spam(self, window, interval=None, tag='A', max_clicks=None):
        """连点一个窗口。

        打出几段由 window 决定, 不由单次点击的时机决定 —— 动画期间的点击会被丢掉,
        连点保证总有一下落在动画刚结束的瞬间。

        【max_clicks 会提前结束整个窗口】: 循环条件是"窗口没到 and n 没到上限",
        所以封顶 2 下 + 间隔 0.12 = 0.24 秒就返回了, window 写多少都不生效。
        只在【空中】那几格用它(多余的点击会变成下落攻击), 用的时候记得窗口本身
        也要相应缩短。
        """
        interval = self.A_INTERVAL if interval is None else interval
        start = time.time()
        n = 0
        cap = int(window / max(interval, 0.01)) + 2
        max_clicks = cap if max_clicks is None else min(cap, max_clicks)
        self.macro_mark(f'{tag}_start')
        while time.time() - start < window and n < max_clicks:
            self.click()
            n += 1
            remaining = window - (time.time() - start)
            if remaining <= 0:
                break
            self.macro_wait(min(interval, remaining))
        self.macro_mark(f'{tag}_end(x{n})')
        return n

    def spam_f(self, window=None, tag='处决'):
        """发处决键, 【发的同时就在看它触发没有】。

        【为什么要合成一个循环】(用户 2026-08-30: "如果没有处决会a几下再RR,
        这里能不能优化一下检测"): 原来是"先发满 0.50 秒的 F, 再花 0.40 秒判有没有
        触发" —— 没处决的那些轮次白白占掉 0.90 秒。现在每发一次就读一帧,
        没触发就跑满 window(约 0.35 秒)、触发了立刻进演出等待。

        【绝对不调 f_break()】: 框架那个是阻塞的 —— 0.5 秒起步、最长 5 秒,
        期间还一直发左键(会打断长按、烧掉墙钟计时)。
        【触发了必须等演完】: 处决动画带全局时停, 不等的话后面每一格的固定时长
        都会被它整体推歪。
        """
        if not self.USE_F_BREAK:
            return 0
        window = self.F_BURST if window is None else window
        start = time.time()
        n = 0
        gone = False
        while time.time() - start < window:
            self.task.send_key('f', after_sleep=0)
            n += 1
            self.task.next_frame()
            if not self.task.in_team()[0]:
                gone = True
                break
            self.macro_wait(self.F_BURST_INTERVAL)
        self.macro_mark(f'{tag}(x{n},{"触发" if gone else "无"},'
                        f'{time.time() - start:.2f}s)')
        if gone:
            self.poke_until_hud_back(tag=f'{tag}Anim',
                                     time_out=self.F_ANIM_TIME_OUT,
                                     tail=self.F_ANIM_TAIL)
        return n

    def spam_then_hold(self, window, clicks, interval, tag='A'):
        """先点【固定几下】, 再把窗口剩下的时间等完(不再点)。

        【为什么不能用 macro_spam 连点】: 地面连段可以连点 —— 多出来的点击落在动画里
        被丢掉, 不花钱。【空中不行】: 空中连段只有 空中A1/空中A2 两段, 打完之后
        下一次点击就变成"空中普攻-下落", 人当场落地 —— 用户 2026-08-29 看到的
        "A4 还没出来就下落了" 就是这么来的。

        【为什么不能用 macro_spam(max_clicks=N)】: 那个参数会【提前结束整个窗口】,
        循环条件是"窗口没到 and n < 上限", 封顶四下就等于窗口只有四下的长度。

        【interval 取派生帧, 不是越密越好】: 点得比派生帧还快, 多出来的那几下并不会
        让连段推得更快(动画期间的输入被丢掉), 却会在段数用完之后立刻捅出下落攻击。
        所以这一格的"最快"就是【贴着派生帧点】。
        """
        start = time.time()
        n = 0
        self.macro_mark(f'{tag}_start')
        while n < clicks and time.time() - start < window:
            self.click()
            n += 1
            if n < clicks:
                self.macro_wait(min(interval, max(0.0, window - (time.time() - start))))
        self.macro_wait(max(0.0, window - (time.time() - start)))
        self.macro_mark(f'{tag}_end(x{n},{time.time() - start:.2f}s)')
        return n

    def segment_window(self, seg, n=1, lead=None):
        """n 段普攻要给多长的连点窗口。

        窗口 = (n-1) * 一段 + A_LEAD: 前 n-1 段各要等自己的动画走完, 最后一段只要
        【递出去】就行 —— 它的动画会在切人之后继续演(合轴), 所以不给它留时长,
        只留 A_LEAD 保证有一下落在能出招的第一帧。
        """
        return max(0.0, (n - 1) * seg) + (self.A_LEAD if lead is None else lead)

    def spam_segments(self, seg, n=1, tag='A', lead=None, interval=None, max_clicks=None):
        """打出 n 段普攻。【调用点写的是段数, 不是秒数】。"""
        return self.macro_spam(self.segment_window(seg, n, lead),
                               self.A_INTERVAL if interval is None else interval,
                               tag=f'{tag}[{n}seg]', max_clicks=max_clicks)

    def macro_key(self, key, settle=0.0, tag=None):
        self.task.send_key(key)
        self.macro_mark(tag or str(key))
        self.macro_gap(settle)

    def macro_hold_attack(self, hold, settle=0.0, tag='hold'):
        """长按左键(重击)。

        【长按期间绝对不要再 mouse_down() 补按】: PostMessage 后端每次 mouse_down
        都会走 try_activate() 投一条 WM_ACTIVATE, 窗口收到就会把已经按住的状态打断。
        一次 mouse_down 就一直有效, 包括跨过切人。
        """
        self.task.mouse_down()
        self.holding_attack = True
        self.macro_mark(f'{tag}_down')
        try:
            self.macro_wait(hold)
        finally:
            self.release_attack()
        self.macro_mark(f'{tag}_up')
        self.macro_gap(settle)

    def release_attack(self):
        if self.holding_attack:
            self.task.mouse_up()
            self.holding_attack = False

    def spam_key(self, send, window, interval=None, tag='key', poke=None, presses=None,
                 click_interval=None, stop_when=None):
        """在一个窗口里反复发同一个技能键, 用来盖住动画那一段。

        动画期间的按键是被丢掉的、不排队, 所以单发必丢, 症状统一是"那一步慢了"
        (要等整个动画演完才有第二次机会)。

        【必须在这个角色自己的回合里跑完, 不要跟切人并行】: 切人期间发出去的技能键会
        被游戏带过换人边界落在新角色身上。点击可以并行, 技能键不行。

        Args:
            presses: 只发这么多次, 均匀铺在窗口里。用在"连续点按两次"那种【次数本身
                有意义】的地方 —— 连发会把两发挤成一发。给了 presses 就由它说了算,
                window 只用来推间隔。
            stop_when: 每发一次之后调一次, 返回 True 就停。用在"多按一下会烧掉后面
                要用的充能"的地方。【会读屏, 别配太密的 interval】。
        """
        interval = self.KEY_INTERVAL if interval is None else interval
        poke = self.poking if poke is None else poke
        click_interval = self.A_INTERVAL if click_interval is None else click_interval
        if presses is not None and presses > 0:
            interval = max(interval, window / presses)
        start = time.time()
        n = 0
        clicks = 0
        next_click = 0.0
        while True:
            send()
            n += 1
            if stop_when is not None and stop_when():
                break
            if presses is not None:
                if n >= presses:
                    break
                left = interval
            else:
                left = window - (time.time() - start)
                if left <= 0:
                    break
            step_end = time.time() + min(interval, left)
            # 发键的节奏和点击的节奏各走各的: 挂在一起的话点击会被技能键的间隔卡住
            while True:
                now = time.time()
                if now >= step_end:
                    break
                if poke and now >= next_click:
                    self.click()
                    clicks += 1
                    next_click = now + click_interval
                self.macro_wait(min(0.02, step_end - time.time()))
        self.macro_mark(f'{tag}(x{n},A x{clicks})')
        return n

    # ==================== 直切 ====================

    def quick_switch(self, target, click_during=None, settle=None, time_out=None,
                     read_con=False, assume_con=False, click_interval=None,
                     click_first=0):
        """按数字键直切给指定角色。

        不走 switch_next_char(): 那个要先跑 _choose_switch_target 选人(顺序是框架
        说了算), 而且每次发数字键都跟一次左键, 想不要那下 A 就没法不要。

        Args:
            click_during: 等换人生效的这段时间里继续点。默认跟随持续普攻开关。
                这几下落在上一个角色身上, 正好把他最后那一段打出来。
                【角色在空中时必须传 False】—— 那时的点击会变成下落攻击。
            read_con: 按键之前读一次协奏, 决定要不要按"带变奏"记账。
                【不便宜】(能量环连通域分析, 睡完之后第一次读屏能到 0.86 秒),
                只有真的要变奏的那几处才传 True。
            assume_con: 不读屏, 直接按满协奏记。用在【刚放完大招】之后 ——
                那时协奏必满, 而演出期间能量环读数不可信。
            click_first: 先点几下再发第一个数字键。用在"边打A边切人"的格子上:
                游戏在角色动作期间会拒绝切人, 这正是那种写法不会掐掉 A 的原因。

        Returns: 是否真的切过去了。
        """
        if target is None:
            return False
        if target is self.cur:
            # 【必须早退】: 不早退的话到场判据立刻成立, 整步 50 毫秒走完,
            # 后面那些"给他的"按键其实发在了别人身上
            self.macro_mark(f'>{target.name[:3]}(already)')
            return True
        entry = time.time()
        time_out = self.SWITCH_TIME_OUT if time_out is None else time_out
        settle = self.SWITCH_SETTLE if settle is None else settle
        click_during = self.poking if click_during is None else click_during
        click_interval = self.A_INTERVAL if click_interval is None else click_interval
        source = self.cur if self.cur is not None else self
        slot = target.index + 1
        for i in range(int(click_first)):
            self.click()
            if i + 1 < int(click_first):
                self.macro_wait(click_interval)
        # 【第一个数字键要抢在读协奏之前发】: 读协奏夹在"上一个动作"和"数字键"之间
        # 就是纯延迟, 而切人本身要 0.06~0.11 才落地, 完全来得及在换人之前读完
        self.task.send_key(slot, down_time=self.SWITCH_KEY_DOWN_TIME)
        if assume_con:
            con_full = True
        elif read_con:
            con_full = bool(source.is_con_full())
        else:
            con_full = False
        return self._await_switch(target, source, slot, entry, time_out, settle,
                                  click_during, click_interval, con_full)

    def _await_switch(self, target, source, slot, entry, time_out, settle,
                      click_during, click_interval, con_full):
        """一直重发数字键直到 HUD 确认换人生效。quick_switch 的后半段。"""
        start = time.time()
        last = start          # 第一个数字键已经在调用方发过了
        next_click = 0.0
        trace = [] if self.TRACE_SWITCH else None
        team_size = len([c for c in self.task.chars if c is not None])
        untrusted_hits = 0
        clicks = 0
        while time.time() - start < time_out:
            now = time.time()
            if now - last >= self.SWITCH_KEY_INTERVAL:
                self.task.send_key(slot, down_time=self.SWITCH_KEY_DOWN_TIME)
                last = now
            # 点击的节奏跟切人键解耦: 切人键每轮都发, 点击照旧按 click_interval
            if click_during and now >= next_click:
                self.click()
                clicks += 1
                next_click = now + click_interval
            self.task.next_frame()
            in_team, index, count = self.task.in_team()
            # 【count 不达标的 index 打折扣, 但不能一票否决】: in_team() 在只找到
            # 一个槽位文本时照样返回 True 和一个 index; 一票否决会在槽位被特效盖住时
            # 造成假失败 —— 切人明明成功了也判不出来, 卡满超时, 整条轴从这里崩
            hit = in_team and index == target.index
            trusted = in_team and count >= team_size
            untrusted_hits = untrusted_hits + 1 if (hit and not trusted) else 0
            if trace is not None:
                trace.append(f'{time.time() - start:.2f}:'
                             f'{(index if trusted else f"?{index}") if in_team else "x"}')
            if hit and (trusted or untrusted_hits >= self.UNTRUSTED_CONFIRM):
                self.handoff(source, target, con_full)
                self.macro_mark(f'>{target.name[:3]}{"^" if con_full else ""}'
                                f'({time.time() - entry:.2f}|A x{clicks})')
                if trace:
                    self.logger.info(f'switch trace -> {target.name}: {" ".join(trace)}')
                self.macro_gap(settle)
                return True
        # 【失败时更要打 trace】: 一直是旧角色的 index -> 游戏真的在拒绝切人;
        # 带 ? 的都是目标 index -> 切过去了, 是 count 判据把它挡住了;
        # 全是 x -> HUD 整个不在(演出/时停里)
        self.logger.warning(f'switch to {target.name} slot {slot} timed out '
                            f'after {time_out:.1f}s (stuck in an animation?)'
                            + (f' trace: {" ".join(trace)}' if trace else ''))
        self.macro_mark(f'>{target.name[:3]}FAIL')
        # 【失败之后必须重新对齐"场上是谁"】(2026-08-29 实机日志):
        # 不对齐的话 self.cur 还指着目标角色, 后面整段都发在错的人身上 ——
        # 日志里 >RovFAIL 之后照样给风主发 E、打空中A、开大招, 而场上其实是夏空,
        # 于是 风主回路未满 / 风主R_NOFIRE 一连串全是假象, 查都没法查
        actual = self.on_field_char(time_out=0.5)
        if actual is not None and actual is not self.cur:
            self.macro_mark(f'resync>{actual.name[:3]}')
            self.cur = actual
        return False

    def handoff(self, from_char, to_char, con_full):
        """复刻 switch_next_char() 尾部那套交接记账。

        直接按数字键绕开了框架逻辑, 不补的话没人的 is_current_char 是 True,
        get_current_char() 返回 None, AutoCombatTask 主循环当场崩。
        """
        self.task.in_liberation = False
        from_char.switch_out(con_full=con_full)
        to_char.is_current_char = True
        to_char.has_intro = con_full
        to_char.has_sub_dps_intro = con_full and from_char.is_sub_dps
        to_char.last_switch_in_time = time.time()
        if con_full:
            now = time.time()
            self.task.add_freeze_duration(now, to_char.intro_motion_freeze_duration, -100)
            from_char.last_outro_time = now
        self.cur = to_char

    def switch_cd_left(self, char):
        """某个角色的换人 CD 还剩多久 —— 【只算不等】。

        【不读屏】: 头像上那个小数字是 OCR, 不便宜也不稳; 而 last_switch_time 是
        我们自己在 handoff -> switch_out 里落的笔, 免费且精确。
        """
        last = getattr(char, 'last_switch_time', -1)
        if last is None or last < 0:
            return 0.0
        return max(0.0, self.SWITCH_CD - (time.time() - last))

    def wait_switch_ready(self, char, tag='swCD', lead=0.0):
        """等某个角色的换人 CD 转好。

        Args:
            lead: 【提前这么多就返回】, 把剩下这段留给调用方拿去跟切人并行 ——
                quick_switch 本来就会一直重发数字键, 让它压着 CD 尾巴开始按,
                游戏 CD 一到那一帧就生效。
        """
        left = self.switch_cd_left(char)
        wait = left - lead
        if wait <= 0:
            self.macro_mark(f'{tag}(0.00|left{left:.2f})')
            return 0.0
        self.macro_gap(wait, tag=tag)
        self.macro_mark(f'{tag}({wait:.2f})')
        return wait

    def switch_out_while_key(self, target, source, key_send, click=True,
                             read_con=False, time_out=None, tag=None):
        """一边切人, 一边给【离场角色】补技能键 —— 键只在 HUD 还读得到他时才发。

        【为什么要那道门】: 切人期间发出去的技能键会被游戏【带过换人边界, 落在新上场
        的角色身上】—— 真同时发的话那一发会变成新角色放的, 白烧一个 CD。判据是
        "HUD 还显示离场角色在场 = 这一发还会落在他身上", 一从 HUD 上消失就停发。

        点击不受这道门约束 —— 点击落错人无所谓(顶多多推一段连段)。
        """
        if target is None:
            return False
        if target is self.cur:
            self.macro_mark(f'>{target.name[:3]}(already)')
            return True
        entry = time.time()
        time_out = self.SWITCH_TIME_OUT if time_out is None else time_out
        src = source if source is not None else (self.cur or self)
        slot = target.index + 1
        self.task.send_key(slot, down_time=self.SWITCH_KEY_DOWN_TIME)
        con_full = bool(src.is_con_full()) if read_con else False
        team_size = len([c for c in self.task.chars if c is not None])
        n_key = n_click = 0
        untrusted_hits = 0
        arrived = False
        next_click = 0.0
        while time.time() - entry < time_out:
            now = time.time()
            self.task.send_key(slot, down_time=self.SWITCH_KEY_DOWN_TIME)
            self.task.next_frame()
            in_team, index, count = self.task.in_team()
            if in_team and index == src.index:
                key_send()
                n_key += 1
            if click and now >= next_click:
                self.click()
                n_click += 1
                next_click = now + self.A_INTERVAL
            hit = in_team and index == target.index
            trusted = in_team and count >= team_size
            untrusted_hits = untrusted_hits + 1 if (hit and not trusted) else 0
            if hit and (trusted or untrusted_hits >= self.UNTRUSTED_CONFIRM):
                arrived = True
                break
        label = tag or f'>{target.name[:3]}+key'
        if arrived:
            self.handoff(src, target, con_full)
            self.macro_mark(f'{label}{"^" if con_full else ""}'
                            f'({time.time() - entry:.2f}|key x{n_key},A x{n_click})')
        else:
            self.logger.warning(f'switch_out_while_key: {target.name} never came in '
                                f'({n_key} keys, {n_click} clicks)')
            self.macro_mark(f'{label}FAIL(x{n_key})')
        return arrived

    # ==================== 大招 ====================

    def fire_lib(self, char, tag='R', window=None):
        """把大招发出去。判据是【队伍 HUD 掉下去 = 演出开始】。

        不用 click_liberation(): 它一路阻塞到演出结束才返回, 而这条轴上好几处要在
        演出【期间】继续做事(连点、连发 E、切人)。

        【发键之前不读屏确认可放】: 那次读屏是纯延迟; 而且它并不能替我们做决定 ——
        读到不可用我们照样要发。可用性只在失败分支里读一次, 用来分辨"能量不够"和
        "键被动画吞了"。
        """
        window = self.LIB_FIRE_WINDOW if window is None else window
        start = time.time()
        self.lib_press_at = start
        n = 0
        while time.time() - start < window:
            # 【先发键再读屏】: 原来是"读一帧 -> 判HUD -> 才发R", 于是每次放大招前
            # 都白读一次屏。多发的那一下不会有副作用 —— 演出期间的按键被丢掉、不排队
            char.send_liberation_key()
            n += 1
            if n % self.LIB_READ_EVERY == 0:
                self.task.next_frame()
                if not self.task.in_team()[0]:
                    char.record_liberation_use()
                    self.macro_mark(f'{tag}_fired(x{n})')
                    return True
            self.sleep(self.LIB_KEY_INTERVAL, check_combat=False)
        self.task.next_frame()
        if not self.task.in_team()[0]:
            char.record_liberation_use()
            self.macro_mark(f'{tag}_fired(x{n})')
            return True
        self.macro_mark(f'{tag}_NOFIRE(x{n})')
        try:
            lit = bool(char.liberation_available())
        except Exception:
            lit = 'err'
        self.logger.warning(f'{tag}: {char.name} liberation never started an animation '
                            f'after {n} presses (icon lit={lit})')
        return False

    def poke_until_hud_back(self, tag='anim', time_out=None, tail=None):
        """演出期间一直点普攻, 等队伍 HUD 回来(演出结束)再往下走。

        【为什么点】: 演出结束的第一帧就要有输入落进去, 而演出期间的点击是被丢掉的、
        不排队 —— 连点免疫被吞, 单发要么埋在演出里要么等太久。
        【为什么还要 tail】: HUD 回来那一刻角色多半还在收招里, 那几下照样被吞。

        【"HUD 回来"要先确认它消失过】: 进来的这一刻画面还在渐变, 读一帧很可能读回
        True, 那就是"演出刚开头就判成结束"。所以要么先看到它真的消失过, 要么连着
        HUD_NO_ANIM_GRACE 秒都读到在场(说明这一次压根没有演出)。
        """
        time_out = self.LIB_ANIM_TIME_OUT if time_out is None else time_out
        tail = self.LIB_ANIM_TAIL if tail is None else tail
        start = time.time()
        n = 0
        gone_seen = False
        back = False
        next_click = 0.0
        while time.time() - start < time_out:
            now = time.time()
            if now >= next_click:
                self.click()
                n += 1
                next_click = now + self.A_INTERVAL
            self.task.next_frame()
            if not self.task.in_team()[0]:
                gone_seen = True
            elif gone_seen or time.time() - start >= self.HUD_NO_ANIM_GRACE:
                back = True
                break
            self.macro_wait(0.01)
        # 演出这一段计入 freeze, 否则框架的 time_elapsed_accounting_for_freeze
        # 会把它算成"这个角色磨蹭了 5 秒"
        self.add_freeze_duration(start, time.time() - start)
        self.macro_mark(f'{tag}({"ok" if back else "timeout"},'
                        f'{"anim" if gone_seen else "NOANIM"},x{n},'
                        f'{time.time() - start:.2f}s)')
        if tail > 0:
            self.macro_spam(tail, self.A_INTERVAL, tag=f'{tag}Tail')
        return back

    def spam_key_through_lib(self, send, tag='key', time_out=None, tail=None, poke=None):
        """演出期间一直发某个技能键, 发到【演出真的结束】(HUD 回来)再补一小段。

        【为什么不能按固定时长】: 大招哪一刻出手是浮动的 —— 早出手时演出早结束,
        固定窗口的尾巴白发; 晚出手时演出还没完窗口就停了, 那些键一发都没进去
        (症状是"R完不接E")。
        """
        time_out = self.LIB_ANIM_TIME_OUT if time_out is None else time_out
        tail = self.LIB_ANIM_TAIL if tail is None else tail
        poke = self.poking if poke is None else poke
        start = time.time()
        n = 0
        gone_seen = False
        back_at = None
        next_click = 0.0
        while time.time() - start < time_out:
            send()
            n += 1
            now = time.time()
            if poke and now >= next_click:
                self.click()
                next_click = now + self.A_INTERVAL
            self.task.next_frame()
            on_hud = self.task.in_team()[0]
            if not on_hud:
                gone_seen = True
                back_at = None
            elif back_at is None:
                if gone_seen or time.time() - start >= self.HUD_NO_ANIM_GRACE:
                    back_at = time.time()
            elif time.time() - back_at >= tail:
                break
            # 【必须 check_combat=False】: 演出期间读不到目标, 默认的 sleep 会跑
            # 战斗判定并抛异常, 整个连发在第一轮就被打断、接着判脱战
            self.sleep(self.KEY_INTERVAL, check_combat=False)
        self.add_freeze_duration(start, time.time() - start)
        self.macro_mark(f'{tag}(x{n},{"ok" if back_at else "timeout"},'
                        f'{"anim" if gone_seen else "NOANIM"},{time.time() - start:.2f}s)')
        return back_at is not None

    # ==================== 变奏(等协奏) ====================

    def hold_until_heavy_fired(self, ciac, cap=None, min_wait=None,
                               tag='预输入重击'):
        """【按住左键】等强化重击真的打出去, 打出去就松手(好让 R 立刻打断收招)。

        【主判据是"回路被消耗"】(用户 2026-08-30: "重击没打完, 协奏还没长上就R了"):
        强化重击吃掉 3 格回路(帧表: 强化重击-地面 核心回收1 = -3), 所以回路从 3 掉下来
        这件事【干净、不会被读数噪声骗到】。
        协奏上涨那条以前是主判据, 但长按左键会【先打出几下普攻再蓄力】, 那几下普攻
        每下涨 0.02~0.03, 攒两三下就够触发 0.08 的阈值 —— 于是重击还没出手就 R 了。
        现在协奏只当【备用】判据, 而且阈值抬到 CON_RISE_THRESHOLD。

        【基线在按下之前读】: 按住之后再读, 基线里已经含了这一下的收益, 永远判不出变化。
        """
        cap = self.CIAC_HOLD_HEAVY_CAP if cap is None else cap
        min_wait = self.CIAC_HOLD_HEAVY_MIN if min_wait is None else min_wait
        forte_base = self.ciac_forte(ciac)
        try:
            con_base = ciac.get_current_con()
        except Exception:
            con_base = 0.0
        self.task.mouse_down()
        self.holding_attack = True
        self.macro_mark(f'{tag}_down(回路{forte_base})')
        start = time.time()
        why = 'cap'
        try:
            if min_wait > 0:
                self.macro_wait(min_wait)
            while time.time() - start < cap:
                self.task.next_frame()
                if self.ciac_forte(ciac) < forte_base:
                    why = '回路掉'
                    break
                try:
                    if ciac.get_current_con() - con_base >= self.CON_RISE_THRESHOLD:
                        why = 'con涨'
                        break
                except Exception:
                    pass
        finally:
            self.release_attack()
        self.macro_mark(f'{tag}_up({why},{time.time() - start:.2f}s)')
        return why != 'cap'

    def wait_con_rise(self, char, cap, base=None, rise=None, min_wait=0.0,
                      tag='con涨'):
        """盯着协奏圈, 一涨就返回。

        【为什么用"涨"而不是"满"或固定时长】(用户 2026-08-29 提的这一格):
        这里要的信号是"刚才那一下【结算了】"—— 而协奏是【打中才涨】的, 所以它一跳
        就是结算完成的那一刻。夏空的强化重击 协奏回收25, 一跳就是一大格, 很好认。
        后面那段收招没有伤害, R 打断它纯赚。

        Args:
            base: 基线。【要在动作起手【之前】读】—— 动作跑完再读的话基线里已经
                含了这一下的收益, 永远检测不到"上涨"。
            rise: 涨多少才算数。【别设太小】(用户 2026-08-30: "协奏值还没变呢你就R了"):
                协奏读数是能量环的连通域分析, 本身每帧抖几个千分点, 0.02 会被噪声
                直接触发。强化重击一下给 25 点(=0.25), 阈值放到 0.08 都绰绰有余。
            min_wait: 这之前一律不判。【为什么需要】: 帧表里夏空 强化重击-地面
                【发生60F】(1.0 秒)才出伤, 而 heavy_click_forte 的判据是"准星旁的
                强化重击标记消失", 那个掉得比出伤早得多 —— 它一返回就开始判的话,
                等于在重击还没打出来的时候等一个永远不会来的上涨, 然后噪声一抖就 R 了。
        """
        rise = self.CON_RISE_THRESHOLD if rise is None else rise
        start = time.time()
        if min_wait > 0:
            self.macro_wait(min_wait)
        if base is None:
            try:
                base = char.get_current_con()
            except Exception:
                base = 0.0
        got = False
        now_v = base
        while time.time() - start < cap:
            try:
                now_v = char.get_current_con()
            except Exception:
                pass
            if now_v - base >= rise:
                got = True
                break
            self.macro_wait(self.CON_POLL_INTERVAL)
        self.macro_mark(f'{tag}({base:.2f}->{now_v:.2f},'
                        f'{"涨" if got else "cap"},{time.time() - start:.2f}s)')
        return got

    def wait_con_for_intro(self, char, next_name, poke=True, time_out=None,
                           stall_give_up=None):
        """等协奏结算到满再交棒 —— 满协奏离场, 下一个人才有变奏入场。

        伤害打中和协奏涨上去之间有延迟, 打完立刻切就没有变奏。
        【协奏必须打中才涨】, 所以这里等不到就往上游找哪笔伤害打空了, 而不是加大超时。

        Args:
            poke: 等的期间补不补普攻。【角色在空中时必须传 False】,
                那时的点击会变成下落攻击。
        """
        start = time.time()
        samples = []
        full = False
        stalled_at = None
        stalled_since = start
        next_click = 0.0
        time_out = self.CON_WAIT_TIME_OUT if time_out is None else time_out
        stall_give_up = (self.CON_STALL_GIVE_UP if stall_give_up is None
                         else stall_give_up)
        while time.time() - start < time_out:
            con = char.get_current_con()
            if len(samples) < self.CON_SAMPLE_MAX:
                samples.append(f'{time.time() - start:.2f}:{con:.2f}')
            if con >= self.CON_ENOUGH:
                full = True
                break
            # 【读数一动不动就别等满超时了】。阈值不能太小 —— 协奏会在 0.99 上卡一下
            if stalled_at is None or abs(con - stalled_at) > 0.005:
                stalled_at = con
                stalled_since = time.time()
            elif time.time() - stalled_since >= stall_give_up:
                self.macro_mark(f'con(stalled@{con:.2f})')
                return False
            now = time.time()
            if poke and now >= next_click:
                self.click()
                next_click = now + self.A_INTERVAL
            self.macro_wait(self.CON_POLL_INTERVAL)
        self.macro_mark(f'con({"full" if full else "timeout"})')
        # 轨迹是判断"上一下打没打中"的唯一手段: 一跳到顶 = 打中了, 这段等待是伤害
        # 飞行时间; 一路慢爬 = 那一下打空了, 协奏是补刀的普攻蹭上去的
        self.logger.info(f'{char.name} con {" ".join(samples)} '
                         f'{"(full)" if full else f"(never filled, {next_name} gets no intro)"}')
        return bool(full)

    # ==================== 场上是谁 ====================

    FIELD_SETTLE_TIME_OUT = 1.5

    def on_field_char(self, time_out=None):
        """现在场上是谁 —— 【只在拿不到入口角色时才用】, 因为它开局会说谎。

        in_team() 的判据是"哪个槽位的名字文本【找不到】, 谁就在场"。战斗刚开始时
        队伍 HUD 还在渐入, 三个槽位的文本不是同时出现的 —— 这时它只找到一个文本,
        但那个分支照样返回 True 和一个 index, 而那个 index 只是渲染顺序的产物。
        可信判据是 count >= 队伍人数。
        """
        time_out = self.FIELD_SETTLE_TIME_OUT if time_out is None else time_out
        expected = len([c for c in self.task.chars if c is not None])
        end = time.time() + time_out
        while True:
            self.task.next_frame()   # in_team() 读的是缓存帧, 不刷就是反复读同一张图
            in_team, index, count = self.task.in_team()
            if in_team and count >= expected:
                for char in self.task.chars:
                    if char is not None and char.index == index:
                        return char
                return None
            if time.time() >= end:
                self.logger.warning(f'team HUD never settled in {time_out:.1f}s '
                                    f'(in_team={in_team} index={index} count={count})')
                return None
            self.macro_wait(0.03)

    # ==================== 卡提希娅: 剑之影 / 形态 / 下落 ====================

    def sword_count(self):
        """场上有几把剑之影。读的是原版的三个模板:
        sword1=重击给的异权剑, sword2=A4 给的神权剑, sword3=E 给的人权剑。
        """
        try:
            return sum(1 for v in self.get_sword_buffs().values() if v)
        except Exception:
            return 0

    def wait_swords(self, want, cap=None, tag='sword', poke=True, interval=None):
        """边点普攻边等剑之影攒到 want 把, 到了立刻返回。

        【这一格必须读屏】: 一把剑什么时候生成跟连段推到第几段有关, 而连段推进的
        速度每轮都在变(被打断、位移、怪站位)。按时间放会出现"剑没齐就去下落",
        下落那一下要吃掉 3 把剑, 少一把整轮的剑效果就废了。
        """
        cap = self.SWORD_WAIT_CAP if cap is None else cap
        interval = self.A_INTERVAL if interval is None else interval
        start = time.time()
        n = 0
        next_click = 0.0
        got = self.sword_count()
        while got < want and time.time() - start < cap:
            now = time.time()
            if poke and now >= next_click:
                self.click()
                n += 1
                next_click = now + interval
            self.task.next_frame()
            got = self.sword_count()
        self.macro_mark(f'{tag}({got}/{want},x{n},{time.time() - start:.2f}s)')
        return got >= want

    def init_template(self):
        """跟着原版一起重建模板缓存 —— 分辨率一变原版会重跑这个方法。"""
        super().init_template()
        self._sword2_mat = None
        self._sword2_box = None

    def sword2_probe(self):
        """神权剑的【提前判据】: 只匹图标上半截, 阈值也放低。

        【为什么不用整张图 + 0.9】: 图标是渐显的, 匹到 0.9 要等它完全画完,
        而 A4-击飞 的浮空窗口只有 47F~66F 这 19 帧 —— 等画完人已经落地了。
        原版 acquire_missing_buffs 对同一把剑用的也是"上半截 + 0.85", 同一个道理。

        【自己新建 Box, 不要改 get_box_by_name 拿到的那个】: 它是 FeatureSet.box_dict
        里的共享对象, 改 .height 会污染全局(原版对 sword3 就是这么干的)。
        """
        if self._sword2_mat is None:
            feature = self.task.get_feature_by_name('forte_cartethyia_sword2')
            mat = feature.mat
            h = mat.shape[0]
            self._sword2_mat = mat[:int(h * 0.5)]
            box = self.task.get_box_by_name('forte_cartethyia_sword2')
            self._sword2_box = Box(box.x, box.y, box.width, int(h * 0.6),
                                   name='forte_cartethyia_sword2_top')
        return bool(self.task.find_one('forte_cartethyia_sword2',
                                       threshold=self.SWORD2_THRESHOLD))

    def wait_sword2(self, cap=None, tag='神权剑', poke=True, key_slot=None,
                    key_after=None, min_a=None):
        """只盯 A4 给的那把神权剑亮起来, 亮了立刻返回。

        【不走 get_sword_buffs()】: 那个一次要做三次模板匹配, 而下一格的窗口只有
        0.32 秒 —— 多出来的两次匹配就是纯延迟, 直接把交棒推到她落地之后。
        """
        cap = self.SWORD2_POLL_CAP if cap is None else cap
        key_after = self.SWORD2_KEY_LEAD_AFTER if key_after is None else key_after
        min_a = self.SWORD2_MIN_A if min_a is None else min_a
        start = time.time()
        n = 0
        keys = 0
        got = False
        absent_seen = False
        next_click = 0.0
        while time.time() - start < cap:
            now = time.time()
            if poke and now >= next_click:
                self.click()
                n += 1
                next_click = now + self.A_INTERVAL
            # 提前发切人键(默认关闭), 见 SWORD2_KEY_LEAD_AFTER
            if key_slot is not None and key_after >= 0 and now - start >= key_after:
                self.task.send_key(key_slot, down_time=self.SWITCH_KEY_DOWN_TIME)
                keys += 1
            self.task.next_frame()
            if not self.sword2_probe():
                # 先确认它【不在】, 再等它出现 —— 少了这一步, 上一把没消掉的剑
                # 会让整格在第一帧就成立
                absent_seen = True
            elif absent_seen and now - start >= min_a:
                got = True
                break
        # absent=0 就是【读图坏了】: 一次都没读到"剑不在", 说明模板匹配的是空框
        self.macro_mark(f'{tag}({"出" if got else "cap"},x{n},absent{1 if absent_seen else 0}'
                        + (f',key x{keys}' if keys else '')
                        + f',{time.time() - start:.2f}s)')
        return got

    def switch_on_a4_launch(self, target, cap=None, tag='A4交棒'):
        """在 A4 打出神权剑的同一瞬间交棒 —— 【必须抢在小卡落地之前】。

        帧表: A4-神权剑 发生45F, 紧接着 A4-击飞 47F 起跳、结束66F ——
        小卡跟着这一下击飞一起浮空, 留给交棒的窗口只有 19 帧(0.32 秒)。
        接手的角色【继承浮空状态】, 风主在空中才打得出空中普攻
        (空中A1/A2 各给 25 点核心回收1, 强化E 那 60 点充能全靠它);
        落地之后再切, 他出来就是站在地上, 这一整套空中连段直接没了。
        用户 2026-08-28 实测: 晚 0.53 秒就已经打不出来。

        所以【从"读到剑"到"发数字键"之间一格都不许插】:
        - 不等协奏: 协奏在进这一格之前就读好, 按 assume_con 记账。原来那句
          wait_con_for_intro 要 0.4~0.6 秒, 正好把整个窗口吃光。
        - quick_switch 不传 read_con: 读协奏是能量环的连通域分析, 睡完之后的第一次
          读屏实测能到 0.86 秒, 夹在数字键和重发之间就是灾难。
        - 切人期间不点普攻: 浮空时的点击会变成下落攻击, 反而把刚打出来的剑之影吃掉。
        """
        # 【提前读协奏】: 这一读放在剑出来【之前】, 那时还有的是时间。
        # 启动轴这一格实测是攒不满的(变身只给 20 点协奏回收), 风主拿不到变奏入场 ——
        # 但浮空是继承来的, 跟有没有变奏无关, 空中连段照样打得出来
        con_full = False
        try:
            con_full = bool(self.is_con_full())
        except Exception:
            pass
        self.macro_mark(f'con^{1 if con_full else 0}')
        self.wait_sword2(cap=cap, key_slot=target.index + 1)
        self.macro_wait(self.CART_A4_SWORD_TO_SWITCH)
        return self.quick_switch(target, assume_con=con_full, click_during=False)

    def wait_form(self, small, cap=None, tag='form'):
        """确认形态真的切过去了。small=True 等小卡, False 等芙露德莉斯。

        【要先确认它是另一个形态】的道理这里不适用 —— is_small() 读的是决意条上
        那把剑的模板, 两个形态互斥, 直接判目标态就行。读不到就是没切成。
        """
        cap = self.FORM_CONFIRM_CAP if cap is None else cap
        start = time.time()
        ok = False
        next_click = 0.0
        while time.time() - start < cap:
            # 【边点边等】: 这只是一次确认, 读不到也照样往下走 —— 干站着等的话
            # 这一格的时间就是纯亏的, 而点击正好把形态切换的那一段连段推下去
            now = time.time()
            if now >= next_click:
                self.click()
                next_click = now + self.A_INTERVAL
            self.task.next_frame()
            if bool(self.is_small()) == bool(small):
                ok = True
                break
        self.macro_mark(f'{tag}({"小卡" if small else "芙"}'
                        f'{"" if ok else "FAIL"},{time.time() - start:.2f}s)')
        if not ok:
            self.logger.warning(f'form switch to {"cartethyia" if small else "fleurdelys"} '
                                f'never showed up in {cap:.1f}s')
        return ok

    def press_r_form(self, to_fleur, tag=None):
        """按 R 切形态。

        R 在这个角色身上有四种含义, 由游戏自己判:
          小卡 + 没有显化状态 + 大招能量满 -> 变身(长演出, 隐藏HUD 203F, 顺手清空剑之影)
          小卡 + 显化状态中               -> 直接切芙(短, 走芙的 A2, 派生46F)
          芙   + 决意 < 120               -> 切回小卡(短, 走卡提的 A2, 派生46F)
          芙   + 决意 >= 120              -> 芙露德莉斯大招(见 fire_fleur_lib)
        这里只负责【前三种】: 发一次 R, 然后看 HUD 掉没掉下去 ——
        掉了就是变身那条长路, 交给 poke_until_hud_back 等演出; 没掉就是短切换,
        按帧表的派生帧等一下就行。

        【形态切换有 1.5 秒冷却】(帧表备注), 两次 R 挨太近第二发会被吞。
        """
        tag = tag or ('R>芙' if to_fleur else 'R>小卡')
        left = self.CART_FORM_CD - (time.time() - self.last_form_switch) \
            if self.last_form_switch > 0 else 0
        if left > 0:
            self.macro_gap(left, tag='formCD')
        self.send_liberation_key()
        self.last_form_switch = time.time()
        self.macro_mark(tag)
        # 变身那条路 HUD 会掉下去。给 0.5 秒判定窗口: 短切换不会掉, 白等的这半秒
        # 正好是 A2 的派生时间, 不浪费
        start = time.time()
        long_anim = False
        while time.time() - start < 0.5:
            self.task.next_frame()
            if not self.task.in_team()[0]:
                long_anim = True
                break
            self.click()
            self.macro_wait(0.02)
        if long_anim:
            # 走到这里说明这一发 R 是【要能量的变身】而不是免费的形态切换 ——
            # 稳态下每圈都该在"切大卡"这一格看到它, 看不到就是上一圈的显化还没耗完
            self.macro_mark(f'{tag}_transform')
            self.poke_until_hud_back(tag='transformAnim',
                                     time_out=self.CART_TRANSFORM_ANIM + 3)
            self.record_liberation_use()
        else:
            # 【这一段要继续点】: 形态切换本身就是一套 A2, 点击是在把连段往下推
            # (小卡这边正好推到 A3->A4 出神权剑)。原来走 macro_gap, 持续普攻没开时
            # 就是干站着 —— 那是"风主进场晚"的一部分
            self.macro_spam(max(0.0, (self.FLEUR_FORM_IN if to_fleur else self.CART_FORM_IN)
                                - (time.time() - start)),
                            self.A_INTERVAL, tag=f'{tag}A')
        return self.wait_form(small=not to_fleur)

    def fleur_ee_done(self):
        """芙的两发 E 是不是都放出去了 —— 判据是共鸣图标的读数。

        芙的 E 是【两格充能】: 两格都用掉之后图标进 CD, 白色读数明显变高。
        【阈值要实机标定】: 日志里每轮都会打一条 芙E充能X.XX, 那就是当轮的读数,
        对着它调 FLEUR_EE_DONE。读不准的话这个判据只是不生效(连发跑满窗口),
        不会误伤 —— E 落在没充能上就是空操作。
        """
        try:
            self.task.next_frame()
            return self.current_resonance() >= self.FLEUR_EE_DONE
        except Exception:
            return False

    def wait_lib_big(self, cap=None, tag='决意'):
        """边点普攻边等芙露德莉斯的决意攒满(大招图标换成 lib_cartethyia_big)。

        【这一格必须读屏】: 决意是芙形态所有动作按各自的"核心回收1"往上加的, 一段
        普攻给多少跟打出的是第几段有关, 算不准。而图标一换就是 100% 确定能放。
        """
        cap = self.LIB_BIG_WAIT_CAP if cap is None else cap
        start = time.time()
        n = 0
        ready = False
        next_click = 0.0
        while time.time() - start < cap:
            now = time.time()
            if now >= next_click:
                self.click()
                n += 1
                next_click = now + self.A_INTERVAL
            self.task.next_frame()
            if self.is_lib_big_available():
                ready = True
                break
        self.macro_mark(f'{tag}({"满" if ready else "cap"},x{n},{time.time() - start:.2f}s)')
        return ready

    def fire_fleur_lib(self, tag='R芙大招'):
        """芙露德莉斯大招。放完人会变回小卡、显化状态解除、决意清空。

        【必须等演出结束再交棒】: 演出期间 has_target() 读不到目标, 控制权一还回去
        就判 target lost -> 脱战 -> 重进战斗 -> 启动轴又跑一遍。
        """
        ok = self.fire_lib(self, tag=tag)
        self.poke_until_hud_back(tag='芙大招Anim', time_out=self.FLEUR_LIB_ANIM + 4)
        # 大招也占形态切换的冷却, 同样从按键那一刻起算
        self.last_form_switch = self.lib_press_at
        self.is_cartethyia = True
        return ok

    def fall_attack(self, tag='下落', jump_window=None, air_clicks=2,
                    check_ready=True):
        """跳 + 空中普攻 = 空中攻击-下落。三把剑之影在这里转成剑效果。

        帧表: 空中攻击-下落 第9F"获得未激活的剑效果、移除所有剑之影", 结束32F;
        落地那一下 派生18F —— 【所以落地后 0.3 秒就能接下一步, 不用等 50F 演完】。

        【空中的点击要封顶】: 多点几下会打出多余的空中攻击, 把落地时机推后。
        跳跃键同理, 连发会一直往上飞。
        """
        jump_window = self.CART_LAND_DERIVE if jump_window is None else jump_window
        # 【先刷新形态标志】: 原版 is_mid_air_attack_available() 第一行就是
        # `if self.is_cartethyia`, 这个字段只有 is_small() 会更新 —— 不刷的话
        # 拿到的是上一次读到的值, 芙形态的残值会让判据恒为 None, 这一格就白跳
        self.task.next_frame()
        self.is_small()
        start = time.time()
        # 先确认下落攻击真的可用(原版读的是决意条里那格白底), 不可用就别跳 ——
        # 白跳一次不但没伤害, 落地还要重新起连段。
        # 【check_ready=False 的用法】: 调用方刚用 wait_swords 确认过三把剑, 这道
        # 轮询就是纯延迟。变奏入场那一格要的是"入场 -> 跳 -> 马上下落攻击",
        # 中间插一秒读屏的话跳跃就不是接着入场了
        ready = not check_ready
        while check_ready and time.time() - start < self.FALL_READY_CAP:
            self.task.next_frame()
            if self.is_mid_air_attack_available():
                ready = True
                break
            self.click()
            self.macro_wait(0.03)
        self.jump_once(tag=f'{tag}_jump({"ready" if ready else "notready"})',
                       after_sleep=self.CART_JUMP_TO_ATTACK)
        # 空中这几下就是下落攻击本体, 封顶 2 下
        self.macro_spam(0.30, self.A_INTERVAL_FAST, tag=f'{tag}A', max_clicks=air_clicks)
        self.macro_wait(self.CART_FALL_TO_LAND)
        self.macro_mark(f'{tag}_land')
        return ready

    # ==================== 夏空 / 风主的读屏判据 ====================

    def ciac_forte(self, ciac):
        """夏空手上有几格回路(0~3)。走原版的 judge_forte(): 满了走 is_mouse_forte_full,
        没满走那条能量条的频谱判据。3 格才放得出强化重击。
        """
        try:
            return int(ciac.judge_forte())
        except Exception:
            return 0

    def wait_ciac_forte(self, ciac, want, cap=None, tag='回路', poke=True):
        """边点普攻边等夏空的回路涨到 want 格。

        回路只有 A4 和变奏入场给(各 +1), 所以"攒一格"实际是【把连段推到第四段】——
        推到第几段每轮都在飘, 只能读屏。
        """
        cap = self.CIAC_FORTE_CAP if cap is None else cap
        start = time.time()
        n = 0
        next_click = 0.0
        got = self.ciac_forte(ciac)
        while got < want and time.time() - start < cap:
            now = time.time()
            if poke and now >= next_click:
                self.click()
                n += 1
                next_click = now + self.A_INTERVAL
            self.task.next_frame()
            got = self.ciac_forte(ciac)
        self.macro_mark(f'{tag}({got}/{want},x{n},{time.time() - start:.2f}s)')
        return got >= want

    def wait_rover_forte(self, rover, cap=None, tag='强化E', poke=True):
        """边点普攻边等风主的强化E 亮起。

        【不能按时间放 E】: 早按一点出来的就是普通 E, 这一格的 20 点大招回收和
        20 点协奏回收就没了。判据用原版的 is_forte_full()。
        """
        cap = self.ROVER_FORTE_CAP if cap is None else cap
        start = time.time()
        n = 0
        lit = False
        next_click = 0.0
        # 【先读一次再决定点不点】(同"协奏满了还A几下"那条): 强化E 本来就亮着的话,
        # 一下都不该点 —— 原来循环是"先 click 再判", 每次都白打一下
        try:
            self.task.next_frame()
            lit = bool(rover.is_forte_full())
        except Exception:
            pass
        while not lit and time.time() - start < cap:
            now = time.time()
            if poke and now >= next_click:
                self.click()
                n += 1
                next_click = now + self.A_INTERVAL
            self.task.next_frame()
            try:
                if rover.is_forte_full():
                    lit = True
                    break
            except Exception:
                pass
        self.macro_mark(f'{tag}({"lit" if lit else "cap"},x{n},{time.time() - start:.2f}s)')
        return lit

    # ==================== 启动轴 ====================

    def perform_opener(self, entry_char=None):
        """启动轴: R 变身 -> R 切回小卡 -> 平A 出神权剑 -> 变奏风主。

        【开局那两发 R 是在存显化状态】: 卡提的大招给 12 秒显化(帧表: 大招-前置
        第154F获得12秒显化状态), 而显化计时在小卡形态下【是暂停的】(帧表:
        "显化状态期间切换至卡提希娅, 暂停显化状态计时")。所以变身完立刻切回小卡,
        这 12 秒原封不动留到循环轴里"切大卡"的时候用 —— 那一发 R 就变成免费的
        形态切换而不是要能量的变身。

        Args:
            entry_char: 调用方自己 —— 框架就是因为他在场才调的 do_perform,
                所以这是"现在场上是谁"最便宜也最可靠的答案。
                【不能让它去读屏判断】: in_team() 在战斗开局的头 0.8 秒会说谎。
        """
        ciac = self.teammate('Ciaccona')
        rover = self.teammate('Rover')
        if ciac is None or rover is None:
            return False

        # 整段关掉脱战判定: 高频切人时 HUD 反复消失(大招演出), 战斗判定线程一误报
        # 就抛 NotInCombatException, 宏从中间断掉比打歪严重得多
        previous = getattr(self.task, 'skip_combat_check', False)
        self.task.skip_combat_check = True
        self.cur = entry_char or self
        self.poking = False
        try:
            self.macro_start()
            # 处决全程自己按: 留着框架的自动 F 会在切人时插一发, 而击破动画带全局
            # 时停 + 队伍 HUD 消失, 正好把切人循环判成脱战
            for c in (self, ciac, rover):
                c.check_f_on_switch = False

            if self.cur is not self:
                self.quick_switch(self, click_during=True)

            # ===== 1. R 变身芙露德莉斯 =====
            # 长演出(隐藏HUD 203F=3.38s, 第196F前不能切人), 期间一直点普攻,
            # 保证演出结束的第一帧就有输入落进去。
            # 【不在按 R 之前读能量】: 那次读屏是纯延迟, 而且开局那零点几秒队伍 HUD
            # 还在渐入, 能量环的读数正好最不可信 —— 等它等满就是白扔 0.8 秒。
            # fire_lib 自己就是判据: 它盯的是"HUD 掉没掉下去", 没放出去就返回 False,
            # 下面第 2 步的 R 也跟着跳过, 不会变成迟到的变身
            if self.fire_lib(self, tag='R变身'):
                self.poke_until_hud_back(tag='变身Anim',
                                         time_out=self.CART_TRANSFORM_ANIM + 3)
                # 【冷却从按键那一刻起算】: 按演出结束算的话变身之后还要白等 1.5 秒
                # 才敢按第二发 R, 而那 3.4 秒演出早就把冷却走完了
                self.last_form_switch = self.lib_press_at
                self.wait_form(small=False)

                # ===== 2. R 切回小卡, 把显化状态存起来 =====
                self.press_r_form(to_fleur=False, tag='R>小卡(存显化)')
            else:
                self.logger.info('opener: no liberation energy, '
                                 'skipping the transform prologue')

            # ===== 3. 平A 到出神权剑(A4, 就是打出光柱那一下) =====
            # 【窗口比循环轴里那一格短】: 形态切换的 A2 已经把连段推过去了,
            # 这里只剩 A3+A4。给整整一轮的话就是"小卡多A一轮、风主进场晚"。
            # 出剑和交棒合成一步(switch_on_a4_launch), 中间不许插东西

            # ===== 4. 出剑那一刻就交棒, 进循环轴 =====
            # 启动轴这次交棒过去, 风主是【站着】的 —— 要自己 E 升空
            self.rover_needs_lift = True
            self.first_loop = True
            self.switch_on_a4_launch(rover, cap=self.O_CART_A_TO_SWITCH)
            self.logger.info(f'opener timeline: {self.macro_timeline()}')
        except Exception as e:
            self.logger.warning(f'opener aborted ({type(e).__name__}: {e}) at: '
                                f'{self.macro_timeline()}')
            raise
        finally:
            self.release_attack()
            self.poking = False
            self.task.skip_combat_check = previous
        return True

    def wait_lib_ready(self, char, cap=2.5, tag='能量'):
        """边点普攻边等某个角色的大招能量转满(能量环亮)。

        大招是【能量门控不是 CD 门控】: 用 liberation_available()(读能量环),
        不要用 has_cd('liberation') —— 那是 OCR 读 CD 数字, 而大招图标上没有数字。
        """
        start = time.time()
        n = 0
        ready = False
        next_click = 0.0
        while time.time() - start < cap:
            now = time.time()
            if now >= next_click:
                self.click()
                n += 1
                next_click = now + self.A_INTERVAL
            self.task.next_frame()
            try:
                if char.liberation_available():
                    ready = True
                    break
            except Exception:
                pass
        self.macro_mark(f'{tag}({"满" if ready else "cap"},x{n},{time.time() - start:.2f}s)')
        return ready

    def fire_echo(self, char, tag='Q'):
        """把声骸键发出去 —— 【一次, 不读屏、不等】。

        (用户 2026-08-30: "Q不需要什么额外的检测, 随时都能放, 没放就是没进入CD,
         你随时按一下不就好了, 根本什么都不耽误, 因为这个Q是脱手的")

        声骸是【脱手技能】: 键递出去角色马上就能做别的, 不需要留时间给它。
        我原来给它配了两样东西, 两样都是错的:
          - need_available 读屏: 纯延迟。落在 CD 上发键本来就是空操作, 读它没有意义
          - 0.25 秒的连发窗口: 实打实占掉的时间, 还会把后面的时序【整体推歪】——
            夏空的下落时机就是这么被带偏的
        所以现在它是零耗时的, 放在轴上任何位置都不用再算"塞进哪段死时间"。
        """
        char.send_echo_key()
        char.record_echo_use()
        self.macro_mark(tag)
        return True

    def rover_e_fired(self, rover):
        """风主的 E 到底放出去没有 —— 判据是共鸣技能图标上出现了读数(进了充能)。

        原版风主的 wind_routine_flying() 用的就是这个判据(current_resonance() > 0.15):
        气动漂泊者的 E 一放出去人就升空, 图标同时进入充能, 两件事是同一个时刻。
        """
        try:
            self.task.next_frame()
            return rover.current_resonance() > 0.15
        except Exception:
            return False

    def rover_lift_e(self, rover, tag='风主E'):
        """把"升空那一发 E"发到真的放出去为止。

        【不能单发】: 刚切进场那几帧还在换人动画里, 按键会被丢掉、不排队 ——
        单发十有八九整个没了, 症状就是"人没升空, 后面几下全打在地上"
        (地面普攻不给核心回收1, 强化E 的 60 点充能就永远差一截)。
        放出去了立刻停手, 不会多按掉第二发要用的那一次充能。
        """
        # 【强化E 亮着就别按这一发】(用户 2026-08-30: "强化E提前好了你就检测到了
        # 就放了, 不行, 必须等R之后, 符合流程才可以"):
        # 强化E 亮着的时候按 E 出来的【就是强化E】—— 既升不了空(后面几下全打在地上),
        # 又把"大招之后那一发"提前浪费掉了。轴上强化E 只有一个位置: 大招演出结束之后。
        try:
            self.task.next_frame()
            if rover.is_forte_full():
                self.macro_mark(f'{tag}(强化E亮,不按)')
                return 0
        except Exception:
            pass
        return self.spam_key(rover.send_resonance_key, self.ROVER_E_RESEND_CAP,
                             interval=self.KEY_INTERVAL, tag=tag, poke=False,
                             stop_when=lambda: self.rover_e_fired(rover))

    def press_e(self, char, tag='E', window=0.20, interval=0.07):
        """把一发技能键【递进去】。

        【为什么不是单发】: 动画期间的按键是被丢掉的、不排队, 单发很容易整个丢掉,
        症状是"那一步慢了"(要等整个动画演完才有第二次机会)。窗口给 0.2 秒:
        比任何一个"按完到能再按"的派生帧都短, 不会把下一发提前按出来。
        """
        return self.spam_key(char.send_resonance_key, window, interval=interval,
                             tag=tag, poke=False)

    # ==================== 循环轴 ====================

    def perform_loop(self, entry_char=None):
        """循环轴。入口是风主(上一圈结尾把他变奏出来), 由 Rover.py 调进来。

        一圈的账: 卡提按 4 次 R(变身/切小卡/切大卡/芙大招), 下落攻击 2 次,
        风主和夏空各一发大招, 夏空攒满 3 格回路放一次强化重击。

        Returns: 是否跑完(中途切人失败也照样往下走, 只有队伍不全才返回 False)。
        """
        ciac = self.teammate('Ciaccona')
        rover = self.teammate('Rover')
        if ciac is None or rover is None:
            return False

        previous = getattr(self.task, 'skip_combat_check', False)
        self.task.skip_combat_check = True
        self.cur = entry_char or rover
        self.poking = False
        try:
            self.macro_start()
            self.jump_count = 0
            for c in (self, ciac, rover):
                c.check_f_on_switch = False

            self.loop_seg1(rover, ciac)
            marks = len(self.macro_marks)
            self.logger.info(f'loop SEG1: {self.macro_timeline()}')
            self.loop_seg2(rover, ciac)
            self.logger.info(f'loop SEG2: {self.macro_timeline(marks)}')
            marks = len(self.macro_marks)
            self.loop_seg3(rover, ciac)
            self.logger.info(f'loop SEG3: {self.macro_timeline(marks)}')
        except Exception as e:
            # 【中途挂掉也要把时间轴打出来】(2026-08-30): macro_marks 原来只在每个 seg
            # 【跑完】才一次性打印, 中间抛异常(脱战最常见)就什么都看不到 ——
            # 表现出来就是"日志里根本没有 SEG3", 分不清是没跑到还是跑了没生效
            self.logger.warning(f'loop aborted ({type(e).__name__}: {e}) at: '
                                f'{self.macro_timeline()}')
            raise
            self.logger.info(
                f'loop total {self.time_elapsed_accounting_for_freeze(self.macro_t0):.2f}s '
                f'(wall {time.time() - self.macro_t0:.2f}s)')
        finally:
            self.release_attack()
            self.poking = False
            self.task.skip_combat_check = previous
        return True

    def rover_air_a(self, clicks, tag='风主空中A'):
        """空中那几下 —— 【点固定几下, 间隔贴着派生帧, 点完就走】。

        【2026-08-30 回退说明】: 上一版改成了"连点 + 窗口=段数x0.38", 那是错的 ——
        空中连段只有 空中A1/空中A2 两段(帧表), 连点到第三下就变成"空中普攻-下落",
        人当场落地, 后面一秒多全在地上白打。这正是更早报过的"A4没出来就下落了",
        我因为"卡顿在空中A"把封顶去掉, 等于把那个老问题又放了回来。

        【卡顿的真正来源是尾巴, 不是间隔】: 老版本点完 N 下之后还要 macro_wait
        把窗口剩下的时间等完(ROVER_AIR_A_TAIL), 那一段是【干站着】的。
        现在窗口 = 点击总时长, 点完立刻走, 没有干等。

        【间隔取派生帧】: 空中A1 派生22F(0.37s)、空中A2 派生24F(0.40s)。
        比它快 -> 多出来的点击落在动画里被吞, 打不出那么多段;
        比它慢 -> 每段之间明摆着的空档。
        """
        return self.spam_then_hold(clicks * self.ROVER_AIR_A_STEP, clicks,
                                   self.ROVER_AIR_A_STEP, tag=tag)

    def rover_e_until_con(self, rover, cap=None, tag='风主E'):
        """发 E 升空, 同时【从第一帧就盯着协奏】—— 协奏一满立刻返回, 不等 E 走完。

        (用户 2026-08-30: "你就应该从切到风主就开始一直检测")

        【为什么要合成一个循环】: 这一格的目的只有一个 —— 把协奏顶满好让夏空
        拿到变奏入场。E 是手段不是目的。原来是"发E -> 等 E 自带那两下 -> 才开始
        检测", 而 rover_lift_e 里还压着一次读强化E、一次读 E 是否进 CD ——
        协奏其实早就满了, 全花在这些串行的读屏上了。
        现在一个循环里每帧都先读协奏, 满了当场返回。

        【强化E 亮着就不按】: 按了出来的是强化E, 既升不了空, 又把大招之后
        那一发浪费掉。
        """
        cap = self.ROVER_E_CON_CAP if cap is None else cap
        start = time.time()
        full = False
        n = 0
        e_done = False
        why = ''
        while time.time() - start < cap:
            self.task.next_frame()
            try:
                if rover.get_current_con() >= self.CON_ENOUGH:
                    full = True
                    break
            except Exception:
                pass
            if not e_done:
                try:
                    if rover.is_forte_full():
                        e_done, why = True, '强化E亮'
                    elif rover.current_resonance() > 0.15:
                        e_done, why = True, 'E已放'
                    else:
                        rover.send_resonance_key()
                        n += 1
                except Exception:
                    pass
        self.macro_mark(f'{tag}(E x{n}{"," + why if why else ""},'
                        f'{"con满" if full else "cap"},{time.time() - start:.2f}s)')
        return full

    def wait_con_full(self, char, cap, tag='协奏', poke=False):
        """盯着协奏圈等它满, 满了立刻返回。【默认不点击】。

        跟 rover_air_a_until_con 的区别: 那个是"边打边看", 这个是【纯等】——
        用在"上一个动作自己就会把协奏顶满、只是要知道什么时候到"的地方。
        """
        start = time.time()
        full = False
        n = 0
        next_click = 0.0
        while time.time() - start < cap:
            self.task.next_frame()
            try:
                if char.get_current_con() >= self.CON_ENOUGH:
                    full = True
                    break
            except Exception:
                pass
            now = time.time()
            if poke and now >= next_click:
                self.click()
                n += 1
                next_click = now + self.A_INTERVAL
        self.macro_mark(f'{tag}({"满" if full else "cap"},x{n},'
                        f'{time.time() - start:.2f}s)')
        return full

    def rover_air_a_until_con(self, char, clicks, tag='风主空中A'):
        """空中那几下, 【协奏一满就立刻停手】。

        (用户 2026-08-30: "只要检测到协奏圈满了就切, 不要等, 实机里多A了几下才切")
        形状跟 rover_air_a 完全一样(点固定几下、间隔贴派生帧), 只是每下之后顺便
        读一次协奏 —— 满了就不打完剩下的段数了。

        【节奏锚在 start 上】: 读协奏要花几十毫秒, 不锚的话这几十毫秒会一轮一轮
        累加, 间隔就不是派生帧了。
        """
        start = time.time()
        n = 0
        full = False
        # 【先读一次再决定点不点】(用户 2026-08-30: "那里明明都满了, 还是A了几下"):
        # 原来是"先 click 再检测", 进来时协奏就已经满的话照样白打一下
        try:
            full = char.get_current_con() >= self.CON_ENOUGH
        except Exception:
            pass
        while not full and n < clicks:
            self.click()
            n += 1
            self.task.next_frame()
            try:
                if char.get_current_con() >= self.CON_ENOUGH:
                    full = True
                    break
            except Exception:
                pass
            if n < clicks:
                self.macro_wait(max(0.0, n * self.ROVER_AIR_A_STEP
                                    - (time.time() - start)))
        self.macro_mark(f'{tag}(x{n},{"con满" if full else "打满"},'
                        f'{time.time() - start:.2f}s)')
        return full

    def rover_air_a_until_forte(self, rover, clicks, tag='风主空中A'):
        """空中那几下, 【回路一满就立刻停手】。

        (用户 2026-08-30: "风主第二次E上去A, 按R的时间可以快0.7s")
        这一格的 A 是【攒回路给大招之后那发强化E】用的(强化E 吃 60 点核心回收1,
        空中普攻每段给 25) —— 攒够了就没必要把段数打完。
        原来是"固定打 5 段 -> 再单独读一次回路 -> 不够才补", 那次独立的读屏正好卡在
        按 R 的路口上; 现在把判据合进连点循环, 够了当场停、也不用再读那一次。

        【这一格读屏不心疼】: 后面接的是 R, 不是切人 —— 晚几十毫秒开大招没有代价。
        而且 is_forte_full 走的是找图, 比协奏那个连通域分析便宜得多。
        """
        start = time.time()
        n = 0
        full = False
        try:
            self.task.next_frame()
            full = bool(rover.is_forte_full())
        except Exception:
            pass
        while not full and n < clicks:
            self.click()
            n += 1
            self.task.next_frame()
            try:
                if rover.is_forte_full():
                    full = True
                    break
            except Exception:
                pass
            if n < clicks:
                self.macro_wait(max(0.0, n * self.ROVER_AIR_A_STEP
                                    - (time.time() - start)))
        self.macro_mark(f'{tag}(x{n},{"回路满" if full else "打满"},'
                        f'{time.time() - start:.2f}s)')
        return full

    def rover_fall_to(self, target, tag='风主下落A'):
        """下落攻击 -> 看见下落前摇就交棒。

        协奏【提前读好】: 交棒要抢在下落这一小段里, 不能让能量环的连通域分析
        夹在数字键和重发之间。
        """
        # 【协奏必须在下落连点【之前】读】(用户 2026-08-30: "风主切夏空慢了好多,
        # 夏空都直接在地面了"): 读协奏是能量环的连通域分析, 而 macro_spam 里每次
        # click 都会 reset_scene —— 连点之后的第一次读屏要等一张新截图,
        # 实测能到 0.86 秒。夹在"下落"和"数字键"之间, 夏空当然就落地了。
        # 放在前面读, 那时帧是热的, 而且离交棒还有一整段下落的时间
        intro = False
        try:
            intro = bool(self.cur.is_con_full() if self.cur else False)
        except Exception:
            pass
        self.macro_mark(f'con^{1 if intro else 0}')
        fall_at = time.time()
        self.macro_spam(self.ROVER_FALL_A_SPAM, self.A_INTERVAL_FAST, tag=tag)
        self.macro_wait(max(0.0, self.ROVER_FALL_TO_SWITCH - (time.time() - fall_at)))
        return self.quick_switch(target, assume_con=intro, click_during=False)

    def ciac_land_and_forte(self, ciac, want, tag='夏空'):
        """夏空空中接手 -> 落地 -> 补一下平A -> 确认/攒回路。

        她三次上场都是从空中接手的(上一个角色交棒时都在空中), 走的是空中出场技:
        帧表 空中A2-下落 结束34F -> 空中A2-落地 派生12F, 合计 46F 才轮得到下一个动作。
        提前动手的话那一下要么被下落动画吞掉, 要么把落地那下的伤害顶掉。
        """
        self.macro_wait(self.CIAC_AIR_INTRO_TO_E)
        self.spam_then_hold(self.CIAC_LAND_A_TO_E, 1, self.CIAC_LAND_A_TO_E,
                            tag=f'{tag}落地A')
        return self.wait_ciac_forte(ciac, want, cap=self.CIAC_FORTE_CAP)

    def jump_once(self, tag='跳', after_sleep=0.0):
        """跳一次, 并把这一次记进时间轴。

        【所有跳跃都必须走这里】(用户 2026-08-30: "后面为什么又多跳了一下"):
        这条轴上跳跃是【不能重发】的 —— 连发会二段跳, 后面接的下落攻击高度就不对。
        所以每一次跳都要在时间轴上留痕, 才查得出"多跳的那一下"是从哪来的。
        """
        self.task.jump(after_sleep=after_sleep)
        self.jump_count = getattr(self, 'jump_count', 0) + 1
        self.macro_mark(f'{tag}#{self.jump_count}')

    def dodge(self, tag='闪避'):
        """闪避。这条轴上它【只用来取消后摇】, 不是为了躲伤害。

        【发完立刻返回】(after_sleep=0): 后面紧跟着的连点要尽早开始 ——
        闪避本身也有 0.27~0.35 秒吃输入, 晚一点开始连点就等于把 A 推到闪避演完之后。
        """
        self.task.send_key(self.task.key_config.get('Dodge Key'), after_sleep=0)
        self.macro_mark(tag)

    def loop_seg1(self, rover, ciac):
        """风主(变奏入场自带升空) -> 夏空 -> 风主 E+A3+大招+强化E -> 切卡提。"""
        # ===== 风主上场: 【有没有变奏, 升空的来源不一样】 =====
        # 带变奏(QTE): 帧表 QTE-1 位置"地转空"、QTE-2 位置"空中" —— 入场自带升空,
        #   这时候再按 E 是白烧一格充能(E 是充能制, 第二次上场就没得用了)。
        # 没变奏(普通换人): 从卡提 A4 击飞那一刻交棒过来只是【继承浮空】, 很快就落地,
        #   【必须自己 E 升空】, 否则后面那几下全打在地上、核心回收1 一点都拿不到。
        # 【这一格上一轮我一刀切删了 E】(用户 2026-08-30: "你把启动轴风主E也删了"):
        # 启动轴那次交棒实机一直是 con^0(卡提变身只给 20 点协奏回收, 攒不满),
        # 所以那次【没有变奏】, 删了 E 就等于让他站在地上打
        # 【声骸塞进"不能出手"的那段空档里】(用户 2026-08-30 明确指定的位置):
        #   带变奏 -> 变奏入场的输入锁(QTE 第85F前不响应输入)
        #   不带变奏 -> E 自带那两下(地面E-1 发生20F、地面E-2 发生37F, 派生57F)
        # 两条分支后面都跟着一段【本来就出不了手】的等待, Q 塞进去一点时间都不占。
        # 放在等待之后 = 白加 0.25 秒; 放在 E 之后 = 顶到升空那一下; 挪走 = 起手那次
        # 上场就没有 Q。绕了四轮, 这里才是对的
        if rover.has_intro:
            lead = self.ROVER_INTRO_LOCK
        elif self.rover_needs_lift:
            self.rover_lift_e(rover, tag='风主E')
            lead = self.ROVER_E_AUTO_HITS
        else:
            # 【已经在天上, 直接 A】(用户 2026-08-30: "循环轴风主是变奏入场直接在天上,
            # 你是不是在等E升空自带的那两下A所以才会卡一下")—— 正是。
            # 不用 E 就没有那两下自动伤害要等, 0.83 秒的空档直接省掉
            lead = 0.0
            self.macro_mark('风主(已在空中)')
        self.fire_echo(rover, tag='风主Q')
        if rover.has_intro:
            # 【入场锁期间要连点, 不能干等】(用户 2026-08-30: "变奏风主入场
            # 你是不是等X秒才开始A, 我还是看着会楞一下"):
            # 帧表 QTE 第85F前不响应输入 —— 那 1.42 秒里点了确实是白点(输入被丢掉、
            # 不排队), 但【锁一解开就必须有一下落进去】。干等的话要等到 poll_wait
            # 走完才发第一下, 中间那一帧的空白就是"楞一下"
            self.macro_spam(lead, self.A_INTERVAL_FAST, tag='风主入场A')
        else:
            # E 分支【不能点】: 那 0.83 秒是 E 自带的两下, 点进去会占掉空中段数
            self.poll_wait(lead, tag='风主起手')
        # 【段数按"要不要自己升空"分】—— 见 ROVER_A_CLICKS_LIFT / _AIR
        self.rover_air_a(self.ROVER_A_CLICKS_LIFT if self.rover_needs_lift
                         else self.ROVER_A_CLICKS_AIR)
        # 下落攻击 -> 看见下落前摇就切夏空
        self.rover_fall_to(ciac)

        # ===== 夏空: 落地A -> 攒一格回路 -> E -> 声骸 =====
        self.ciac_land_and_forte(ciac, 1)
        self.press_e(ciac, tag='夏空E')
        self.fire_echo(ciac, tag='夏空Q')
        self.macro_gap(self.CIAC_Q_TO_SWITCH)

        # ===== 切回风主: E 升空 -> A 到 A3 -> R 开大 -> 强化E =====
        self.quick_switch(rover, click_during=True)
        self.rover_lift_e(rover, tag='风主E')
        self.macro_wait(self.ROVER_E_AUTO_HITS)
        # 【A 打满就立刻 R, 中间一次屏都不读】
        # (用户 2026-08-31: "我要的是按R的时间提前, 不需要减少A的时间之类的";
        #  而且上一版"快0.6s"实机感觉没变化 —— 根因就在这)。
        # 【上一版为什么白忙】: rover_air_a_until_forte 是【每点一下就读一屏】
        # (next_frame + is_forte_full), 5 段就是 5 次读屏; 而循环里的
        # macro_wait(n*STEP - 已用) 会把读屏耗时【吸收进间隔】—— 读屏比 0.19 长的话
        # 整段反而被拉长。用读屏换来的提前, 全被读屏自己吃回去了。
        # 这跟"协奏检测越检测越慢"是同一个教训, 我在这一格又犯了一次。
        # 【回路够不够不用读】: 空中普攻每段给 25 点核心回收1, 打满 5 段 = 125,
        # 而强化E 只吃 60 —— 正常轮次本来就够。之前"回路未满"是因为段数被我
        # 从 8 误砍到 3(减半 STEP 时漏改), 不是判据缺失。
        # 真不够的话大招之后的 wait_rover_forte 还在兜, 而那一段不在 R 的路径上
        # 【段数按"第几圈"分开】: 用户这几轮调的一直是【循环圈】那一档
        self.rover_air_a(self.ROVER_A_CLICKS_2_OPENER if self.first_loop
                         else self.ROVER_A_CLICKS_2_LOOP)
        self.macro_spam(self.ROVER_FORTE_TO_R_OPENER if self.first_loop
                        else self.ROVER_FORTE_TO_R_LOOP,
                        self.A_INTERVAL, tag='风主R前A')
        if not self.fire_lib(rover, tag='风主R'):
            self.wait_lib_ready(rover, cap=self.ROVER_LIB_RETRY_CAP, tag='风主能量')
            self.fire_lib(rover, tag='风主R2')
        # 【R 之后不再点普攻】(用户 2026-08-30: "风主R以后就不要A了, 直接等强化E切人")。
        # tail=0: poke_until_hud_back 的收尾连点也去掉 —— 那几下正好落在演出刚结束,
        # 打出来的就是"R 完还A一下"
        self.poke_until_hud_back(tag='风主大招Anim', time_out=self.ROVER_LIB_ANIM + 4,
                                 tail=0)
        # ===== 强化E: 按下【立刻】发切人键 =====
        # 帧表: 强化E1 "第48F后, 处于【切人滞留状态】时自动派生强化E2" ——
        # 切人指令要先发出去让她滞留, 游戏到 48F 自己把强化E2 派生出来
        # 【大招演出结束到强化E 之间留一手】(用户 2026-08-30: "风主提前放了强化E")。
        # poke_until_hud_back 的判据是队伍 HUD 回来, 而帧表里风主大招
        # 【第211F前不能切人】、伤害是 发生148F 持续66F(到 214F 才打完) ——
        # HUD 回来的那一刻他还在收招里, 这时按 E 要么被吞、要么把大招的尾巴掐掉。
        # 【这一段改成干等, 不点】: 只是留给收招的缓冲, 不再补普攻
        self.macro_wait(self.ROVER_LIB_TO_FE)
        self.wait_rover_forte(rover, poke=False)
        self.press_e(rover, tag='风主强化E1')
        self.macro_gap(self.ROVER_FE1_TO_SWITCH)
        self.quick_switch(self, click_during=True)

    def loop_seg2(self, rover, ciac):
        """卡提E -> 夏空攒回路 -> 风主 E+A 顶满协奏 -> 夏空预输入重击+R -> 变奏卡提。"""
        # ===== 卡提: 一发 E(地转空), 递出去就走 =====
        self.press_e(self, tag='卡提E')
        self.macro_wait(self.SKILL_TO_SWITCH)
        # 【空中不点普攻】: 点击会打出下落攻击, 把这一轮攒的剑之影提前吃掉
        self.quick_switch(ciac, read_con=True, click_during=False)

        # ===== 夏空: 落地A -> 再攒一格回路 =====
        self.ciac_land_and_forte(ciac, 2)

        # ===== 切回风主: E 升空 -> A -> 顶满协奏 =====
        self.quick_switch(rover, click_during=True)
        # 【这一格全程不读协奏, 主路径就是计时】(用户 2026-08-30: "怎么还是慢,
        # 你读的行不行啊" —— 对, 读屏本身就是那个"慢")。
        # get_current_con 走的是能量环的【连通域分析】(count_rings), 前面还压着
        # _ensure_ring_index —— 一次几十到几百毫秒。放进"满了就走"的循环里,
        # 循环转一圈的代价本身就大于想省的那点时间, 越检测越慢。
        # 用户原话是"我只是为了保底让你检测的" —— 那主路径就该是【计时】:
        # E 自带那两下打中协奏就满, 那是个稳定的时刻, 直接按秒数走。
        # 【唯一保留的一次读屏】是"强化E 亮没亮", 它在计时之外, 而且非读不可 ——
        # 强化E 亮着按 E 出来的是强化E, 既升不了空又浪费大招后那一发
        skip_e = False
        try:
            self.task.next_frame()
            skip_e = bool(rover.is_forte_full())
        except Exception:
            pass
        e_at = time.time()
        if skip_e:
            self.macro_mark('风主E(强化E亮,不按)')
        else:
            self.press_e(rover, tag='风主E', window=self.ROVER_E2_WINDOW)
        # 【从按下 E 到交棒 = ROVER_E_TO_SWITCH, 就这一个数】
        # (用户 2026-08-30: "风主E检测切夏空那里 缩短到0.3s")。
        # 【这里没有 A 段了】: 0.30 秒连 E 自带那两下(地面E-2 派生57F=0.95,
        # 空中E-2 派生50F=0.83)都放不下, 更谈不上再接普攻 —— 这一格现在纯粹是
        # "把 E 递出去就走"。
        # 【要留意的代价】: E 的自动伤害还没结算完就切人, 那 10 点协奏回收可能没到账,
        # 夏空就吃不到变奏入场(症状是她的回路少一格, 日志 回路(2/3))。
        # 真出现的话就把这个数往回加
        self.macro_wait(max(0.0, self.ROVER_E_TO_SWITCH - (time.time() - e_at)))
        # 【切人期间不点普攻】(同上那条): click_during=True 会在等换人生效的这段时间
        # 一直点 —— 协奏已经满了、目的只剩交棒, 那几下是纯多余的;
        # 而且风主这时在空中, 点击会变成下落攻击, 把浮空提前用掉,
        # 夏空就继承不到了
        # assume_con=True: 不读屏, 直接按满协奏记账
        self.quick_switch(ciac, assume_con=True, click_during=False)

        # ===== 夏空: 长按左键【预输入】重击 -> 协奏一涨就 R 打断 =====
        # (用户 2026-08-30: "长按鼠标左键预输入重击(看见协奏涨/回路消耗)R开大打断")
        # 【为什么是长按预输入而不是等她能出手】: 空中出场技落地之前按下去的左键
        # 会被游戏缓存, 一落地就直接进重击 —— 比"等落地再按"快一整个落地硬直。
        # 【判据用协奏上涨】: 强化重击 协奏回收25, 一跳就是一大格, 说明那一下结算了;
        # 后面的收招没有伤害, R 打断它纯赚
        self.macro_wait(self.CIAC_AIR_INTRO_TO_E)
        # 【回路不满的保底: 跳一下打下落攻击接A 补回路】(用户 2026-08-30)。
        # 强化重击要吃 3 格回路(帧表: 强化重击-地面 核心回收1 = -3), 不够就放不出来,
        # 而它又是这一格大招能量的大头 —— 放不出来就一路连锁到"夏空R没放出来"。
        # 【为什么是跳+下落攻击而不是站着平A】: 她的回路只有 A4 给, 从站桩打到 A4
        # 要走完整条连段; 而下落攻击落地能直接把连段接到后段, 快得多。
        # 【读屏在这里不心疼】: 这一格后面接的是重击和 R, 不是切人
        if self.ciac_forte(ciac) < 3:
            self.macro_mark('夏空回路不足,补一轮')
            self.jump_once(tag='夏空跳')
            self.macro_spam(self.CIAC_FALL_A_SPAM, self.A_INTERVAL_FAST,
                            tag='夏空下落A')
            self.wait_ciac_forte(ciac, 3, cap=self.CIAC_FORTE_CAP)
        self.hold_until_heavy_fired(ciac, tag='夏空预输入重击')
        # 【放不出来就等能量, 别白按】(用户 2026-08-30: "循环轴夏空R没放出来";
        #  实机 warning 写的是 icon lit=False —— 是【能量真的不够】, 不是键被吞)。
        # 【为什么"回路掉了"不等于能量够了】: 帧表里强化重击的大招回收是分两笔的 ——
        #   强化重击-聚怪  大招回收 0.75, 持续 120F
        #   强化重击-爆炸  大招回收 7.47, 备注"【聚怪持续帧结束后】自行生成"
        # 也就是那 7.47 点大头要等【2 秒】之后爆炸结算才到账。而"回路掉"只说明
        # 重击【起手】了 —— 这两件事差着整整一个聚怪的持续时间。
        # 【取舍】: 等能量就打断不了重击收招了, 但能量不够根本放不出来, 没得选。
        # 正常轮次(能量本来就够)一发就进, 这段一秒都不占
        if not self.fire_lib(ciac, tag='夏空R'):
            self.wait_lib_ready(ciac, cap=self.CIAC_LIB_RETRY_CAP, tag='夏空能量')
            self.fire_lib(ciac, tag='夏空R2')
        self.poke_until_hud_back(tag='夏空大招Anim', time_out=self.CIAC_LIB_ANIM + 4)

        # ===== 变奏卡提 =====
        # 【assume_con 不读屏】: 大招-前置自带 20 点协奏回收, 放完必满;
        # 而演出期间能量环的读数不可信
        self.quick_switch(self, assume_con=True, click_during=True)

    def loop_seg3(self, rover, ciac):
        """卡提的双下落 4R。整条按用户 2026-08-29 给的优化流程走:

            满协奏切卡提 -> 跳A 下落(吃三剑)
            R 切大卡 -> EE 连放 -> 接 A3/A4/A5
            R 切小卡 -> 从 A2 打到 A4, A4 起长按左键 -> 自动接重击(出异权剑)
            跳跃取消重击后摇 -> E -> 闪避取消 E 后摇 -> A 下落(吃三剑)
            R 切大卡 -> A1 到 A5 -> 看到 A5 出伤再开 R2
        """
        # ===== 变奏入场自带一把异权剑, 入场完【直接跳】=====
        # 帧表: 卡提 QTE 第53F前不响应输入(0.88s); QTE-异权剑 发生65F(1.08s)。
        # 【这一整段一下都不点】: 锁住的那 0.88 秒里点了也是白点(输入被丢掉、不排队),
        # 而锁一解开, 连点窗口尾巴那几下就变成【真的普攻】、起了连段, 跳跃只能排在
        # 它后面 —— 用户看到的"A了两下才跳"就是这么来的
        # 【等到输入锁解开就跳, 不等异权剑】: 异权剑是 QTE 自己在 65F 生成的,
        # 跟她之后做什么无关。而这一段【完全静默】会拖长"场上没有任何攻击"的时间,
        # 战斗判定线程读不到目标就开始 target lost —— 2026-08-30 实机在这里脱战过。
        # 静默期间照样 next_frame, 让判定线程拿到的是新画面
        self.poll_wait(self.CART_INTRO_LOCK, tag='卡提入场')
        # 【那个三剑检查删了】(用户 2026-08-30: "跳跃可以再快0.2S起跳"):
        # 实机日志里它一直是 三剑(0/3,x0,0.21s) —— 一把都读不到、每次跑满上限,
        # 纯粹是 0.21 秒的延迟。读不到也照跳, 那这一步就没有存在的理由
        self.fall_attack(tag='下落1', check_ready=False)
        self.macro_gap(self.CART_LAND_DERIVE)

        # ===== R 切大卡 -> EE【连放】 =====
        # 【两发 E 之间不等派生帧】(用户 2026-08-29: "你EE那里按慢了"):
        # 帧表上 E1-2 的派生帧是 55F(0.92s), 但这一格是"ee连放" —— 第二发在第一发
        # 的动作里就递进去, 不用等它演完
        self.press_r_form(to_fleur=True, tag='R>芙')
        # 【连发到两格充能都用掉为止】(用户 2026-08-30: "大卡的EE会被打断,
        # 导致第二个E就不放了, 后续发现没放要补放")。
        # 【为什么加长窗口就是保底】: E 落在没充能上【就是空操作, 没有代价】——
        # 跟声骸同理。所以窗口可以给足, 让它覆盖"第一发被打断、重来一次"的情况;
        # 而 stop_when 保证正常轮次读到两格用完就立刻停手, 不白等
        ee_at = time.time()
        self.spam_key(self.send_resonance_key, self.FLEUR_EE_WINDOW,
                      interval=self.FLEUR_EE_INTERVAL, tag='芙EE', poke=False,
                      stop_when=self.fleur_ee_done)
        # 【只在窗口跑满时才补】(用户 2026-08-30: "EE之后又愣了一下才A"):
        # stop_when 提前退出就说明【已经读到两格都用掉了】, 这时再读一次是白花一次
        # 读屏 —— 而这一次正好卡在"该接 A 了"的路口上, 那就是那一下愣。
        # 跑满窗口才说明 stop_when 一直不成立(第一发被打断了), 那才需要补
        if time.time() - ee_at >= self.FLEUR_EE_WINDOW - 0.05:
            self.macro_mark('芙EE没放完,补一轮')
            self.spam_key(self.send_resonance_key, self.FLEUR_EE_RETRY,
                          interval=self.FLEUR_EE_INTERVAL, tag='芙E补',
                          poke=False, stop_when=self.fleur_ee_done)
        # 【诊断】: 连发完读一次共鸣图标。两格充能都用掉的话图标会显示读数,
        # 这个值就高; 一直很低说明键根本没被接受, 那就不是间隔的问题了
        try:
            self.macro_mark(f'芙E充能{self.current_resonance():.2f}')
        except Exception:
            pass

        # ===== 接 A3/A4/A5 =====
        # 【从 EE 结束就一直连点, 不要干等落地】(用户 2026-08-30: "还是会愣一下"):
        # E2 是下落 + 落地, 那一段确实出不了手 —— 但【点了也是白点、不花钱】,
        # 而落地那一帧就能立刻接上 A。干等的话要等 macro_wait 整个走完才发第一下,
        # 中间那一帧的空白就是"愣一下"。
        # 所以把"等落地"和"打 A2345"合成【一个连续的连点段】, 中间没有任何空白
        # 【处决不放在这里了】(用户 2026-08-30: "卡提的处决还是会打断节奏,
        # 加到R2后面去吧") —— A1 之后的派生窗口虽然是 A123 里最宽的(38F=0.63s),
        # 但处决动画本身带全局时停, 插在连段中间怎么都会把后面的段数推歪。
        # 挪到 R2 之后: 那里本来就是一段"演出刚结束、下一步是 RR"的空档
        self.macro_spam(self.FLEUR_E2_TO_A + self.FLEUR_A_TO_A5_CAP,
                        self.A_INTERVAL, tag='芙A2345')

        # ===== R 切小卡 -> 从 A2 打到 A4 =====
        # 【这一发要在决意够 120 之前按】: 决意满了 R 就变成芙大招, 后面攒的三把剑
        # 和第二次下落全部落空
        self.press_r_form(to_fleur=False, tag='R>小卡')
        # 【卡提的声骸放这里】(用户 2026-08-30: "卡提的Q好像一直没放, Q有了就放"):
        # 上一轮重写 seg3 时把它弄丢了。选这个位置是因为【显化状态的计时在小卡形态下
        # 是暂停的】(帧表原文) —— 这一整段无论花多久都不吃芙露德莉斯那 12 秒的额度,
        # 是全轴唯一真正有余量的地方。在 CD 上直接跳过, 不占时间
        # 【同一段里发两次】(用户 2026-08-30: "卡提的Q还是时不时不放"):
        # Q 是脱手技能、发出去就走, 但【单发照样会被动画吞掉】—— 这一发正好落在
        # 形态切换那套 A2 的动画里, 十有八九没进去。
        # 又因为落在 CD 上就是空操作、零耗时, 所以【换个时刻再发一次】是最省的补法:
        # 不用等、不用读屏, 两次里总有一次落在能出手的帧上。
        # (不混进连点流是因为 F 和左键那次教训: 键混着发会互相吞)
        self.fire_echo(self, tag='卡提Q')
        # 形态切换本身走的是卡提 A2, 所以这里是从 A2 接着往下打
        self.macro_spam(self.CART_A_TO_A4, self.A_INTERVAL, tag='小卡A到A4')
        self.fire_echo(self, tag='卡提Q2')

        # ===== A4 起长按左键 -> A4 之后自动接重击(出异权剑) =====
        # 用户 2026-08-29: "a4的时候就应该长按鼠标左键了, a4后自动接重击(看见左剑生成)"。
        # 【长按期间绝对不要再 mouse_down 补按】: PostMessage 后端每次都会投一条
        # WM_ACTIVATE, 窗口收到就把已经按住的状态打断
        hold_up_at = time.time()
        self.macro_hold_attack(self.CART_A4_HOLD, tag='小卡A4+重击')
        # 【这里原来还夹着一句 wait_swords(2)】(用户 2026-08-30: "重击往后那段又不对了"):
        # 它 poke=False、读不到剑就跑满 0.20 秒上限, 而实机那三把剑的模板【从来读不到】
        # (日志一直是 0/3、absent0)。所以每一轮跳跃都被它推迟了 0.20 秒。
        # 更坑的是 up_at 记在它【后面】, 于是日志打出来永远是"跳(松手后+0.00)" ——
        # 看着完美, 实际晚了 0.20 秒。已删除, 并且 up_at 改成锚在长按开始那一刻

        # ===== 跳跃取消重击后摇 -> E =====
        # 重击的伤害在 56F(异权剑也是这一帧), 后面那段收招没有伤害 —— 跳掉它纯赚
        # 【单发】: 连发会二段跳, 后面的下落攻击高度就不对了。
        # 时机全靠 CART_HEAVY_TO_JUMP —— 日志里把"松手之后隔了多久跳的"打出来,
        # 对着实机调这一个数
        self.macro_wait(self.CART_HEAVY_TO_JUMP)
        self.jump_once(tag=f'跳(长按起+{time.time() - hold_up_at:.2f})')
        self.macro_wait(self.CART_JUMP_TO_E)
        self.press_e(self, tag='小卡E')

        # ===== 闪避取消 E 后摇 -> A 下落(吃三剑) =====
        # 帧表: E-人权剑 发生43F, E-击飞 结束54F。剑到手之后那段收招同样没有伤害。
        # E 的位置状态是"地转空", 所以闪避完人还在空中, 直接点普攻就是下落攻击 ——
        # 这一次【不用再跳】
        self.macro_wait(self.CART_E_TO_DODGE)
        self.dodge(tag='闪避取消E后摇')
        # 【闪避完立刻 A, 中间不留间隔】(用户 2026-08-30)。
        # 那个三剑检查也一并删了 —— 跟变奏入场那个一样, 实机从来读不到,
        # poke=False 又不出手, 纯粹是跑满上限的延迟
        self.macro_spam(self.CART_FALL_A_SPAM, self.A_INTERVAL_FAST, tag='下落2')
        self.macro_wait(self.CART_FALL_TO_LAND)
        self.macro_gap(self.CART_LAND_DERIVE)

        # ===== R 切大卡 -> A1 到 A5 -> 看到 A5 出伤再开 R2 =====
        self.press_r_form(to_fleur=True, tag='R>芙')
        # wait_lib_big 边点边等决意满 —— 决意的大头就是 A5(核心回收1 各 10),
        # 所以"图标变成大招二段"约等于"A5 打出去了"
        # 【决意一满就直接开 R2, 不再等 A5】(用户 2026-08-30: "改成只要能放就直接放")。
        # wait_lib_big 本身就是"边点边等, 图标一换成大招二段就立刻返回", 所以这里
        # 什么都不用加。原来后面还跟着 macro_spam(FLEUR_A5_TO_R2) 继续把连段推到 A5,
        # 那一段现在整个去掉 —— 要改回去就在这两句之间把它加回来
        self.wait_lib_big()
        self.fire_fleur_lib()

        # ===== R2 之后一直按 F: 有处决就吃掉, 没有就立刻往下走 =====
        # (用户 2026-08-30: "R2就开始一直F, 处决到了就处决, 处决的时候就准备RR,
        #  处决不到就接着连续两次R")
        # 【为什么这里最合适】: 芙大招刚演完, 下一步是两发 R —— 这一段没有连段要接,
        # 处决动画怎么拖都不会把别的东西推歪。spam_f 内部会判"到底触发了没":
        # 触发了就等它演完再走, 没触发只花 F_DETECT 那么点时间
        self.spam_f(tag='R2后处决', window=self.F_AFTER_R2)

        # ===== 接着【R 变身、再 R 切回小卡】=====
        # (用户 2026-08-30: "R2以后也没马上RR切小卡"; 他给的循环轴开头也是
        #  "接Rr变成小卡从a2开始")
        # 【为什么每圈都要重新变身】: 芙大招"第202F解除显化状态、清空决意"——
        # 显化没了, 下一圈的"R切大卡"就不再是免费的形态切换。所以在这里补一发
        # 变身把新的 12 秒显化拿到手, 紧接着切回小卡把它【存起来】
        # (显化计时在小卡形态下是暂停的)。这两下跟启动轴的步骤 1/2 是同一件事。
        # 【能量不够就整段跳过】: fire_lib 放不出去会返回 False, 下面那发 R 也跟着
        # 不按 —— 否则它会变成一发迟到的变身, 后面全部错位
        # 【处决之后那一发 R 要给缓冲, 还要能重试】(用户 2026-08-30: "怎么处决
        # 以后不会RR了"): 处决动画带全局时停, 演完那一刻角色还在收招里 ——
        # 这时发 R 会被整个吞掉, fire_lib 只发 0.6 秒就放弃, 于是 RR 整段跳过。
        # 【重试时边点边等】: wait_lib_ready 那段普攻本身也在回能量
        transformed = self.fire_lib(self, tag='R变身')
        if not transformed:
            self.wait_lib_ready(self, cap=self.CART_LIB_RETRY_CAP, tag='卡提能量')
            transformed = self.fire_lib(self, tag='R变身2')
        if transformed:
            self.poke_until_hud_back(tag='变身Anim',
                                     time_out=self.CART_TRANSFORM_ANIM + 3)
            self.last_form_switch = self.lib_press_at
            self.wait_form(small=False)
            self.press_r_form(to_fleur=False, tag='R>小卡(存显化)')
        else:
            # 【真的是能量不够】: 刚放完芙大招, 能量本来就是空的 —— 这一格能不能
            # 做 RR 取决于这一圈回了多少能量。日志里 卡提能量(cap) 反复出现的话,
            # 说明这个位置根本攒不出一发变身, 那 RR 就该整个挪走
            self.logger.info('loop tail: no liberation energy, skipping the transform')

        # ===== 收尾: 小卡平A 出一把剑, 交回循环开头 =====
        # 【这一格不能省】: 下一圈的三把剑里就有这一把, 而且交棒必须落在一段普通动作上
        self.poking = False
        # 循环圈这次交棒过去, 风主【已经在天上】—— 不用 E, 直接 A
        self.rover_needs_lift = False
        self.first_loop = False
        # 【跟启动轴收尾是同一格, 窗口也必须一样】(用户 2026-08-30: "循环轴小卡切风主
        # 那里慢了, 跟启动轴一样不就好了"): 两边都是【R切小卡的 A2 之后接着打到 A4】,
        # 起点完全相同 —— 而我这里传的是 CART_A_TO_SWORD_CAP(2.60), 启动轴传的是
        # O_CART_A_TO_SWITCH(0.90)。神权剑那个判据实机一直读不到、每次跑满窗口,
        # 所以这 1.7 秒的差直接变成了交棒延迟
        self.switch_on_a4_launch(rover, cap=self.O_CART_A_TO_SWITCH)

    # ==================== 框架接口 ====================

    def do_perform(self):
        """卡提在场时框架会调这里。

        启动轴由她自己起跑(轴的第一个动作就是她的 R); 循环轴由风主起跑
        (上一圈结尾把他变奏出来), 所以循环阶段走到这里就说明宏散了
        (切人失败 / 脱战重进) —— 打一小段普攻把场子交出去, 让风主重新拿到入口。

        【不要在这里跑循环轴】: 循环轴的第一步假设风主刚变奏入场, 从卡提这里起跑
        一定错位。
        """
        if not self.is_in_cart_cycle:
            return super().do_perform()
        self.check_f_on_switch = False
        blocked = self.opener_blocked_by()
        if blocked is None:
            # 【标记要在跑之前落】: perform_opener 中途抛异常(脱战/任务被停)也不能
            # 让启动轴重跑 —— reset_state 会把 armed 重新置回来
            self.opener_armed = False
            self.last_opener = time.time()
            if self.perform_opener(self):
                return
            self.logger.warning('cartethyia opener aborted, falling back to the native rotation')
            return super().do_perform()
        self.logger.info(f'cartethyia: opener not pending ({blocked}), handing the field back')
        self.continues_normal_attack(0.6)
        return self.switch_next_char()

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        """启动轴待跑时卡提【必须】先上场 —— 轴的第一个动作是她的 R。

        【这里别打 INFO 日志】: 框架会对每个候选反复调用, 会刷屏。
        """
        if self.is_in_cart_cycle and self.opener_pending():
            return SwitchPriority.MUST
        return super().get_switch_priority(current_char, has_intro, target_low_con)

    def on_combat_end(self, chars):
        self.release_attack()
        self.poking = False
        self.cur = None
        return super().on_combat_end(chars)
