import cv2
import numpy as np
from ok import color_range_to_bound

from src.char.BaseChar import BaseChar, SwitchPriority


class Verina(BaseChar):
    """持续尝试大招直到成功 -> E -> 声骸 -> 地面A到回路两格 -> 跳跃 -> 空中A到协奏满;
    不区分普通/变奏入场，协奏满后优先固定切洛瑟菈。"""

    ATTACK_INTERVAL: float = 0.1
    INTRO_LIBERATION_RETRY: float = 0.1
    NEXT_CHAR_NAME: str = 'char_lucilla'

    def do_perform(self):
        self.perform_combat()
        if not self.concerto_full():
            self.logger.warning('verina concerto is not full, staying on field')
            return
        self.switch_to_lucilla()

    def concerto_full(self):
        """确认协奏满后缓存结果，避免切人前重复识别造成延迟。"""
        if self.is_con_full():
            self.current_con = 1
            return True
        return False

    def cast_liberation_until_success(self):
        """持续尝试释放大招；R 未成功前不进入后续流程。"""
        while True:
            self.check_combat()
            if self.click_liberation(wait_if_cd_ready=0):
                return
            self.sleep(self.INTRO_LIBERATION_RETRY)

    def switch_to_lucilla(self):
        """队伍中有洛瑟菈则固定切她，否则使用框架选人逻辑。"""
        target = next(
            (char for char in self.task.chars
             if char is not None and char.char_name == self.NEXT_CHAR_NAME),
            None,
        )
        if target is None:
            self.switch_next_char()
            return

        choose_target = self.task._choose_switch_target
        self.task._choose_switch_target = lambda *args, **kwargs: target
        try:
            self.switch_next_char()
        finally:
            self.task._choose_switch_target = choose_target

    def forte_bar_visible(self, image):
        """识别单格维里奈黄色回路。"""
        height, width = image.shape[:2]
        if height == 0 or width < 64 or not np.array_equal(np.unique(image), [0, 255]):
            return False

        profile = np.sum(image == 255, axis=0).astype(np.float32)
        profile -= np.mean(profile)
        spectrum = np.abs(np.fft.fft(profile))
        frequency = int(np.argmax(spectrum[1:]) + 1)
        amplitude = spectrum[frequency]
        self.logger.debug(f'verina forte with freq {frequency} & amp {amplitude}')
        return 39 <= frequency <= 41 or amplitude >= 50

    def has_two_forte_bars(self):
        """判断维里奈共鸣回路是否已有至少两格。"""
        box = self.task.box_of_screen_scaled(
            3840, 2160, 1633, 2004, 2160, 2016,
            name='verina_forte', hcenter=True,
        )
        cropped = box.crop_frame(self.task.frame)
        lower_bound, upper_bound = color_range_to_bound(VERINA_FORTE_COLOR)
        image = cv2.inRange(cropped, lower_bound, upper_bound)
        step = image.shape[1] // 4
        return step > 0 and self.forte_bar_visible(image[:, step:step * 2])

    def attack_until_two_forte_bars(self):
        """每次普攻前检查回路，达到两格后进入空中攻击。"""
        while not self.has_two_forte_bars():
            self.check_combat()
            self.click_with_interval(self.ATTACK_INTERVAL)

    def attack_until_concerto_full(self):
        """空中持续普攻，直到协奏满。"""
        while not self.concerto_full():
            self.check_combat()
            self.click_with_interval(self.ATTACK_INTERVAL)

    def perform_combat(self):
        """R -> E -> 声骸 -> 地面A到回路两格 -> 跳跃 -> 空中A到协奏满。"""
        self.cast_liberation_until_success()
        self.cast_resonance()
        self.cast_echo()
        self.attack_until_two_forte_bars()
        self.task.jump(after_sleep=0.01)
        self.attack_until_concerto_full()

    def cast_resonance(self):
        """共鸣(E)可用则放。"""
        if self.resonance_available():
            self.click_resonance(send_click=True, time_out=0)

    def cast_echo(self):
        """声骸可用则放。"""
        if self.echo_available():
            self.click_echo(time_out=0)

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        if has_intro and current_char and current_char.char_name in {'char_hiyuki'}:
            return SwitchPriority.MUST
        return super().get_switch_priority(current_char, has_intro, target_low_con)


VERINA_FORTE_COLOR = {
    'r': (240, 255),
    'g': (220, 255),
    'b': (100, 160),
}
