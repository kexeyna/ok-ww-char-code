import time

from src.char.ShoreKeeper import ShoreKeeper as NativeShoreKeeper
from src.char.Xigelika import Xigelika as NativeXigelika


class Xigelika(NativeXigelika):
    """西格莉卡 —— 西仇守「25s 轮椅轴」的主 C, 也是整条轴的收尾。

    轮换环: 守岸人 -> 仇远 -> 西格莉卡 -> 守岸人。她这一棒最长, 而且【开场那一下
    和站场那一段是两件完全不同的事】, do_perform 按有没有带变奏进场分流:

      * 空手入场 (开局第一帧, 或者轮换散了) -> opener_toss():
        只丢一个声骸吃一层增伤, 然后立刻把场子交给守岸人去攒协奏。
        视频 t=1.83 按 Q, t=2.87 切人; 字幕「开局西格莉卡先丢个声骸技能」「获得一层增伤」。

      * 带变奏入场 -> main_axis(): 下面这一整套。

    轴的来源: E:\\轴视频\\西仇守.mp4。时间是墙钟秒。启动轴和循环轴对她来说只差一处:
    启动轴的 Q 在开局就用掉了(冷却 70 秒), 所以那一轮开头只有 R;
    循环轴是 Q + R 一起。代码里两条走同一条路 —— 冷却上的 Q 按下去是空操作。

                                     启动轴            循环轴
        (Q +) R                   25.70 - 33.90     73.90 - 80.97
        E + a3a4 + 强化A           (跟上一格同属一个步骤条格子)
        回路重击 + 闪避             34.03 - 39.57     81.00 - 82.47
        一套普攻(4A) + 强化A         40.40 - 43.20     82.50 - 86.40
        回路重击 (+ 补 Q)           43.23 - 46.17     86.60 - 87.40
        回路E (长按)               46.20 - 48.57     88.20 - 89.97
        A + 处决                   48.60 - 50.30     90.00 - 91.40
        -> 变奏守岸人               50.33 - 52.90     91.43 - 92.50

    循环轴逐帧节点 (技能栏冷却数字为证, 她的 E 冷却 10 秒、R 冷却 25 秒):
        73.90  变奏入场
        74.35  Q          74.80  R (75.2 - 77.4 大招演出)
        77.45  E          <- 字幕「这里E技能可以打断大招后摇」
        78.6 / 79.2  a3 a4
        80.4   强化A       81.0 - 82.2  回路重击     82.2  闪避
        82.8 - 85.5  一套普攻(4A)        85.8  强化A
        86.6 - 87.4  回路重击            88.2 - 90.0  回路E(长按)
        90.3   普攻 + 处决               91.4  变奏守岸人

    字幕原文: t=26.0「西格莉卡直接释放大招」 t=28.8「然后E技能」
    t=30.3「这里E技能可以打断大招后摇」 t=33.0「接着打a3a4+强化A」
    t=35.5「强化A的时候按住普攻释放回路重击」 t=38.3「回路重击招式出来后马上闪避」
    t=39.5「打断后摇」 t=40.5「然后再打一套」 t=43.0「强化A+回路重击」
    t=45.0「释放回路重击的时候长按E技能」 t=46.9「这样可以直接衔接回路技能」
    t=48.1「出招更快」 t=49.4「回路技能第二段伤害出来后」 t=50.5「普攻+处决」。

    【视频里那个 UP 主的小抄跟画面对不上的一处】: 循环轴的步骤条第 9 格写的是
    「西 | E-2A-强化A」, 但同一段的字幕写的是「一套普攻+强化A」, 而技能栏的 E 冷却
    从 79.0 秒的 8.4 一路数到 85.0 秒的 2.4 中间没有跳回去过 —— 那一段【没有按 E】。
    攻略图上写的也是「4A+强化A」。所以这里按 4A 实现, 步骤条那个 E 当笔误。
    """
    # ================================================================ 固定顺序切人 (公共段)
    # 这一段在 Xigelika.py / Qiuyuan.py / ShoreKeeper.py 三个文件里逐字一样, 改一处记得同步改三处。
    # (跟 Chisa__Suisui__YangYangSp 那队的三份也是逐字一样的, 那边改了这边最好跟。)
    # 下面各自的常量写在这一段【之后】, 所以子类想覆盖哪个直接在下面重写就行。
    #
    # 为什么不用框架的 switch_next_char():
    #   1. 它按 get_switch_priority() 现场挑人, 顺序会漂 —— 这套轴要求死顺序;
    #   2. 它内部有三处补普攻 ("performing too fast add a normal attack"、维持锁定、
    #      切换未检测到时补点击), 打完最后一下想立刻走人时那几下 A 会把节奏拖乱。
    # 代价是框架的交接记账要自己补, 全在 handoff_to() 里。

    SWITCH_TIMEOUT: float = 2.0        # 单程切人的最长尝试时间 (秒)
    SWITCH_KEY_INTERVAL: float = 0.12  # 连按数字键的间隔 (秒)
    # 切到之后等角色站稳的时间 (秒)。很敏感 —— 实测 0.50 / 0.52 会让下一个角色的起手被吞,
    # 0.55 才稳, 别再往下压
    SWITCH_SETTLE: float = 0.55
    SETTLE_ATTACK_INTERVAL: float = 0.42
    HANDOFF_CON_WAIT: float = 0.8      # 交接时等协奏读数稳定的上限 (秒)
    HANDOFF_CON_POLL: float = 0.1
    HOLD_POLL: float = 0.1             # 长按期间轮询条件的间隔 (秒)
    # 切走前按 F 处决 —— 框架 switch_next_char() 里有 current_char.f_break(True), 直接
    # 按数字键切人会绕开它。这套轴里默认【关掉】: handoff_to() 是在 switch_to_index()
    # 之后调的, 那时候下一个角色已经站上场了, 这一下 F 会被他吃掉, 而且发生在他的 R
    # 之前 (千咲"还没按 R 就开处决"就是这么来的)。处决统一由千咲在 R 之后接
    F_BREAK_ON_HANDOFF: bool = False

    # 别人用 handoff_to() 直接切给我时打的标记, 写成类属性省掉 __init__。
    # 不能只靠 has_intro —— reset_state() 每次重读队伍都会把它清成 False, 而战斗判定
    # 一抖动就会重进战斗、重读队伍, 于是角色以为自己空手入场, 跑去走开场那套流程
    intro_pending = False
    # 切人【真正完成】那一刻的时间戳 —— in_team 认出换人成功的那一帧, 不是
    # settle_with_attack 站稳之后。循环轴的落地E 就按这个锚点计时, 差 0.55 秒
    # 就会掉进"E 按在下落段完全没反应"的失败区
    switch_confirmed_at = 0.0

    def note_intro_handoff(self):
        """被别人用直接切人的方式交接进场时调用 —— 记下"我是带着变奏上来的"。"""
        self.intro_pending = True

    def take_intro(self):
        """本次入场是否带着变奏。读完就清, 避免下一轮误判。"""
        intro = self.has_intro or self.intro_pending
        self.intro_pending = False
        return intro

    def reset_fixed_rotation(self):
        """战斗结束时调 —— 在各自的 on_combat_end() 里。"""
        self.intro_pending = False

    def direct_switch(self, slot=None, assume_intro=False):
        """按数字键直接切到指定队伍位置 (1-based), 并自己补上框架的交接记账。

        Args:
            slot: 不传就用 NEXT_SLOT。
            assume_intro: True 时不读协奏, 直接认定是满的。刚放完大招要用这个 ——
                能量环读数滞后会把 has_intro 误判成 False, 下一个角色就拿不到变奏增益。
        """
        slot = self.NEXT_SLOT if slot is None else slot
        if slot is None:
            return False
        target = self.char_at_slot(slot)
        if target is None or target is self:
            return False

        has_intro = True if assume_intro else self.wait_con_full()
        if not self.switch_to_index(target.index):
            self.logger.warning(f'direct switch to slot {slot} failed')
            return False
        self.logger.info(f'direct switched to slot {slot} ({target.char_name}, intro={has_intro})')
        self.handoff_to(target, has_intro)
        return True

    def switch_to_index(self, index):
        """按数字键切到指定队伍位置, 直到 in_team 确认切过去了。

        点击落在谁身上就由谁打出来, 所以等待期间也保持点普攻, 两边连段都不断档。
        """
        start = time.time()
        while time.time() - start < self.SWITCH_TIMEOUT:
            in_team, current_index, _ = self.task.in_team()
            if in_team and current_index == index:
                # 【先记时间戳再站稳】: settle_with_attack 要花 SWITCH_SETTLE 秒,
                # 记在它后面的话锚点整体晚 0.55 秒, 靠锚点计时的动作全跟着晚
                self.switch_confirmed_at = time.time()
                self.settle_with_attack(self.SWITCH_SETTLE)
                return True
            self.task.send_key(index + 1)
            self.click()
            self.sleep(self.SWITCH_KEY_INTERVAL, check_combat=False)
        return False

    def settle_with_attack(self, duration):
        """等 duration 秒, 期间保持点普攻, 不干等。"""
        end = time.time() + duration
        while time.time() < end:
            self.click()
            self.sleep(min(self.SETTLE_ATTACK_INTERVAL, max(0.0, end - time.time())),
                       check_combat=False)

    def handoff_to(self, target, has_intro):
        """把场上角色交接给 target —— 复刻 switch_next_char() 内部那套记账。

        直接按数字键切人绕开了框架的交接逻辑, 必须自己补上, 否则:
          - 没人的 is_current_char 是 True → get_current_char() 返回 None → 下一帧崩溃;
          - has_intro / last_outro_time 不更新, 下一个角色拿不到变奏。
        """
        if self.F_BREAK_ON_HANDOFF:
            self.f_break(check_f_on_switch=True)
        self.task.in_liberation = False
        self.switch_out(con_full=has_intro)
        target.is_current_char = True
        target.has_intro = has_intro
        if has_intro and hasattr(target, 'note_intro_handoff'):
            # has_intro 是易失的, 再给对方补一个它自己保管的持久标记
            target.note_intro_handoff()
        # 用 in_team 确认那一刻, 不是现在 —— 中间隔着 settle_with_attack 那 0.55 秒
        target.last_switch_in_time = self.switch_confirmed_at or time.time()
        self.switch_confirmed_at = 0.0
        if has_intro:
            now = time.time()
            self.task.add_freeze_duration(now, target.intro_motion_freeze_duration, -100)
            self.last_outro_time = now

    def wait_con_full(self):
        """短暂轮询协奏是否满 —— 用来决定交接时给不给对方变奏。

        不能只读一次: 打完最后一下那一刻协奏其实已经满了, 但能量环读数滞后。
        必须在【按切人键之前】读: 切走之后能量环显示的已经是新角色的了。
        """
        start = time.time()
        while time.time() - start < self.HANDOFF_CON_WAIT:
            if self.is_con_full():
                return True
            self.sleep(self.HANDOFF_CON_POLL, check_combat=False)
        self.logger.info(f'con not full before switch (con={self.get_current_con()}), '
                         f'next char gets no intro')
        return False

    def char_at_slot(self, slot):
        """按队伍位置 (1-based) 取角色, 越界返回 None。"""
        index = slot - 1
        for char in self.task.chars:
            if char is not None and char.index == index:
                return char
        return None

    def attack_chain(self, count, interval, last_interval=None):
        """点按普攻打一轮连段。

        Args:
            last_interval: 最后一段之后的间隔。后面紧接切人时传更小的值 —— 按下切人键之后
                还要等游戏识别切换完成, 那段时间最后一下的动作照样在演, 两者是重叠的。
        """
        for i in range(count):
            self.click()
            if i == count - 1 and last_interval is not None:
                self.sleep(last_interval)
            else:
                self.sleep(interval)

    def hold_until(self, cond, timeout, name):
        """轮询某个条件, 期间不动手 —— 攻击键的按下/松开由调用方管。"""
        start = time.time()
        while self.time_elapsed_accounting_for_freeze(start) < timeout:
            if cond():
                self.logger.info(f'{name} ready after '
                                 f'{self.time_elapsed_accounting_for_freeze(start):.1f}s')
                return True
            self.sleep(self.HOLD_POLL)
        self.logger.info(f'timed out waiting for {name} ({timeout:.1f}s)')
        return False


    # ---------------------------------------------- "没打到就不许切人" 的硬 gate
    # 这套轴是靠变奏/延奏一棒接一棒串起来的: 任何一棒少做一步, 代价都直接传给下一棒。
    # 实测 21:23 那一圈就是完整的传染链:
    #   穗穗 forte3 没读到 -> 硬走 Q/R -> "liberation not ready, leaving without field"
    #   -> 领域没放, 千咲上场 -> "chisa: liberation not ready" -> 整圈裸打。
    # 所以关键步骤不再"到点就走", 改成留场重试到真打出来为止。
    #
    # 【没有超时是有意的】: 给上限就等于"打不出来也走", 那这个 gate 等于没有。
    # 唯一的出口是 check_combat() —— 脱战/任务被停时它抛异常, 整条轴一起退出。
    # 怪都没了的话, "这一步没打到"本来也就不是问题了。
    GATE_POLL: float = 0.12       # gate 轮询间隔 (秒)
    GATE_LOG_EVERY: float = 3.0   # 卡住时每隔这么久打一条日志, 好在日志里一眼看出卡在哪

    def require(self, name, cond, action=None, timeout=0):
        """留场直到 cond() 成立 —— 这一步没做到就不许往下走。

        Args:
            name: 打日志用的步骤名, 卡住时就是靠它定位。
            cond: 判据, 返回真就放行。
            action: 每轮做的事, 一般传 self.click。不传就是干等 (长按期间要用这个,
                手上已经按着了, 再 click 会打断长按)。
            timeout: >0 时的上限 (秒), 到点放行并返回 False。默认 0 = 不设上限。
                【什么时候该给上限】: 这一步做不到时"照走"能自愈的, 就必须给 ——
                比如协奏没满只是让下一棒退回启动轴(那条轴本来就为空手入场准备),
                而卡死在这里不能自愈。实测 01:18 那轮 fill_con 无上限直接把任务挂住了。

        Returns:
            bool: 条件成立返回 True; 到 timeout 放弃返回 False。
        """
        start = time.time()
        last_log = 0.0
        while True:
            if cond():
                waited = self.time_elapsed_accounting_for_freeze(start)
                if waited > 0.3:
                    self.logger.info(f'gate [{name}] ok after {waited:.1f}s')
                return True
            self.check_combat()
            if action is not None:
                action()
            elapsed = self.time_elapsed_accounting_for_freeze(start)
            if timeout > 0 and elapsed >= timeout:
                self.logger.warning(f'gate [{name}] gave up after {elapsed:.1f}s, moving on')
                return False
            if elapsed - last_log >= self.GATE_LOG_EVERY:
                last_log = elapsed
                self.logger.warning(f'gate [{name}] not satisfied after {elapsed:.1f}s, '
                                    f'staying on field')
            self.sleep(self.GATE_POLL)

    def require_cast(self, name, send, landed, pre=None, timeout=0):
        """反复按某个键直到它真的放出去了。

        跟 require() 的区别: 这里每轮都【重新发键】。被打断时按键会被游戏吃掉,
        补发是唯一的解法。
        Args:
            send: 发键的函数。
            landed: 判据 —— "已经放出去了"返回真。
            pre: 发键之前必须先成立的条件 (比如"图标亮了"), 不成立就先不发, 省得
                在冷却里空按。不传就是每轮都发。
            timeout: >0 时的上限 (秒), 到点放弃并返回 False。默认 0 = 不设上限。
        """
        start = time.time()
        last_log = 0.0
        while True:
            if landed():
                waited = self.time_elapsed_accounting_for_freeze(start)
                self.logger.info(f'gate [{name}] cast confirmed after {waited:.1f}s')
                return True
            self.check_combat()
            if pre is None or pre():
                send()
            elapsed = self.time_elapsed_accounting_for_freeze(start)
            if timeout > 0 and elapsed >= timeout:
                self.logger.warning(f'gate [{name}] gave up after {elapsed:.1f}s, moving on')
                return False
            if elapsed - last_log >= self.GATE_LOG_EVERY:
                last_log = elapsed
                self.logger.warning(f'gate [{name}] not cast after {elapsed:.1f}s, retrying')
            self.sleep(self.GATE_POLL)

    # ============================================================ 公共段结束

    # ================================================================ 西仇守: 西格莉卡这一棒

    # ---- 时间常量。来自视频墙钟, 单位秒 ----
    INTRO_ANIM = 0.45       # 变奏入场 -> 该按 Q。视频: 73.90 -> 74.35
    ECHO_TO_LIB = 0.05      # Q -> R。fire_echo 自己就要花几百毫秒连发, 这里不用再等
    # Q 连发几次。【读屏只用来提前收手, 不用来提前放弃】(2026-08-25 实机: "Q又没放"):
    # 上一版一读到"在冷却"就只发一次走人 —— 读错一次这一轮就没 Q 了。
    # 用户原话「多按几次, 西格莉卡Q是脱手的, 不会打断角色」, 所以改成【无条件按满】,
    # 只有真的确认放出去了(进来是好的、现在读到冷却)才提前停
    ECHO_TRIES = 5
    ECHO_RETRY = 0.12       # 5 x 0.12 = 0.6 秒封顶 (视频里 Q->R 是 0.45 秒)
    LIB_TO_E = 0.05         # 大招演出结束 -> E。字幕说这一下是拿来打断大招后摇的,
                            # click_liberation() 本来就会阻塞到回到队伍界面才返回,
                            # 所以这里几乎不用等
    E_TO_A = 0.60           # E -> 开始点普攻。E 的动画会吞掉前面几下, 但不吞完
    A_INTERVAL = 0.18       # 普攻节奏。框架自己的 continues_normal_attack 用的是 0.1
    FORTE_POLL = 0.05       # 轮询回路指示器的间隔。现在判据是【算颜色占比】不是找图,
                            # 一次只算一个 140x120 的小框, 比模板匹配便宜得多, 可以放密
    # ---- 强化重击的按住时长, 分两段算 ----
    # 【锚点是"黄灭了"那一刻, 不是"按下"那一刻】(2026-08-25 实机第七轮改)。
    # 视频实测: 黄 81.1 出现 -> 81.3 就没了, 也就是【按下去回路马上被吃掉】,
    # 重击是那时候起手的。原来从"按下"起算 1.3 秒, 中间混进了不确定的起手延迟,
    # 于是松手/闪避/接E 的时刻整体飘。
    HEAVY_START_WAIT = 0.6  # 按下之后等"黄灭"(= 重击起手)的上限。实机实测这个延迟是 0.13 / 0.20 秒
    # 起手之后再按住多久才松手。【0.9 太短, 会把重击截断】(2026-08-25 实机):
    # 视频里重击本身要 1.2 秒 (81.0 -> 82.2), 0.9 秒松手等于打了一半就收 ——
    # 第一段"闪避没接上反而愣了一会"和第二段"直接没打重击"都是这一个数造成的。
    # 松手那一刻就是闪避发出去的时刻, 所以这个值同时也是"闪避相对起手的偏移量",
    # 视频里玩家是在起手后约 1.2 秒闪的。要调闪避早晚就调它,
    # 日志里 `dodge at +X.XXs` 会把实际偏移打出来
    HEAVY_AFTER = 1.20
    # 松手之后隔多久按闪避 (2026-08-25 用户指定: "闪避在强化重击后 0.3s 按")。
    # 按下闪避的同一时刻就开始持续普攻, 见 after_heavy_dodge()
    DODGE_DELAY = 0.30
    # 【第二个重击 -> 回路E 之间必须留间隔】(2026-08-25 实机: "总是强化E放了才打强化重击"):
    # 原来松手后 0.15 秒就长按 E, E 是瞬发的, 直接插到重击动画里去了, 看起来就是
    # E 先出、重击后出, 而且重击被打断还得重来, 更慢。
    # 最后一个强化重击 -> 回路E 的间隔。【实机调出来的, 别照视频改回去】:
    # 视频里量出来是 0.8 秒 (第二个重击 86.60-87.40, 回路E 88.20 才开始),
    # 但那是人手的节奏; 实机 1.00 -> "慢了", 0.70 -> 还是"慢了", 定在 0.30。
    # (下限在 0 附近: 太贴着松手按, E 会插进重击的动画里, 变成"E先出、重击后出")
    # 0.30 实机还是"衔接等的太久了" -> 0.15。
    # 这一段之外还有两笔开销要一起算: heavy_loop 退出前确认 E 就绪的 FORTE_E_CHECK,
    # 和 forte_resonance 里的重复读屏(已经用 confirmed 干掉了)
    # 0.30 -> 0.15 -> 0.05 -> 0: 用户四次都说"还能更快"。
    # 敢压到 0 是因为按 E 之前是【确认过 e_forte 那一格显示成字母E】的,
    # 而那一格只在重击打完、回路满了之后才变 E —— 不会再插进重击的动画里。
    # 现在衔接时间几乎全部来自"确认"那一步, 见 FORTE_E_POLL
    HEAVY_TO_FORTE_E = 0.0
    # 【闪避彻底不做了】(2026-08-25 用户最终决定):
    #   「没办法确认是不是真打出去了, 因为有可能在打的过程中就被打断, 这样我们也不闪避了」
    # 根子上的问题是: 我能读出"强化重击起手了", 读不出"它有没有被打断" ——
    # 而闪避的价值完全取决于"重击到底打完没有", 判不出来就不该赌。
    DODGE_AFTER_HEAVY: bool = False
    # 第二轮的 (Q) 补刀之后到第一段普攻。她的声骸 70 秒冷却, 循环里多半在冷却上,
    # fire_echo 会走"发一次就返回"的快路径, 所以这里给 0 —— 闪完马上 A
    ECHO_TO_A = 0.0
    # 回路E 的长按时长。【0.60 实机疑似没触发长按】—— 游戏一般 0.3~0.5 秒算长按,
    # 但按键是 PostMessage 投进去的, 中间还隔着窗口的输入采样, 留足余量更保险
    FORTE_E_HOLD = 0.90
    FORTE_E_SETTLE = 0.20   # 松开 E 之后等多久再去读"E 进冷却了没有"
    FORTE_E_TRIES = 2       # 长按没放出去就再来一次
    # 回路E 长按完之后留给动画收尾的时间。1.60 -> 0.50 -> 0.20:
    # 用户 2026-08-25 两次都说太长("强化E放完会发呆" / "1S也太长了")
    FORTE_E_TO_BREAK = 0.20
    # 找处决提示的【窗口】。0 = 只看一帧, 不开窗口。
    # 用户 2026-08-25: 「直接检测有没有F, 没有就过切人就行。一般怪不死都是有的,
    #   就算错过了让守岸人打就是了」。1.4 -> 0.5 -> 0(只看一帧)
    BREAK_WINDOW = 0.0
    OPEN_ECHO_TO_SWITCH = 0.05
    # 【协奏没满就走人是整条轴最贵的失败】: 下一棒守岸人就拿不到变奏, 多打一整组。
    # 实机日志里 26 次 `con not full before switch`, 读数 0.74~0.97 —— 全是差一点。
    # 所以这道闸放宽, 而且下面还加了"协奏没满就接着补强化重击"的额外轮次,
    # 等协奏的这段时间不再是站着平A
    CON_GATE_TIMEOUT = 8.0
    # ---- 强化重击的轮次: 【不写死打几轮, 靠"强化E好了"收尾】 ----
    # (2026-08-25 用户定的保底方案, 原话:
    #  「前面只管A, 看到重击亮了长按重击, 一直到最后强化E亮起, 说明走到最后一段了,
    #    那就是要第二段强化重击接E, 切人」)
    # 好处是整段不再依赖"这一轮的重击到底打没打出去"这个我判不出来的东西 ——
    # 被打断就多打一轮, 反正退出条件是强化E, 不是轮数。
    MIN_HEAVY_ROUNDS = 2     # 至少打出这么多个重击再开始看"强化E好了没"(轴本来就是两个)
    # 每打完一个重击, 花这么久确认"E 是不是刚变黄"。
    # 【必须在打完之后判】: 重击是攒回路的, 回路满 E 才变黄, 所以功劳要打完才看得见。
    # 给 0.25 秒是留给回路到账 + 判据去抖(连读 2 帧); 已经黄了的话 0.1 秒就返回
    FORTE_E_CHECK = 0.25
    # 确认"强化E 变黄"时的轮询间隔。【衔接快不快就看这个数】:
    # 去抖要连读 FORTE_CONFIRM(2) 帧, 每帧等一个轮询间隔,
    # 所以最小检测延迟 = 2 * FORTE_E_POLL。用普通的 0.05 就是 0.10 秒起,
    # 压到 0.01 之后是 0.02 秒起 —— 加上 next_frame 的开销, 实测衔接 0.13 -> 0.05 秒。
    # 【别把 FORTE_CONFIRM 降到 1 来提速】: 去抖是防特效闪光误判的, 那个坑踩过
    FORTE_E_POLL = 0.01
    # 【整段只有这一个总预算, 没有"每轮超时"】(2026-08-25 用户: "要持续检测啊,
    # 不要过了个点就不重击了开始点按了")。上一版是分轮 + 每轮 6 秒超时 + 最多 5 轮,
    # 被怪打断几次就把轮次耗光, 然后剩下的时间纯点普攻、再也不重击了 ——
    # "没跑完就切人"就是这么来的。现在改成一个从头跑到尾的循环, 黄一亮就长按,
    # 退出条件只有"强化重击和强化E同时是黄的"; 这个预算只是防判据失灵时永远不出来
    HEAVY_LOOP_BUDGET = 20.0
    CON_FILL_SLICE = 1.0     # 等协奏满时, 每次先打这么久普攻再回头看一眼协奏
    # hold_heavy() 每次松手时写进来的"这一下按住了多久(从起手算)", 只用来打日志。
    # 【写成类属性是为了它在第一次按住之前也存在】—— 不然静态检查扫不出来,
    # 而且哪天有人把 getattr 的默认值去掉就会炸
    heavy_hold_after = -1.0
    SWITCH_ANCHOR_MAX = 1.5
    # ---- 离场 (见 leave() 的注释: 处决之后切人 7/7 全失败) ----
    SWITCH_TIMEOUT = 3.0     # 覆盖公共段的 2.0 —— 演出之后队伍 HUD 要多给点时间
    TEAM_HUD_WAIT = 2.5      # 按数字键之前先等 HUD 渲染回来的上限
    LEAVE_TRIES = 2          # 直接切人失败重试几次, 之后才掉回框架

    # ======================= 强化普攻 / 强化重击 指示器 =======================
    # 【2026-08-25 用户给了截图, 位置终于定死了】
    # 就是技能栏最左边那一格 (骷髅目标图标的右边、声骸装置的左边, E 往左数第二格):
    #     绿色光环 + 拳头图标  = 强化普攻可用
    #     金黄光环 + 剑刃图标  = 强化重击可用
    #     没光环(暗)           = 都不能放
    # 位置是拿视频里的 E/Q/R 三个已知框 (box_resonance/box_echo/box_liberation) 做锚点
    # 反算出来的: 视频里这一格中心在 x=957, 而 E=1081 / Q=1145 / R=1210,
    # 拟合出 norm = 0.0276 + 0.000758 * video_x  ->  这一格 norm ≈ 0.7356 ~ 0.7720,
    # 换算到 3840x2160 就是下面的 (2824,1875)-(2962,1995)。
    # 交叉验证: 它正好落在 assets 里 box_extra_action [2586,1846,375,161] 的右半边 ——
    # 那个框太宽(盖住了左边两格), 所以自己开一个窄的。
    FORTE_ICON = (2824, 1875, 2962, 1995)

    # 光环颜色 —— 【按"通道之间差多少"算, 不用绝对的 r/g/b 区间】。
    # (2026-08-25 实机第六轮改。)
    # 绝对区间的毛病: HUD 泛光会把光环的芯整个吹成白色 —— probe 里那行
    # `rgb=252,250,246` 就是。蓝通道一旦被抬过区间上限, 那一片就整个不算数了。
    # 同一个"黄亮着"的状态, 两场实机差了一倍多:
    #     13:30  y=0.11~0.23        13:44  y=0.02~0.08 (场景更亮, 于是漏判, 一直平A)
    # 改成看"红/绿比蓝高多少": 金色不管多亮, 蓝通道总是明显低于红绿; 纯白三通道齐平,
    # 自然被排除。拿视频那一格对比过, 分离度好一大截:
    #     绝对区间   亮 0.03~0.19 / 不亮 0.00
    #     通道差     亮 0.19~0.66 / 不亮 0.00      <- 用这个
    YELLOW_RB = 35      # 红 - 蓝 至少差这么多
    YELLOW_GB = 20      # 绿 - 蓝 至少差这么多
    YELLOW_MIN_R = 140  # 太暗的像素不算
    GREEN_GR = 25       # 绿 - 红 (绿只用来打日志, 不参与判断)
    GREEN_GB = 10
    GREEN_MIN_G = 140
    GREEN_MIN = 0.12
    # 通道差算法下: 亮的时候 0.19~0.66, 不亮的时候是硬 0.00 —— 0.10 留了很大余量
    YELLOW_MIN = 0.10
    # 判据连读多少帧一致才认。【别去掉】: 上一版用单帧找图, 被特效闪光骗到,
    # 点下 A 才 37 毫秒就判定"强化普攻已经打出去了"。颜色比找图稳, 2 帧够了
    FORTE_CONFIRM = 2

    # 一直点 A 等黄亮的上限。这一段里回路是靠普攻攒起来的, 实测要 3~4.5 秒,
    # 所以给得松一点; 但【不能给 0(不设上限)】—— 阈值万一不灵就是永久卡死。
    # 到点就往下走, 后面的回路E / 处决 / 切人照常
    ENHANCED_WAIT = 10.0
    # ---- 重击预输入 (2026-08-25 用户要求: "正常来说应该在强化普攻时就开始长按重击
    #      预输入, 这样打的更快") ----
    # 打开时, 等黄的那段普攻不是"点一下就松", 而是【按住 PREINPUT_HOLD_TIME 再松】,
    # 按住期间照样在轮询: 黄一亮【就不松手了】, 直接接进强化重击 ——
    # 等于强化普攻还在演的时候手就已经按下去了, 重击不用再等我先按一次。
    # 按住时长压在 0.15 秒是怕被判成蓄力重击(那个一般要 0.3 秒以上)。
    # 觉得连段变味了就把它关掉, 退回一下一下点。
    # 【默认关掉】(2026-08-25 实机: "中间有段A的断断续续的, 尤其是被打断了以后"):
    # 按住 0.15 秒再松这个节奏, 游戏很可能当成"想蓄力又放弃", 连段接不上去,
    # 表现就是普攻一顿一顿的。省下的那点检测延迟不值这个价 ——
    # 黄的轮询本来就是 0.05 秒一次, 慢不了多少。
    # 想再试就打开, 顺便把 PREINPUT_HOLD_TIME 往下压(0.10 试试)。
    PREINPUT_HOLD: bool = False
    PREINPUT_HOLD_TIME = 0.15
    PREINPUT_GAP = 0.05
    HEAVY_TRIES = 2          # 一轮里"按住"最多试几次 (黄还亮着就再按一次)
    # 两次按住都没起手就整轮重来: 回去继续 A、等黄重新亮, 再按。
    # 用户要的"重击被打断要继续尝试"是这一层 —— 光重按没用, 被打断之后要重新攒
    CYCLE_TRIES = 2
    # 长按E 之前等 e_forte 提示的上限。【别给太长】: 这个模板时灵时不灵
    # (实机既出现过 `after 0.07s` 也出现过 `prompt not seen`), 等不到就该直接按,
    # 1.5 秒的等待纯粹是白站
    FORTE_E_WAIT = 0.5
    FORTE_LOG_EVERY = 3.0

    # 视频里 UP 主是在回路重击【还在演的时候】就长按 E 抢时间的
    # (字幕「释放回路重击的时候长按E技能 / 这样可以直接衔接回路技能 / 出招更快」)。
    # 这里默认【先按完重击再按 E】: 按住鼠标期间发键有把长按打断的风险 ——
    # PostMessage 后端的 send_key 会投一条 WM_ACTIVATE, 窗口收到就可能松开左键。
    CHAIN_E_INTO_HEAVY: bool = False


    @property
    def NEXT_SLOT(self):
        """打完切守岸人。按类找人, 不写死队伍位置。"""
        for char in self.task.chars:
            if isinstance(char, NativeShoreKeeper):
                return char.index + 1
        return None

    def reset_state(self):
        super().reset_state()
        # 【必须写在 reset_state 里】: 换类时 __dict__.update 会把"内置也有、我改了值"
        # 的字段打回内置值。她不是治疗, 内置的 check_f_on_switch 是 True ——
        # 不重申的话框架会在切人时替她再按一次 F, 把 execute_break() 刚打完的处决重放
        self.check_f_on_switch = False

    def on_combat_end(self, chars):
        self.reset_fixed_rotation()
        super().on_combat_end(chars)

    # ------------------------------------------------------------------ 路由

    def do_perform(self):
        intro = self.take_intro()
        self.check_f_on_switch = False
        if self.flying():
            self.wait_down()
        if not intro:
            # 空手入场 = 要么是开局第一帧, 要么是轮换散了。两种情况的处理是一样的:
            # 她的整条轴都建立在"带变奏 + 大招能量满"之上, 硬打是白打, 不如把场子
            # 交回给守岸人重新起一圈
            return self.opener_toss()
        return self.main_axis()

    # ------------------------------------------------------------------ 启动轴的第 0 步

    def opener_toss(self):
        """开局: 只丢一个声骸吃一层增伤, 然后交给守岸人。

        视频 0.00 - 2.87 这一格。字幕「开局西格莉卡先丢个声骸技能」「获得一层增伤」。
        她的声骸冷却 70 秒, 这一下也顺便把冷却转起来 —— 等她第一次真正上场时
        (视频 25.7 秒) 还没转好, 所以启动轴那一轮开头只有 R 没有 Q。
        """
        self.logger.info('xigelika: opening toss (echo only), handing the field to shorekeeper')
        self.fire_echo()
        self.sleep(self.OPEN_ECHO_TO_SWITCH)

        # 【这里不走 direct_switch()】(2026-08-25 实机改)
        # 它第一件事是 wait_con_full() —— 轮询【0.8 秒】去读协奏, 好决定要不要把变奏
        # 交出去。但走到这条分支就意味着"空手入场"(开局第一帧, 或者轮换散了),
        # 协奏铁定是 0, 那 0.8 秒纯粹是白等。实机日志里
        #     09:13:02.615 opening toss
        #     09:13:03.771 con not full before switch (con=0.0)   <- 白等的 0.8 秒在这
        #     09:13:04.489 direct switched
        # Q 到守岸人接手花了 1.87 秒, 其中一半是这个。
        # 所以自己走 switch_to_index + handoff_to: 交接记账一样补, 只是不读协奏, 直接
        # 按 has_intro=False 交出去。
        target = self.char_at_slot(self.NEXT_SLOT)
        if target is not None and target is not self and self.switch_to_index(target.index):
            self.handoff_to(target, False)
            return
        self.logger.warning('xigelika: opening switch failed, falling back to framework')
        self.switch_next_char()

    # ------------------------------------------------------------------ 主轴

    def main_axis(self):
        anchor = self.switch_in_anchor()
        self.sleep(max(0.0, anchor + self.INTRO_ANIM - time.time()), check_combat=False)
        self.logger.info('xigelika main axis: (Q)R -> E -> [一直A, 黄一亮就长按重击, '
                         '循环到"重击和强化E都黄"] -> 回路E -> A -> 处决 -> 切人')

        # ---- Q + R ----
        # 启动轴那一轮 Q 还在 70 秒冷却里, 这一下是空操作, 不用分支
        self.fire_echo()
        self.sleep(self.ECHO_TO_LIB)
        # click_f=False: 大招演出里框架默认每 0.1 秒发一次 F, 会把留给收尾的处决吃掉
        cast = self.click_liberation(wait_if_cd_ready=0.4, click_f=False)
        if not cast:
            self.logger.warning('xigelika: liberation not ready, running the rest without it')

        # ---- E 打断大招后摇 ----
        self.sleep(self.LIB_TO_E)
        self.cast_resonance()

        # ---- 强化重击循环: 【持续检测, 打到"强化重击和强化E都变黄"为止】----
        # 用户 2026-08-25:
        #   「要持续检测啊, 不要过了个点就不重击了开始点按了」
        #   「有强化重击要马上长按, 直到强化重击和强化E都变成黄色, 才算结束的流程」
        # 为什么这么定: 我能读出"强化重击起手了", 读不出"它有没有被怪打断" ——
        # 资源一消耗指示器就灭, 招式后来被打断也看不见。所以整段不依赖那个判断,
        # 被打断就是多打一个重击, 反正退出条件是"两个都黄"而不是轮数/时间。
        self.sleep(self.E_TO_A)
        e_ready = self.heavy_loop(chain_e=self.CHAIN_E_INTO_HEAVY)


        # ---- 回路E: 【最后一个强化重击打完了】才长按 E ----
        # 中间必须留 HEAVY_TO_FORTE_E 的间隔 —— E 是瞬发的, 贴着松手按就会插进
        # 重击的动画里, 实机看到的"总是强化E放了才打强化重击"就是这么来的。
        # 视频里这个间隔是 0.8 秒 (第二个重击 86.60-87.40, 回路E 88.20 才开始)
        if not self.CHAIN_E_INTO_HEAVY:
            self.sleep(self.HEAVY_TO_FORTE_E)
            # confirmed: heavy_loop 是"确认强化E 就绪"才返回 True 的, 那就别再读一遍
            self.forte_resonance(confirmed=e_ready)

        # ---- 回路E 打完: 有处决就处决, 没有就立刻走 ----
        # 用户 2026-08-25: 「如果强化E完事, 有处决就处决, 没处决就切守岸人继续,
        #   让守岸人在A的时候处决就行」。
        # 所以这里【不再等满一个处决窗口】: FORTE_E_TO_BREAK 只留够回路E 的动画尾巴,
        # 然后 execute_break() 就看一眼(BREAK_WINDOW 0.5 秒), 没有马上切人。
        # 处决不会因此漏掉 —— 守岸人打普攻的时候会顺手接 (见她的 try_break)
        self.sleep(self.FORTE_E_TO_BREAK)
        self.execute_break()

        self.leave()

    def after_heavy_dodge(self, landed):
        """第一个强化重击之后的那一下闪避 —— 【现在没人调它了, 整个关掉】。

        2026-08-25 用户最终决定不闪了: 「没办法确认是不是真打出去了, 因为有可能在
        打的过程中就被打断, 这样我们也不闪避了」。闪避的价值完全取决于"重击到底
        打完没有", 而那恰好是我判不出来的东西 —— 判不出来就不该赌。
        方法留着不删, 是因为参数(DODGE_DELAY)和调用形态都已经调好了, 哪天想找回来
        直接把 DODGE_AFTER_HEAVY 打开、在 main_axis 的重击循环里调一下即可。

        下面是关掉之前的说明:
        【确认打出来了才闪, 而且立刻闪】。

        用户 2026-08-25 原话:
            「第一个强化重击能确认打出就马上闪避, 闪避了马上开始A, 这样衔接才平滑。」
        所以这里没有任何固定延时: 调用方是读到"强化重击起手了"才返回 True 的,
        返回那一刻重击就已经出去了, 直接闪; 调用方紧接着就是第二轮的普攻。

        landed=False 时【不能闪】—— 重击没出就没有后摇可断, 这一下闪避只会把人
        往后拉一段, 而她攻击范围本来就小, 拉远之后更打不到怪。
        """
        if not self.DODGE_AFTER_HEAVY:
            return
        if not landed:
            self.logger.info('xigelika: 第一个强化重击没确认打出, 不闪避')
            return
        # 【松手之后再隔 DODGE_DELAY 才闪】(用户指定 0.3 秒), 闪完立刻接普攻
        self.sleep(self.DODGE_DELAY)
        self.dodge()
        self.click()      # 闪避按下去的同一时刻就开始持续普攻
        self.logger.info(f'xigelika: dodge at +{getattr(self, "heavy_hold_after", -1):.2f}s '
                         f'after the heavy started, +{self.DODGE_DELAY:.2f}s after release')

    # ------------------------------------------------------------------ 动作

    def cast_resonance(self):
        """E。返回的是三元组 (clicked, duration, animated), 不是 bool。"""
        return self.click_resonance(send_click=False, time_out=1)[0]

    def fire_echo(self, click_between=False):
        """Q 声骸 —— 【连发, 不是只发一次】。

        (2026-08-25 实机: "西格莉卡循环里也不会放Q, 可以多点几次,
         反正 Q 也是脱手的不会打断角色"。)
        演出期间的按键是被游戏丢弃的、不排队, 只发一次很容易整段被吃掉 ——
        她这两下 Q 一次紧跟着变奏入场、一次夹在连段里, 都是容易被吞的位置。
        读到进冷却就提前收手; 读不出来就把 ECHO_TRIES 次发满 —— 按在冷却上是空操作。

        【不用 click_echo(time_out=0)】: 它第一件事是读屏 echo_available(),
        读到 False 就掉进一秒起步的慢路径, 而刚打完大招那几帧读数最不可信。
        """
        # 【无条件按满 ECHO_TRIES 次】—— 读屏只用来"提前收手", 绝不用来"提前放弃"。
        # 上一版一读到"在冷却"就只发一次走人, 读错一次这一轮就没 Q 了;
        # 而 Q 是脱手技能, 多按几下不会打断她当前的动作, 按在冷却上也只是空操作。
        was_available = self.echo_available()
        for i in range(self.ECHO_TRIES):
            self.send_echo_key()
            self.record_echo_use()
            if click_between:
                # 连发期间别停手 —— Q 是脱手的, 普攻照打
                self.click()
            self.sleep(self.ECHO_RETRY, check_combat=False)
            if was_available and not self.echo_available():
                # 进来是好的、现在读到冷却 = 确认放出去了, 可以收手
                self.logger.info(f'xigelika: echo landed on try {i + 1}')
                return True
        return False

    # ------------------------------------------------------------------ 回路指示器

    def forte_icon_box(self):
        """技能栏最左边那一格的框 —— 强化普攻(绿)/强化重击(黄) 的光环就画在这里。

        坐标见 FORTE_ICON 的注释。用 box_of_screen_scaled 按当前分辨率换算,
        不要去动 FeatureSet 里的共享 Box。
        """
        x0, y0, x1, y1 = self.FORTE_ICON
        return self.task.box_of_screen_scaled(3840, 2160, x0, y0, x1, y1,
                                              name='xigelika_forte_icon')

    def forte_color(self):
        """返回 (绿占比, 黄占比)。

        按【通道之间的差】算, 不用绝对色值区间 —— 理由见 YELLOW_RB 那一堆常量的注释:
        泛光会把光环的芯吹成白色, 绝对区间一旦被蓝通道顶出去就整片不算数,
        同一个状态在两场实机里能差一倍多。通道差对亮度不敏感: 金色再亮, 蓝也总是
        明显低于红绿; 纯白三通道齐平, 自然排除。

        自己算而不是走 task.calculate_color_percentage —— 那个只支持 r/g/b 区间。
        代价很小: 一个 140x120 的小框, 没有找图开销, 所以 FORTE_POLL 能压到 0.05 秒。
        """
        import numpy as np
        box = self.forte_icon_box()
        try:
            img = box.crop_frame(self.task.frame)
        except Exception:
            return 0.0, 0.0
        if img is None or img.size == 0:
            return 0.0, 0.0
        b = img[:, :, 0].astype(int)
        g = img[:, :, 1].astype(int)
        r = img[:, :, 2].astype(int)
        total = float(r.size)
        yellow = float((((r - b) >= self.YELLOW_RB) & ((g - b) >= self.YELLOW_GB)
                        & (r >= self.YELLOW_MIN_R)).sum()) / total
        green = float((((g - r) >= self.GREEN_GR) & ((g - b) >= self.GREEN_GB)
                       & (g >= self.GREEN_MIN_G)).sum()) / total
        return green, yellow

    def forte_e_ready(self):
        """强化E 亮没亮 —— 【只认"E 图标变黄"这一条】。

        【机制搞反过一次, 记在这里】(2026-08-25 用户澄清):
            强化重击【不消耗】回路, 反而是【增加】回路;
            只有黄色的强化E 消耗【全部】回路。
        所以整条轴是: 打重击攒回路 -> 回路攒满, E 图标变黄 -> 长按E 一次性倒出去。
        "强化E 变黄" ≈ "回路条满了", 它是这一段唯一真正的进度信号。

        【判据以 e_forte 模板为主】(2026-08-25 用户澄清了那一格是什么):
            「回路条右边的鼠标图标变亮 = 可以打强化重击;
              变成字母 E = 可以释放强化E」
        也就是说那一格就是框架里的 mouse_forte / e_forte 两个模板轮流显示 ——
        我之前把 e_forte 当成"不是 E 图标"删掉了, 是搞错了位置, 现在放回来当主判据。
        两个状态在同一格里互斥, 所以 e_forte 命中就是"现在能放强化E", 很干净。
        E 图标变黄当第二条(用户也提过), 两条取或。

        【`not has_cd('resonance')` 已经彻底删掉】—— 她一棒二十秒里普通E 只按一次,
        "E 不在冷却"几乎恒真。实机 18:51 那轮 heavy_loop 就是被它骗着提前退出,
        退出后长按 E 自然放不出来 (`强化E 没读到就绪, 照样长按`)。
        """
        # 【只算判断真正需要的两样】: 原来走 forte_e_signals(), 那里面顺带做了一次
        # has_cd() 的 OCR —— 那个值只用来打日志, 却在每一次轮询里都花掉几十毫秒。
        # 这个函数是"重击 -> 强化E"衔接路径上被轮询得最密的一个, 省下的就是衔接时间。
        if self.is_e_forte_full():
            return True
        try:
            box = self.task.get_box_by_name('box_resonance')
        except Exception:
            return False
        return box is not None and self.box_yellow(box) >= self.YELLOW_MIN

    def forte_e_signals(self):
        """三条判据分开返回 (E图标黄占比, e_forte模板命中, E在冷却)。

        只有第一个参与判断 (见 forte_e_ready), 另外两个纯粹是日志里的参考值 ——
        留着是因为出问题时能一眼看出是不是框选偏了。
        """
        y = 0.0
        try:
            box = self.task.get_box_by_name('box_resonance')
            if box is not None:
                y = self.box_yellow(box)
        except Exception:
            pass
        return y, bool(self.is_e_forte_full()), bool(self.has_cd('resonance'))

    def box_yellow(self, box):
        """某个框里"金黄"占多少 —— 跟 forte_color() 用同一套通道差判据。"""
        try:
            img = box.crop_frame(self.task.frame)
        except Exception:
            return 0.0
        if img is None or img.size == 0:
            return 0.0
        b = img[:, :, 0].astype(int)
        g = img[:, :, 1].astype(int)
        r = img[:, :, 2].astype(int)
        return float((((r - b) >= self.YELLOW_RB) & ((g - b) >= self.YELLOW_GB)
                      & (r >= self.YELLOW_MIN_R)).sum()) / float(r.size)

    def enhanced_ready(self):
        """绿 —— 强化普攻可用。

        【已经不参与任何判断了, 留着只为了日志/以后调试】。
        实机日志里绿的占比 0.15~0.65 —— 0.65 意味着这个框里 65% 的像素是绿的,
        一圈光环不可能占这么多, 那是她自己的青绿色特效把框刷满了。
        想重新启用之前, 先把框收窄到只剩光环那一圈, 再看日志里的 g= 分不分得开。
        """
        green, yellow = self.forte_color()
        return green >= self.GREEN_MIN and yellow < self.YELLOW_MIN

    def heavy_ready(self):
        """黄 —— 强化重击可用。这一格转黄, 就是「强化普攻已经打出去了」的证据。"""
        _, yellow = self.forte_color()
        return yellow >= self.YELLOW_MIN

    def forte_probe(self, tag):
        """把这一格里最亮那些像素的实测 RGB + 绿/黄占比打进日志, 用来调阈值。"""
        import numpy as np
        box = self.forte_icon_box()
        green, yellow = self.forte_color()
        rgb = 'dark'
        try:
            img = box.crop_frame(self.task.frame)
            if img is not None and img.size:
                b = img[:, :, 0].astype(int)
                g = img[:, :, 1].astype(int)
                r = img[:, :, 2].astype(int)
                lum = r + g + b
                mask = lum >= max(300, int(lum.max()) - 90)
                if int(mask.sum()) >= 4:
                    rgb = (f'{int(r[mask].mean())},{int(g[mask].mean())},'
                           f'{int(b[mask].mean())} n={int(mask.sum())}')
        except Exception:
            rgb = 'n/a'
        # 【E 图标的黄一起打出来】: 那是"强化E 好了没有"的唯一判据(见 forte_e_ready),
        # 而它的阈值还没实机标定过 —— 靠这行日志看它在整段里怎么涨的
        ey, tpl, cd = self.forte_e_signals()
        self.logger.info(f'xigelika forte [{tag}] 指示器 g={green:.2f} y={yellow:.2f} '
                         f'rgb={rgb} | E图标黄={ey:.2f} (模板={tpl} 冷却={cd})')

    def wait_forte(self, cond, name, timeout, click, click_after=0.0, confirm=None,
                   poll=None):
        """等某个回路状态成立 —— 【连读 confirm 帧一致才认】。

        去抖不能省: 上一版用单帧找图, 被特效闪光骗到 —— 点下 A 才 37 毫秒就判定
        "强化普攻已经打出去了"(11:16:46 的日志), 于是按住普攻的时机提前到了起手里,
        重击自然接不上。

        Args:
            cond: 判据。
            name: 打日志用的名字。
            timeout: 0 = 不设上限 (唯一的出口是 check_combat() 抛异常)。
            click: True 时按 A_INTERVAL 的节奏打普攻。False 时只轮询不动手 ——
                这时要自己 next_frame(), 否则读的一直是同一张缓存帧。
            click_after: click=True 时, 头这么多秒【先不点】。等"转黄"要用它:
                强化普攻刚放出去的那零点几秒不该再补普攻, 但一直干等更亏
                (这一下要是被躲了, 站着等只会更慢), 所以过了这个点就一边等一边继续 A。
            confirm: 连续命中多少次才认, 默认 FORTE_CONFIRM。
            poll: 轮询间隔, 默认 FORTE_POLL。【衔接路径上要给小值】——
                去抖要连读 confirm 帧, 每帧都要等一个 poll,
                所以"检测出来"的最小延迟就是 confirm * poll。
        """
        confirm = self.FORTE_CONFIRM if confirm is None else confirm
        poll = self.FORTE_POLL if poll is None else poll
        start = time.time()
        last_click = 0.0
        last_log = 0.0
        hits = 0
        while True:
            elapsed = self.time_elapsed_accounting_for_freeze(start)
            if not click or elapsed < click_after:
                # click() 内部会 reset_scene 刷新帧; 不点的时候得自己刷
                self.task.next_frame()
            if cond():
                hits += 1
                if hits >= confirm:
                    self.logger.info(f'xigelika: {name} after {elapsed:.2f}s')
                    return True
            else:
                hits = 0
            if timeout > 0 and elapsed >= timeout:
                return False
            self.check_combat()
            now = time.time()
            if click and elapsed >= click_after and now - last_click >= self.A_INTERVAL:
                self.click()
                last_click = now
            if elapsed - last_log >= self.FORTE_LOG_EVERY:
                last_log = elapsed
                g, y = self.forte_color()
                self.logger.warning(f'xigelika: still waiting for {name} ({elapsed:.1f}s) '
                                    f'g={g:.2f} y={y:.2f}')
            self.sleep(poll)
    def attack_until_heavy(self, timeout):
        """一直打普攻直到黄亮。返回 (等到没有, 手是不是已经按着)。

        【预输入】(用户 2026-08-25: "正常来说应该在强化普攻时就开始长按重击预输入,
        这样打的更快"): PREINPUT_HOLD 打开时, 普攻走"按住 0.15 秒再松"的节奏,
        按住期间照样轮询 —— 黄一亮【就不松手】, 直接返回 held=True 接进强化重击。
        等于强化普攻还在演的时候手已经按下去了, 省掉"检测到黄 -> 再按一次"那一下的延迟。

        黄的判据在这里【只看一帧】(不去抖): 它的不亮基线是硬 0.00, 单帧误判概率很低;
        就算误判, 代价也只是多打一发普通蓄力, 不像别的地方会整段错位。
        """
        start = time.time()
        last_log = 0.0
        while True:
            elapsed = self.time_elapsed_accounting_for_freeze(start)
            if timeout > 0 and elapsed >= timeout:
                return False, False
            self.check_combat()

            if self.PREINPUT_HOLD:
                self.task.mouse_down()
                held_at = time.time()
                while time.time() - held_at < self.PREINPUT_HOLD_TIME:
                    self.task.next_frame()
                    if self.heavy_ready():
                        self.logger.info(f'xigelika: 强化重击可用(黄) after {elapsed:.2f}s '
                                         f'(预输入: 手没松, 直接接重击)')
                        return True, True
                    self.sleep(self.FORTE_POLL, check_combat=False)
                self.task.mouse_up()
                self.sleep(self.PREINPUT_GAP, check_combat=False)
            else:
                self.click()
                self.sleep(self.A_INTERVAL)

            self.task.next_frame()
            if self.heavy_ready():
                self.logger.info(f'xigelika: 强化重击可用(黄) after {elapsed:.2f}s')
                return True, False

            if elapsed - last_log >= self.FORTE_LOG_EVERY:
                last_log = elapsed
                g, y = self.forte_color()
                self.logger.warning(f'xigelika: still waiting for 强化重击可用(黄) '
                                    f'({elapsed:.1f}s) g={g:.2f} y={y:.2f}')

    def heavy_loop(self, chain_e=False):
        """一直打, 直到【强化重击(黄) 和 强化E 同时是黄的】—— 那一下重击就是最后一个。

        用户 2026-08-25 原话:
          「你西格莉卡那里要持续检测啊, 不要过了个点就不重击了开始点按了」
          「有强化重击要马上长按, 直到强化重击和强化E都变成黄色, 才算结束的流程」

        所以这里【不分轮次、不设每轮超时】。上一版是"每轮等黄 6 秒 x 最多 5 轮",
        被怪打断几次就把轮次耗光, 剩下的时间纯点普攻、再也不重击了 ——
        实机"没跑完就切人"正是这么来的。
        现在是一个从头跑到尾的循环: 每一帧都在看黄, 亮了就立刻长按(不管这是第几个);
        只有一个总预算 HEAVY_LOOP_BUDGET 兜底, 防止判据失灵时永远出不来。

        按住没起手也不用特判 —— 循环回去黄还亮着, 下一圈立刻又按住, 天然就是重试。

        Returns:
            bool: 有没有走到"两个都黄"的收尾条件。
        """
        start = time.time()
        heavies = 0
        while True:
            left = self.HEAVY_LOOP_BUDGET - self.time_elapsed_accounting_for_freeze(start)
            if left <= 0:
                self.logger.warning(f'xigelika: 重击循环跑满 {self.HEAVY_LOOP_BUDGET}s '
                                    f'(打出 {heavies} 个重击), 收尾')
                return False
            # 进来就已经黄了(上一圈刚攒满) —— 不用再打重击了, 直接收尾
            if heavies >= self.MIN_HEAVY_ROUNDS and self.forte_e_ready():
                self.logger.info(f'xigelika: 强化E 已经黄了 (已打 {heavies} 个重击), 接回路E')
                return True

            found, held = self.attack_until_heavy(left)
            if not found:
                continue
            # 【黄一亮就长按, 不管这是第几个】
            self.forte_probe('黄')
            started = self.hold_heavy(chain_e=chain_e, already_down=held)
            if started:
                heavies += 1

            # 【收尾条件必须在打完之后判】(2026-08-25 实机: "多放了一个强化重击才打出E"):
            # 强化重击是【攒】回路的, 回路攒满 E 才变黄 —— 所以 E 只可能在一个重击
            # 打完之后才变黄。原来是在按之前判, 那一下的功劳要等到下一圈才看得见,
            # 于是白白多打一整轮(等黄 + 长按)才收尾。
            if heavies >= self.MIN_HEAVY_ROUNDS and                     self.wait_forte(self.forte_e_ready, '强化E 变黄',
                                    timeout=self.FORTE_E_CHECK, click=False,
                                    poll=self.FORTE_E_POLL):
                self.logger.info(f'xigelika: 第 {heavies} 个重击把回路攒满了, 接回路E')
                self.forte_probe('强化E 变黄')
                return True
            # 攻略图上这一格写的是「回路重击-(Q)」: 好了就补, 没好就算。
            # 【补 Q 的时候不要停手】—— fire_echo 连发要花 0.6 秒, 干等会把连段断掉
            self.fire_echo(click_between=True)

    def hold_heavy(self, chain_e=False, already_down=False):
        """按住普攻放强化重击 —— 分两段, 【锚点是"黄灭了"那一刻】。

            按下  ->  [黄灭 = 回路被吃掉 = 重击起手]  ->  再按住 HEAVY_AFTER  ->  松手

        为什么不从"按下"起算固定时长: 按下到起手中间有一段不确定的延迟, 全算进去的话
        松手、闪避、接回路E 的时刻会整体飘 —— 实机"闪避接太晚"和"E 插到重击里"
        都是这么来的。视频实测黄 81.1 出现 / 81.3 消失, 说明按下去回路几乎立刻被吃掉,
        所以这个锚点又准又快。

        【中途松手会把重击截断】, 所以第二段宁可多按 0.1 秒也别提前松;
        但也别太长 —— 松手那一刻就是闪避该接上的时刻。

        Returns:
            bool: 重击到底起手了没有 (黄灭了没有)。没起手就该原地再按一次。
        """
        started = False
        start = time.time()
        if not already_down:
            # already_down: 预输入那一段手还按着, 【绝对不要再 mouse_down 补按】——
            # PostMessage 后端每次 mouse_down 都会投一条 WM_ACTIVATE, 窗口收到就松手
            self.task.mouse_down()
        try:
            started = self.wait_forte(lambda: not self.heavy_ready(), '强化重击起手(黄灭)',
                                      timeout=self.HEAVY_START_WAIT, click=False)
            start = time.time()   # 【重新锚在"起手"这一刻】, 按下到起手的延迟不算进来
            if chain_e:
                # 【按住期间只发键, 绝对不要再 mouse_down 补按】
                self.task.send_key_down(self.get_resonance_key())
                self.sleep(self.FORTE_E_HOLD, check_combat=False)
                self.task.send_key_up(self.get_resonance_key())
                self.record_resonance_use()
                self.sleep(max(0.0, self.HEAVY_AFTER - self.FORTE_E_HOLD), check_combat=False)
            else:
                self.sleep(self.HEAVY_AFTER, check_combat=False)
        finally:
            self.task.mouse_up()
            self.heavy_hold_after = time.time() - start
        return started

    def forte_resonance(self, confirmed=False):
        """回路E: 长按 E。视频 88.2 - 90.0 那一格。

        跟普通 E 走的是同一个键, 但吃的是回路而不是冷却 —— 所以不能用 has_cd 去判,
        也不用 click_resonance (它会因为"图标不亮"直接不发)。

        【判据换成"强化E 变黄"】(2026-08-25 实机: "第二段强化重击打出去, 没有马上接
        黄色的强化E"): 原来等的是 `is_e_forte_full()` 那个 e_forte 模板, 它时灵时不灵
        (日志里既有 `after 0.07s` 也有 `prompt not seen`), 不灵的时候要白等
        FORTE_E_WAIT 秒 —— 叠上前面的 HEAVY_TO_FORTE_E, 就成了"接不上"。

        而走到这一行的时候, heavy_loop() 的退出条件本来就是"重击和强化E 同时是黄的",
        所以【绝大多数情况进来就已经是好的, 一秒都不用等】。
        forte_e_ready() 是三条判据取或(E图标变黄 / e_forte 模板 / E 不在冷却),
        比单看模板稳得多。读不到也照按 —— 这一步之后只剩处决和切人, 赖在这里更亏。
        """
        # confirmed: heavy_loop 退出时刚确认过 E 就绪, 这里【一帧都不要再读】——
        # 每多读一次就多几十毫秒, 实机反馈"第二个强化重击和强化E衔接等的太久了"
        # 就是这些零碎叠出来的
        if confirmed:
            self.logger.info('xigelika: 强化E 刚确认过, 直接长按')
        elif self.forte_e_ready():
            self.logger.info('xigelika: 强化E 已经就绪, 立刻长按')
        elif not self.wait_forte(self.forte_e_ready, '强化E 就绪',
                                 timeout=self.FORTE_E_WAIT, click=False):
            self.logger.warning('xigelika: 强化E 没读到就绪, 照样长按')

        key = self.get_resonance_key()
        for attempt in range(1, self.FORTE_E_TRIES + 1):
            self.task.send_key_down(key)
            self.sleep(self.FORTE_E_HOLD, check_combat=False)
            self.task.send_key_up(key)
            self.record_resonance_use()
            self.sleep(self.FORTE_E_SETTLE)
            # 【长按之后确认它真的放出去了】: E 进了冷却 = 有东西被放出来了。
            # 实机出现过"照样长按"之后 E 根本没出来就切人了, 光发键不确认查不出来
            if self.has_cd('resonance'):
                self.logger.info(f'xigelika: 强化E 放出去了 (第 {attempt} 次长按)')
                return True
            y, tpl, cd = self.forte_e_signals()
            self.logger.info(f'xigelika 强化E 判据: e_forte模板={tpl} '
                             f'E图标黄={y:.2f} E在冷却={cd}')
            self.logger.warning(f'xigelika: 长按 {self.FORTE_E_HOLD}s 之后 E 还没进冷却, '
                                f'没放出去 (第 {attempt}/{self.FORTE_E_TRIES} 次)')
        return False

    def dodge(self):
        """闪避 = 右键。

        【这条轴里已经不用了】(用户实机要求拿掉): 它原来只有一个用途 —— 断强化重击的
        后摇。但时机不对就会把人往后拉一段, 而西格莉卡攻击范围本来就小,
        拉远之后更打不到怪。留着方法和 DODGE_AFTER_HEAVY 开关只是为了以后好找回来。
        """
        self.task.click(key='right')

    # ------------------------------------------------------------------ 处决

    def execute_break(self):
        """A 之后接 F 处决 —— 全队唯一一处主动处决。

        【为什么不能只调一次 task.f_break()】: 它的第一行是
        `if self.can_break or self.check_f_break():`, 提示晚出来哪怕 0.1 秒这次调用
        就整个跳过。而且宏跑起来之后 skip_combat_check=True, 战斗判定线程不再刷新
        can_break; check_f_break() 里屏幕中央那一路找图外面还裹着 1 秒频率限制,
        高频重试等于只查了顶部那一路。所以自己把中央那一路补上, 命中就置 can_break
        再进 f_break() 的短路分支。

        【f_break() 本身很贵】: 阻塞 0.5 ~ 5 秒, 期间还一直连打左键。放在这里是安全的
        —— 这一步之后就直接切人了, 手上没有任何长按, 也没有靠墙钟计时的窗口。
        """
        end = time.time() + self.BREAK_WINDOW
        while True:
            if self.task.can_break or self.break_prompt():
                self.task.can_break = True
                fired = self.f_break()
                # 按完记得清掉, 否则框架切人时会再按一次
                self.task.can_break = False
                self.logger.info(f'xigelika: break executed ({fired})')
                return True
            if time.time() >= end:
                break
            # 开了窗口才有这一段: 顺便盯黄, 亮了就补一个强化重击
            if self.heavy_ready():
                self.logger.info('xigelika: 找处决的时候黄亮了, 补一个强化重击')
                self.hold_heavy()
                continue
            self.click()
            self.sleep(0.1)
        self.logger.info('xigelika: 没有处决提示, 直接切人 (漏的交给守岸人)')
        return False

    def break_prompt(self):
        """屏幕中央那一路处决提示。check_f_break() 里的同一段判据, 但不吃频率限制。"""
        box = self.task.box_of_screen(0.2, 0.2, 0.75, 0.8, hcenter=True, vcenter=True)
        if self.task.find_one('f_break', box=box, target_height=720):
            return not self.task.is_pick_f()
        return False

    # ------------------------------------------------------------------ 离场

    def leave(self):
        """【硬 gate】协奏没满不许走, 然后按数字键直接切守岸人。

        她带不带变奏走人, 决定的是守岸人打两组还是三组 —— 守岸人那边是靠
        take_intro() 分流的, 判错了不是白打就是多打一组。

        【切人前必须先等队伍 HUD 回来】(2026-08-25 实机定位, 这是"守岸人刚变奏入场
        就被切走"的真凶):
        统计整份日志, 西格莉卡切守岸人 4 成功 / 7 失败, 而且分得干干净净 ——
        4 次成功【全部】来自开场丢 Q 那条分支(opener_toss, 前面没有任何演出),
        7 次失败【全部】来自主轴结尾的 leave(), 也就是紧跟在 F 处决 / 回路E 后面。
        失败的耗时又都正好是 SWITCH_TIMEOUT(2.0 秒), 说明那 2 秒整个泡在演出里:
        处决动画带全局时停、队伍 HUD 不渲染, switch_to_index 的 in_team() 一路读不到人,
        于是判失败 -> 掉进框架的 switch_next_char()。而那玩意是按优先级现场挑人的,
        挑到仇远的时候(12:10:43 / 12:33:43)轮换顺序就漂了 ——
        实际画面就是: 数字键其实已经把守岸人换上来了(带着变奏), 紧接着框架又切了一次。
        """
        con_ok = self.fill_con()
        for attempt in range(1, self.LEAVE_TRIES + 1):
            self.wait_team_hud()
            if self.direct_switch(assume_intro=con_ok):
                return
            self.logger.warning(f'xigelika: direct switch failed '
                                f'(第 {attempt}/{self.LEAVE_TRIES} 次), retrying')
        # 【掉回框架是最后手段】: 它会按优先级重挑人, 轮换顺序可能整个错位
        self.logger.warning('xigelika: falling back to framework switch, rotation may drift')
        self.switch_next_char()

    def fill_con(self):
        """等协奏满 —— 期间【照样盯着黄, 亮了就长按重击】, 不是干点普攻。

        用户 2026-08-25: 「不要过了个点就不重击了开始点按了」。
        原来这里是 require(is_con_full, action=self.click): 最多点 8 秒普攻, 全程
        不看黄 —— 强化重击好了也白瞎。现在拆成一秒一段, 每段都是"打普攻+盯黄",
        黄亮就按住, 打完回头看一眼协奏。
        """
        start = time.time()
        while True:
            if self.is_con_full():
                waited = self.time_elapsed_accounting_for_freeze(start)
                if waited > 0.3:
                    self.logger.info(f'xigelika: 协奏满 after {waited:.1f}s')
                return True
            left = self.CON_GATE_TIMEOUT - self.time_elapsed_accounting_for_freeze(start)
            if left <= 0:
                self.logger.warning(f'xigelika: 协奏没满就到点了 '
                                    f'(con={self.get_current_con():.2f}), 走人')
                return False
            found, held = self.attack_until_heavy(min(self.CON_FILL_SLICE, left))
            if found:
                self.logger.info('xigelika: 等协奏的时候黄又亮了, 补一个强化重击')
                self.hold_heavy(already_down=held)

    def wait_team_hud(self, timeout=None):
        """等右侧队伍头像的编号渲染回来 —— 演出期间它整块是不画的。

        不等就按数字键的话, switch_to_index 的 in_team() 全程读不到人, 白按满
        SWITCH_TIMEOUT 秒然后判失败(实机 7/7 就是这么失败的)。
        """
        timeout = self.TEAM_HUD_WAIT if timeout is None else timeout
        start = time.time()
        while time.time() - start < timeout:
            if self.task.in_team()[0]:
                waited = time.time() - start
                if waited > 0.2:
                    self.logger.info(f'xigelika: team hud back after {waited:.2f}s')
                return True
            self.task.next_frame()
            self.sleep(0.08, check_combat=False)
        self.logger.warning(f'xigelika: team hud still unreadable after {timeout:.1f}s')
        return False

    def switched_away(self):
        """我自己那个队伍编号又出现了 = 我已经不在场上了。

        这是给 switch_to_index 补的第二条确认路。框架的 in_team() 是靠
        "三个编号里【第一个】读不到的就是当前角色"反推的, 所以想认出"当前是3号",
        1号和2号两个模板都得命中; 认"当前是1号"只要1号读不到就行 ——
        判"切到3号"天生比判"切到1号"难。而这里只看我自己那一个模板。
        """
        return self.task.find_one(f'char_{self.index + 1}_text', threshold=0.8) is not None

    def switch_to_index(self, index):
        """覆盖公共段的版本 —— 多一条确认路(switched_away), 其余逐字一样。

        公共段那份留着不动, 因为别的角色切 1号/2号 从来没失败过;
        只有西格莉卡要切的 3号 判起来最难, 而且她还是唯一一个紧跟演出切人的。
        """
        start = time.time()
        while time.time() - start < self.SWITCH_TIMEOUT:
            in_team, current_index, _ = self.task.in_team()
            if (in_team and current_index == index) or self.switched_away():
                self.switch_confirmed_at = time.time()
                self.settle_with_attack(self.SWITCH_SETTLE)
                return True
            self.task.send_key(index + 1)
            self.click()
            self.sleep(self.SWITCH_KEY_INTERVAL, check_combat=False)
        return False

    # ------------------------------------------------------------------ 小工具

    def switch_in_anchor(self):
        """本轮的计时基准: 头像认出「切人完成」的那一刻, 不是 do_perform 被调那一刻。"""
        now = time.time()
        anchored = self.last_switch_in_time
        gap = now - anchored if anchored > 0 else -1
        if 0 <= gap <= self.SWITCH_ANCHOR_MAX:
            return anchored
        return now
