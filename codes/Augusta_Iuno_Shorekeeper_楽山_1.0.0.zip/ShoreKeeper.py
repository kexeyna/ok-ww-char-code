import time

from src.char.BaseChar import SwitchPriority
from src.char.ShoreKeeper import ShoreKeeper as NativeShoreKeeper


class ShoreKeeper(NativeShoreKeeper):
    """日月守队(奥古斯塔/尤诺/守岸人)里的守岸人。非本队时整套走原版。

    【她是两条轴的入口】: 一圈是 守 -> 月 -> 日 -> 守, 起点和终点都是她, 所以
    框架每次调到她的 do_perform 就是"新的一圈开始了"。宏体在同目录的 Augusta.py 里:
    自定义角色文件由 CustomCharLoader 按路径单独加载, 互相 import 不到, 但同一个
    task 下用 task.chars 拿得到彼此的实例, 这是跨文件复用宏原语的唯一路子。

    启动段和循环段的区别只在她身上:
      启动段 —— 战斗第一次上场, 协奏是空的, 要打满一整套才凑得出变奏;
      循环段 —— 带变奏入场进来, 身上已经有一截协奏, 只要 3A -> E -> 重击 -> Q -> R。
    这个分岔由 Augusta.opener_pending() 说了算, 不由这边猜。

    【原版那两处特殊逻辑一行没动】:
      - skip_combat_check(): 变奏入场/悬空时不跑战斗判定, 免得把入场动画判成脱战;
      - decide_teammate() / auto_dodge(): 队里有奥古斯塔时的自动闪避。
    上游改了它们, 这条轴自动跟着走。
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # 【新加的字段内置版没有, 不受 apply_team_char_classes 的 __dict__.update 影响】
        self.macro_yield_logged = 0.0

    @property
    def is_in_aug_cycle(self) -> bool:
        members = 0
        for char in self.task.chars:
            if char is not None and char.name in {'Augusta', 'Iuno'}:
                members += 1
        return members == 2

    def macro(self):
        """拿到持宏的奥古斯塔实例。

        【按能力找, 不按名字找】: 奥古斯塔那份自定义没启用的话这里就该返回 None,
        然后老老实实走原版轮换 —— 而不是拿着一个没有 perform_loop 的实例崩掉。
        """
        for char in self.task.chars:
            if char is None or char is self:
                continue
            if hasattr(char, 'perform_loop') and hasattr(char, 'quick_switch'):
                return char
        return None

    def do_perform(self):
        if not self.is_in_aug_cycle:
            return super().do_perform()
        # 处决全程由宏自己按 —— 留着框架的自动 F 会在切人时插一发, 而击破动画带
        # 全局时停 + 队伍 HUD 消失, 正好把切人循环判成脱战
        self.check_f_on_switch = False
        macro = self.macro()
        if macro is None:
            now = time.time()
            if now - self.macro_yield_logged > 5:
                self.macro_yield_logged = now
                self.logger.warning('日月守: Augusta 自定义代码没生效, 退回原版轮换')
            return super().do_perform()

        opener = macro.opener_pending()
        if opener:
            # 【标记要在跑之前落】: 中途抛异常(脱战/任务被停)也不能让启动轴重跑,
            # reset_state 会把 armed 重新置回来
            macro.opener_armed = False
            macro.last_opener = time.time()

        # 【把自己传进去】: 框架是因为守岸人在场才调的这个 do_perform, 所以这就是
        # "现在场上是谁"最可靠的答案, 宏据此跳过开场那次切人。
        # 【不能让它去读屏判断】: in_team() 在战斗开局的头 0.8 秒会说谎
        if opener:
            if macro.perform_opener(self):
                return
        elif macro.perform_loop(self):
            return
        self.logger.warning('日月守: 轴中断, 退回原版轮换')
        return super().do_perform()

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        """启动轴待跑时守岸人【必须】先上场 —— 轴的第一个动作是她的普攻。

        【这里别打日志】: 框架会对每个候选反复调用, 会刷屏。
        """
        if self.is_in_aug_cycle:
            macro = self.macro()
            if macro is not None and macro.opener_pending():
                return SwitchPriority.MUST
        return super().get_switch_priority(current_char, has_intro, target_low_con)
