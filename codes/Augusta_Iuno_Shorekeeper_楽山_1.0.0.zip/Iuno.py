import time

from src.char.BaseChar import SwitchPriority
from src.char.Iuno import Iuno as NativeIuno


class Iuno(NativeIuno):
    """日月守队(奥古斯塔/尤诺/守岸人)里的尤诺。非本队时整套走原版。

    【她不驱动任何一段轴】: 一圈是 守 -> 月 -> 日 -> 守, 起点是守岸人, 她这一段
    是宏按数字键直切进来的。所以框架调到她的 do_perform 就说明宏散了
    (切人失败 / 脱战重进) —— 打一小段普攻把场子交出去, 让守岸人重新拿到入口。

    【为什么不在这里跑轴】: 轴的第一步假设守岸人刚上场, 从尤诺这里起跑一定错位 ——
    她这一段开头的那发 E 是"变奏入场解锁的强化技能"(帧表 QTE-吸附: 不处于月相状态时
    第1F解锁, 持续5秒), 没有那次变奏入场, 按下去的就是另一个技能。
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # 【新加的字段内置版没有, 不受 apply_team_char_classes 的 __dict__.update 影响】
        self.macro_yield_logged = 0.0

    @property
    def is_in_aug_cycle(self) -> bool:
        members = 0
        for char in self.task.chars:
            if char is not None and char.name in {'Augusta', 'ShoreKeeper'}:
                members += 1
        return members == 2

    def macro(self):
        """拿到持宏的奥古斯塔实例。【按能力找, 不按名字找】。"""
        for char in self.task.chars:
            if char is None or char is self:
                continue
            if hasattr(char, 'perform_loop') and hasattr(char, 'quick_switch'):
                return char
        return None

    def do_perform(self):
        if not self.is_in_aug_cycle:
            return super().do_perform()
        self.check_f_on_switch = False
        macro = self.macro()
        if macro is None:
            return super().do_perform()
        now = time.time()
        if now - self.macro_yield_logged > 5:
            self.macro_yield_logged = now
            self.logger.info('iuno: 这条队由宏驱动, 把场子交回去')
        self.continues_normal_attack(0.6)
        # 【直切回守岸人, 不交给框架选人】: 这条轴的入口必须是守岸人, 而她是治疗,
        # 带满协奏离场之后会被 healer_full_con_switch_locked() 锁一段时间 ——
        # 框架选人时会把她判成 SwitchPriority.NO, 于是又挑回尤诺, 来回打转。
        # 实机出现过的"怎么不是守岸人"就是这条路径。
        if hasattr(macro, 'back_to_entry') and macro.back_to_entry(tag='月交回场子'):
            return
        return self.switch_next_char()

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        """启动轴待跑时让位给守岸人。【这里别打日志】, 框架会对每个候选反复调用。"""
        if self.is_in_aug_cycle:
            macro = self.macro()
            if macro is not None and macro.opener_pending():
                return SwitchPriority.NO
        return super().get_switch_priority(current_char, has_intro, target_low_con)
