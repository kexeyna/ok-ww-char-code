import time

from src.Labels import Labels
from src.char.BaseChar import BaseChar, SwitchPriority


class Suisui(BaseChar):
    # 轴参数
    FILL_ROUTE_TIME = 10.0     # 普攻打满回路的总兜底时长
    CONCERTO_WAIT = 4.0        # 协奏满的兜底时长

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.last_forte3_switch = -1

    @staticmethod
    def _axis_first(task):
        # 首轮标记:本场战斗(combat_start)第一次为 True,穗穗打完置 False
        combat = getattr(task, 'combat_start', None)
        if getattr(task, '_wsv_combat', None) != combat:
            task._wsv_combat = combat
            task._wsv_first = True
        return bool(getattr(task, '_wsv_first', True))

    def do_perform(self):
        first = self._axis_first(self.task)
        if self.has_intro:
            self.wait_down()              # 变奏进场落地

        if first:
            # 前半段(仅首轮):普攻充能,等强化技能图标(suisui_e1)亮(第1条回路满)→放强化技能进入强化形态
            self.task.wait_until(lambda: bool(self.task.find_one(Labels.suisui_e1)),
                                 post_action=self.click, time_out=self.FILL_ROUTE_TIME)
            self.try_e()                  # 官方强化E(图标亮→发键循环)
            self.task._wsv_first = False

        # 后半段(首轮/循环都打):一般技能(落地) → 普攻打满第2条回路 → Q(建议大招前放) → R(开大) → 协奏满才切
        self.click_resonance(send_click=False, time_out=0)   # 一般技能(落地)
        self._fill_to_forte3()            # 普攻打满回路(最后一下打满才许开大)
        self.click_echo(time_out=0)       # Q 声骸(攻略:建议大招前放)
        if self.forte3_available():       # 回路满才开大,避免"早开少半格回路"
            self.click_liberation(wait_if_cd_ready=0)   # R 延奏
        # 协奏满才切(保证延奏buff)
        self.task.wait_until(self.is_con_full, post_action=self.click_with_interval, time_out=self.CONCERTO_WAIT)
        self.switch_next_char()

    def _fill_to_forte3(self):
        # 把回路普攻充到满(forte3图标);没满绝不提前放/切
        self.task.wait_until(self.forte3_available, post_action=self.click, time_out=self.FILL_ROUTE_TIME)

    def forte3_available(self):
        return bool(self.task.find_one(Labels.suisui_forte3, threshold=0.75))

    def forte2_available(self):
        return bool(self.task.find_one(Labels.suisui_forte2, threshold=0.75))

    def try_e(self):
        # 强化技能(图标检测,官方积木)
        if self.task.find_one(Labels.suisui_e1):
            start = time.time()
            while self.task.find_one(Labels.suisui_e1) and self.time_elapsed_accounting_for_freeze(start) < 2:
                self.send_resonance_key()
                self.sleep(0.05)
            return True
        return False

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        # 强制按轴轮切:只有"下一手该上"的角色MUST,其余NO
        if current_char is None or self is current_char:
            return super().get_switch_priority(current_char, has_intro, target_low_con)
        nxt = {'Suisui': 'Linnai', 'Linnai': 'Hiyuki', 'Hiyuki': 'Suisui'}.get(current_char.__class__.__name__)
        if nxt:
            return SwitchPriority.MUST if self.__class__.__name__ == nxt else SwitchPriority.NO
        return super().get_switch_priority(current_char, has_intro, target_low_con)
