import time

from src.Labels import Labels
from src.char.BaseChar import BaseChar, Elements


class Suisui(BaseChar):
    """穗穗 —— 队伍位置 1, 秧千穗轮换的起手与闭环点。

    【轴换成绯洛穗那条】(2026-08-25): 站场逻辑整体搬自
    configs/custom_teams/Hiyuki__Lucilla__Suisui/Suisui.py, 启动更快。
    搬过来时改了两处:
      1. 原轴在按E落地之后会"切主C(绯雪)入场打一下再切回来"(dps_touch), 按要求整个拿掉。
         于是 E_LAND_TO_SWITCH 那段变成纯粹的"落地后按住攻击键打一段地面连段"。
      2. 切人目标从绯洛穗的主C 改成本队的千咲 (NEXT_SLOT = 2), 走公共段的 direct_switch。

    两条轴只有开头不同, 从"等第一格回路能量满"起完全一样:
      启动轴  按住攻击键 -> 等E亮 -> 按E「醒春潮」进濯雨时 -> v
      循环轴  (变奏入场, 变奏技能本身已把她推进濯雨时) 按住攻击键 -> v
      启动轴等E的过程中还盯着芳菲信: 它涨了就说明这次其实是带变奏进来的(记账丢了),
      当场认领那段濯雨时并跳过醒春潮 —— 否则会白攒 6 秒水云息, 濯雨时的计时基准
      也跟着晚记那么多, 保底闸会一路等到芳菲信被清零
      v  等第一格满 -> 按E落地 -> 打一段地面连段 -> Q -> [保底: 三格回路满才准放R]
         -> R -> 切千咲

    攻击键是鼠标、E/Q/数字键是键盘, 互不冲突, 所以整条轴中途一次都不松手, 只在放R前松开。
    【按住期间绝对不要再调 mouse_down()】—— PostMessage 后端的 mouse_down() 内部会走
    try_activate() 投一条 WM_ACTIVATE, 窗口收到就会把已经按住的左键松开。

    大招压到最后放: 30 秒领域几乎全部覆盖后面两个角色的输出窗口。
    R 必须传 click_f=False —— 她的R动画 4.3 秒, 框架默认每 0.1 秒发一次F, 等于替全队
    按掉四十来次处决。

    【这条轴里"回路满"不能设成无上限的 gate】: 芳菲信只在濯雨时(15秒)里存在, 窗口一关
    直接清零 —— 等下去永远等不到。所以 wait_forte3() 保留原来那两道逃生闸: 芳菲信
    "见过又不见了", 或者窗口只剩 LIB_CAST_RESERVE 秒, 都立刻停手去放R。
    """

    # ================================================================ 固定顺序切人 (公共段)
    # 这一段在 Suisui.py / Chisa.py / YangYangSp.py 三个文件里逐字一样, 改一处记得同步改三处。
    # 下面各自的常量写在这一段【之后】, 所以子类想覆盖哪个直接在下面重写就行。
    #
    # 为什么不用框架的 switch_next_char():
    #   1. 它按 get_switch_priority() 现场挑人, 顺序会漂 —— 这套轴要求死顺序;
    #   2. 它内部有三处补普攻 ("performing too fast add a normal attack"、维持锁定、
    #      切换未检测到时补点击), 打完最后一下想立刻走人时那几下 A 会把节奏拖乱。
    # 代价是框架的交接记账要自己补, 全在 handoff_to() 里。

    SWITCH_TIMEOUT: float = 2.0        # 单程切人的最长尝试时间 (秒)
    SWITCH_KEY_INTERVAL: float = 0.12  # 连按数字键的间隔 (秒)
    # 切到之后等角色站稳的时间 (秒)。很敏感 —— 实测 0.50 / 0.52 会让下一个角色的起手被吞,
    # 0.55 才稳, 别再往下压
    SWITCH_SETTLE: float = 0.55
    SETTLE_ATTACK_INTERVAL: float = 0.42
    HANDOFF_CON_WAIT: float = 0.8      # 交接时等协奏读数稳定的上限 (秒)
    HANDOFF_CON_POLL: float = 0.1
    HOLD_POLL: float = 0.1             # 长按期间轮询条件的间隔 (秒)
    # 切走前按 F 处决 —— 框架 switch_next_char() 里有 current_char.f_break(True), 直接
    # 按数字键切人会绕开它。这套轴里默认【关掉】: handoff_to() 是在 switch_to_index()
    # 之后调的, 那时候下一个角色已经站上场了, 这一下 F 会被他吃掉, 而且发生在他的 R
    # 之前 (千咲"还没按 R 就开处决"就是这么来的)。处决统一由千咲在 R 之后接
    F_BREAK_ON_HANDOFF: bool = False

    # 别人用 handoff_to() 直接切给我时打的标记, 写成类属性省掉 __init__。
    # 不能只靠 has_intro —— reset_state() 每次重读队伍都会把它清成 False, 而战斗判定
    # 一抖动就会重进战斗、重读队伍, 于是角色以为自己空手入场, 跑去走开场那套流程
    intro_pending = False
    # 切人【真正完成】那一刻的时间戳 —— in_team 认出换人成功的那一帧, 不是
    # settle_with_attack 站稳之后。循环轴的落地E 就按这个锚点计时, 差 0.55 秒
    # 就会掉进"E 按在下落段完全没反应"的失败区
    switch_confirmed_at = 0.0

    def note_intro_handoff(self):
        """被别人用直接切人的方式交接进场时调用 —— 记下"我是带着变奏上来的"。"""
        self.intro_pending = True

    def take_intro(self):
        """本次入场是否带着变奏。读完就清, 避免下一轮误判。"""
        intro = self.has_intro or self.intro_pending
        self.intro_pending = False
        return intro

    def reset_fixed_rotation(self):
        """战斗结束时调 —— 在各自的 on_combat_end() 里。"""
        self.intro_pending = False

    def direct_switch(self, slot=None, assume_intro=False):
        """按数字键直接切到指定队伍位置 (1-based), 并自己补上框架的交接记账。

        Args:
            slot: 不传就用 NEXT_SLOT。
            assume_intro: True 时不读协奏, 直接认定是满的。刚放完大招要用这个 ——
                能量环读数滞后会把 has_intro 误判成 False, 下一个角色就拿不到变奏增益。
        """
        slot = self.NEXT_SLOT if slot is None else slot
        if slot is None:
            return False
        target = self.char_at_slot(slot)
        if target is None or target is self:
            return False

        has_intro = True if assume_intro else self.wait_con_full()
        if not self.switch_to_index(target.index):
            self.logger.warning(f'direct switch to slot {slot} failed')
            return False
        self.logger.info(f'direct switched to slot {slot} ({target.char_name}, intro={has_intro})')
        self.handoff_to(target, has_intro)
        return True

    def switch_to_index(self, index):
        """按数字键切到指定队伍位置, 直到 in_team 确认切过去了。

        点击落在谁身上就由谁打出来, 所以等待期间也保持点普攻, 两边连段都不断档。
        """
        start = time.time()
        while time.time() - start < self.SWITCH_TIMEOUT:
            in_team, current_index, _ = self.task.in_team()
            if in_team and current_index == index:
                # 【先记时间戳再站稳】: settle_with_attack 要花 SWITCH_SETTLE 秒,
                # 记在它后面的话锚点整体晚 0.55 秒, 靠锚点计时的动作全跟着晚
                self.switch_confirmed_at = time.time()
                self.settle_with_attack(self.SWITCH_SETTLE)
                return True
            self.task.send_key(index + 1)
            self.click()
            self.sleep(self.SWITCH_KEY_INTERVAL, check_combat=False)
        return False

    def settle_with_attack(self, duration):
        """等 duration 秒, 期间保持点普攻, 不干等。"""
        end = time.time() + duration
        while time.time() < end:
            self.click()
            self.sleep(min(self.SETTLE_ATTACK_INTERVAL, max(0.0, end - time.time())),
                       check_combat=False)

    def handoff_to(self, target, has_intro):
        """把场上角色交接给 target —— 复刻 switch_next_char() 内部那套记账。

        直接按数字键切人绕开了框架的交接逻辑, 必须自己补上, 否则:
          - 没人的 is_current_char 是 True → get_current_char() 返回 None → 下一帧崩溃;
          - has_intro / last_outro_time 不更新, 下一个角色拿不到变奏。
        """
        if self.F_BREAK_ON_HANDOFF:
            self.f_break(check_f_on_switch=True)
        self.task.in_liberation = False
        self.switch_out(con_full=has_intro)
        target.is_current_char = True
        target.has_intro = has_intro
        if has_intro and hasattr(target, 'note_intro_handoff'):
            # has_intro 是易失的, 再给对方补一个它自己保管的持久标记
            target.note_intro_handoff()
        # 用 in_team 确认那一刻, 不是现在 —— 中间隔着 settle_with_attack 那 0.55 秒
        target.last_switch_in_time = self.switch_confirmed_at or time.time()
        self.switch_confirmed_at = 0.0
        if has_intro:
            now = time.time()
            self.task.add_freeze_duration(now, target.intro_motion_freeze_duration, -100)
            self.last_outro_time = now

    def wait_con_full(self):
        """短暂轮询协奏是否满 —— 用来决定交接时给不给对方变奏。

        不能只读一次: 打完最后一下那一刻协奏其实已经满了, 但能量环读数滞后。
        必须在【按切人键之前】读: 切走之后能量环显示的已经是新角色的了。
        """
        start = time.time()
        while time.time() - start < self.HANDOFF_CON_WAIT:
            if self.is_con_full():
                return True
            self.sleep(self.HANDOFF_CON_POLL, check_combat=False)
        self.logger.info(f'con not full before switch (con={self.get_current_con()}), '
                         f'next char gets no intro')
        return False

    def char_at_slot(self, slot):
        """按队伍位置 (1-based) 取角色, 越界返回 None。"""
        index = slot - 1
        for char in self.task.chars:
            if char is not None and char.index == index:
                return char
        return None

    def attack_chain(self, count, interval, last_interval=None):
        """点按普攻打一轮连段。

        Args:
            last_interval: 最后一段之后的间隔。后面紧接切人时传更小的值 —— 按下切人键之后
                还要等游戏识别切换完成, 那段时间最后一下的动作照样在演, 两者是重叠的。
        """
        for i in range(count):
            self.click()
            if i == count - 1 and last_interval is not None:
                self.sleep(last_interval)
            else:
                self.sleep(interval)

    def hold_until(self, cond, timeout, name):
        """轮询某个条件, 期间不动手 —— 攻击键的按下/松开由调用方管。"""
        start = time.time()
        while self.time_elapsed_accounting_for_freeze(start) < timeout:
            if cond():
                self.logger.info(f'{name} ready after '
                                 f'{self.time_elapsed_accounting_for_freeze(start):.1f}s')
                return True
            self.sleep(self.HOLD_POLL)
        self.logger.info(f'timed out waiting for {name} ({timeout:.1f}s)')
        return False


    # ---------------------------------------------- "没打到就不许切人" 的硬 gate
    # 这套轴是靠变奏/延奏一棒接一棒串起来的: 任何一棒少做一步, 代价都直接传给下一棒。
    # 实测 21:23 那一圈就是完整的传染链:
    #   穗穗 forte3 没读到 -> 硬走 Q/R -> "liberation not ready, leaving without field"
    #   -> 领域没放, 千咲上场 -> "chisa: liberation not ready" -> 整圈裸打。
    # 所以关键步骤不再"到点就走", 改成留场重试到真打出来为止。
    #
    # 【没有超时是有意的】: 给上限就等于"打不出来也走", 那这个 gate 等于没有。
    # 唯一的出口是 check_combat() —— 脱战/任务被停时它抛异常, 整条轴一起退出。
    # 怪都没了的话, "这一步没打到"本来也就不是问题了。
    GATE_POLL: float = 0.12       # gate 轮询间隔 (秒)
    GATE_LOG_EVERY: float = 3.0   # 卡住时每隔这么久打一条日志, 好在日志里一眼看出卡在哪

    def require(self, name, cond, action=None, timeout=0):
        """留场直到 cond() 成立 —— 这一步没做到就不许往下走。

        Args:
            name: 打日志用的步骤名, 卡住时就是靠它定位。
            cond: 判据, 返回真就放行。
            action: 每轮做的事, 一般传 self.click。不传就是干等 (长按期间要用这个,
                手上已经按着了, 再 click 会打断长按)。
            timeout: >0 时的上限 (秒), 到点放行并返回 False。默认 0 = 不设上限。
                【什么时候该给上限】: 这一步做不到时"照走"能自愈的, 就必须给 ——
                比如协奏没满只是让下一棒退回启动轴(那条轴本来就为空手入场准备),
                而卡死在这里不能自愈。实测 01:18 那轮 fill_con 无上限直接把任务挂住了。

        Returns:
            bool: 条件成立返回 True; 到 timeout 放弃返回 False。
        """
        start = time.time()
        last_log = 0.0
        while True:
            if cond():
                waited = self.time_elapsed_accounting_for_freeze(start)
                if waited > 0.3:
                    self.logger.info(f'gate [{name}] ok after {waited:.1f}s')
                return True
            self.check_combat()
            if action is not None:
                action()
            elapsed = self.time_elapsed_accounting_for_freeze(start)
            if timeout > 0 and elapsed >= timeout:
                self.logger.warning(f'gate [{name}] gave up after {elapsed:.1f}s, moving on')
                return False
            if elapsed - last_log >= self.GATE_LOG_EVERY:
                last_log = elapsed
                self.logger.warning(f'gate [{name}] not satisfied after {elapsed:.1f}s, '
                                    f'staying on field')
            self.sleep(self.GATE_POLL)

    def require_cast(self, name, send, landed, pre=None, timeout=0):
        """反复按某个键直到它真的放出去了。

        跟 require() 的区别: 这里每轮都【重新发键】。被打断时按键会被游戏吃掉,
        补发是唯一的解法。
        Args:
            send: 发键的函数。
            landed: 判据 —— "已经放出去了"返回真。
            pre: 发键之前必须先成立的条件 (比如"图标亮了"), 不成立就先不发, 省得
                在冷却里空按。不传就是每轮都发。
            timeout: >0 时的上限 (秒), 到点放弃并返回 False。默认 0 = 不设上限。
        """
        start = time.time()
        last_log = 0.0
        while True:
            if landed():
                waited = self.time_elapsed_accounting_for_freeze(start)
                self.logger.info(f'gate [{name}] cast confirmed after {waited:.1f}s')
                return True
            self.check_combat()
            if pre is None or pre():
                send()
            elapsed = self.time_elapsed_accounting_for_freeze(start)
            if timeout > 0 and elapsed >= timeout:
                self.logger.warning(f'gate [{name}] gave up after {elapsed:.1f}s, moving on')
                return False
            if elapsed - last_log >= self.GATE_LOG_EVERY:
                last_log = elapsed
                self.logger.warning(f'gate [{name}] not cast after {elapsed:.1f}s, retrying')
            self.sleep(self.GATE_POLL)

    # ============================================================ 公共段结束

    # ================================================================ 绯洛穗那条轴

    NEXT_SLOT = 2  # 打完切千咲

    MISTY_WINDOW = 15.0       # 濯雨时总时长, 用墙钟(游戏侧计时, 不受动画冻结影响)
    LIB_CAST_RESERVE = 3.0    # 窗口末尾预留给"放大招 + 切人"

    OPEN_E_WAIT_TIMEOUT = 10.0
    OPEN_POLL = 0.1
    # 醒春潮之后隔多久按落地E。醒春潮把她顶上天, E 只在上升/滞空有效, 进入下落就没反应。
    # 标定: 3.0/3.1 已在下落段完全不出; 2.0/2.2/2.4 能出但偏早。窗口夹在 2.4~3.0
    FIRST_BAR_TIME = 2.8
    # 循环轴按落地E的时机。【计时起点和启动轴不同】: 这里从她被切上场那一刻算起,
    # 中间没有醒春潮, 开头约 0.9 秒是变奏入场动画, 两个值没有可比性。
    # 标定: 3.1/2.9/2.7 已在下落段完全没反应; 2.6 能出但只比失败区低 0.1 秒。
    # 早了只是第一格没攒满(wait_forte3 兜得住), 晚了是整轮报废, 两边不对称, 往早的一侧靠
    FIRST_BAR_TIME_INTRO = 2.6
    # 用【头像认出切人完成那一刻】当循环轴的计时锚点, 而不是 do_perform 被调用那一刻
    SWITCH_ANCHOR_MAX = 1.5
    # 按E落地之后按住攻击键打地面连段的时间。
    # 【原轴里这段是"落地 -> 切主C"的间隔】, dps_touch 拿掉之后它就只剩连段的意义了
    E_LAND_TO_SWITCH = 0.95
    BACK_TO_R = 0.1           # 按完Q到开R; 保底闸(wait_forte3)排在这后面

    # ---- 循环轴 (loop_axis) ----
    # 【入场段回到绯洛穗原轴的做法: 按住不松】(2026-08-25)
    # 中间走过一段弯路, 记下来省得再试: 试过用框架的 heavy_attack(hold) 起手, 也就是
    #   mouse_down -> sleep(hold) -> mouse_up -> 等一会儿 -> 按E
    # 结果每轮重击伤害都被吞。两个原因叠在一起, 而且都是那个 mouse_up 带来的:
    #   1. 松手把重击截断了 —— 按住 1.5 加到 2.5 才确认是这个;
    #   2. 松手到按E 之间那段是【纯空转】(手松着又不点普攻), 所以 E 显得特别晚。
    #      这也是为什么把间隔从 0.8 加到 1.8 完全没用 —— 加的全是空转。
    # 原轴没有这两个问题: 手一次都不松, 重击自然打完, E 按下去的时候鼠标还按着。
    # 松手的时机推到"按完落地E、打完一段地面连段之后", 那之后才改成点按去攒回路。
    LOOP_E_TO_ATTACK = 0.3    # 按完落地E 到松手改点按的间隔 (秒), 这段还按着
    LOOP_TAP_INTERVAL = 0.22  # 松手之后点普攻的间隔 (秒)

    # ---- F 处决 (全队唯一一处, 只在循环轴的点按段) ----
    # 【f_break() 比看上去贵得多】, CombatCheck.f_break() 的真身是:
    #     while time.time() - start < 0.5 or (< 5 and 还能处决):
    #         send_key('f'); self.click()
    # 也就是【阻塞 0.5~5 秒 + 期间连打左键】。秧秧"F处决完就不动了"就是卡在这里面,
    # 不是卡死。处决动画本身的时长还因角色而异 (上游 Phoebe.py 注释写的是 2.4 秒)。
    # 所以两条铁律:
    #   1. 长按流程里绝对不能插 —— 那个 click() 会把按住的左键打断。启动轴
    #      (tap=False) 因此不放处决, 上游给赞妮/菲比重写 f_break 返回 False 同理;
    #   2. 别再用"扣掉冻结时间就不亏"论证 —— 阻塞和左键都不是冻结能抵消的。
    # 放在循环轴这段点按 A 里是目前最不吃亏的位置: 退出条件是【三格回路满】这个找图
    # 判定, FORTE3_WAIT 只是兜底, 正常走不到上限。
    # 【但仍然要花钱】: 濯雨时的 15 秒是墙钟 (misty_left 用 time.time()),
    # 阻塞那 0.5~5 秒是实打实从窗口里扣的 —— 日志里把剩余窗口一起打出来盯着
    F_BREAK_IN_FORTE_WAIT: bool = True
    F_BREAK_INTERVAL: float = 0.5   # 两次尝试之间的最小间隔 (秒)
    F_BREAK_MIN_DELAY: float = 0.5  # 进这段多久之后才开始找处决提示 (秒)
    POST_LIB_SETTLE = 0.15    # 大招动画刚结束时能量环没渲染回来, 立刻切人会把协奏读成0

    FORTE3_WAIT = 8.0         # 等三格满的上限, 超了照放不误
    FORTE3_THRESHOLD = 0.75   # 原来 0.6 太松会误判
    FORTE2_THRESHOLD = 0.75
    FORTE3_CONFIRM = 2        # 连读这么多帧都命中才认, 单帧误判不算
    MIN_MISTY_BEFORE_LIB = 3.0  # 刚进濯雨时物理上不可能满, 这时的命中一定是误判
    # 芳菲信见过之后连续这么多帧读不到, 就认定濯雨时已经关了。
    # 这条判据不依赖 misty_start 记得对不对, 是唯一能兜住"计时基准整个记错"的东西
    GAUGE_GONE_CONFIRM = 4
    # 启动轴里发现"其实已经在濯雨时"要连续命中几次。宁可晚半秒也不能误判 ——
    # 误判的代价是整轮不放醒春潮, 濯雨时压根没进
    GAUGE_CONFIRM = 2
    # 开场头这一段不信芳菲信: 变奏进场时它从 0 开始涨, 物理上到不了 400,
    # 这时的命中只可能是上一个角色的HUD残影
    MISTY_DETECT_MIN = 1.0

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.misty_start = -1  # 本次进入濯雨时的墙钟时间
        if self.ring_index < 0:
            # CharFactory 里穗穗没写 ring_index, 环色会被现场猜; 万一第一次判定发生在
            # 濯雨时特效糊住能量环时会锁死错值, 而离场判定完全依赖 is_con_full()
            self.ring_index = Elements.ICE

    def reset_state(self):
        super().reset_state()
        # v3.5.32 起必须在这里重申: apply_team_char_classes() 的 __dict__.update
        # 会把 ring_index 打回 CharFactory 给的 -1
        if self.ring_index < 0:
            self.ring_index = Elements.ICE
        self.misty_start = -1

    def on_combat_end(self, chars):
        self.reset_fixed_rotation()
        self.misty_start = -1
        super().on_combat_end(chars)

    # ------------------------------------------------------------------ 路由

    def do_perform(self):
        if self.flying():
            self.wait_down()

        if self.take_intro():
            # 变奏技能已经消耗水云息把她推进濯雨时了, 不用再攒
            self.enter_misty_state()
            return self.loop_axis()

        if self.in_misty():
            # 上一轮被中途切走但濯雨时还在走: 第一格早就满了, 人也已经在地上, 直接接后半段
            self.logger.info(f'suisui resuming misty, {self.misty_left():.1f}s left')
            return self.loop_axis(skip_entry=True)

        return self.hold_axis(opening=True)

    # ------------------------------------------------------------------ 轴

    def loop_axis(self, skip_entry=False):
        """循环轴: 按住 -> 按E落地 -> 松手 -> Q -> 点A到回路满 -> R -> 切千咲。

        分成两半, 用哪只手是分开的:
          入场段  按住不松 —— 重击靠一直按住才打得完整, 中途松手会把它截断;
          攒回路段 松手改点按 —— 这一段要的是普攻【段数】, 长按走重击反而攒得慢。
        松手的分界点就在"按完落地E、再走 LOOP_E_TO_ATTACK 秒"之后。

        Args:
            skip_entry: 人已经在地上、濯雨时也还在跑 (上一轮被中途切走) —— 跳过
                入场段, 直接接后半段。
        """
        self.logger.info(f'suisui loop axis: hold -> E(land) -> Q -> tap A -> R'
                         f'{" (resuming, entry skipped)" if skip_entry else ""}')
        self.check_f_on_switch = False
        anchor = self.switch_in_anchor()

        if not skip_entry:
            # 【按住不松】: 重击靠一直按住才打得完整, 中途 mouse_up 会把它截断。
            # 按E 的时刻用绝对锚点 —— FIRST_BAR_TIME_INTRO 是原轴标定的
            # "变奏入场 -> 该按E"间隔, 基准是切人完成那一刻, 不是这个函数被调用那一刻
            self.task.mouse_down()
            try:
                self.sleep(max(0.0, anchor + self.FIRST_BAR_TIME_INTRO - time.time()),
                           check_combat=False)
                self.send_resonance_key()  # 按E落地 —— 这时鼠标还按着
                self.sleep(self.LOOP_E_TO_ATTACK, check_combat=False)
            finally:
                # 到这里才松手: 后面攒回路要的是普攻段数, 点按比长按快
                self.task.mouse_up()

        self.send_echo_key()  # Q
        self.sleep(self.BACK_TO_R, check_combat=False)
        self.wait_forte3(tap=True)  # 一直点A, 打到三格回路满

        cast = self.cast_field()
        if cast:
            self.sleep(self.POST_LIB_SETTLE, check_combat=False)
        else:
            self.logger.warning('suisui: liberation not ready at R time, leaving without field')
        self.leave(assume_intro=cast)

    def hold_axis(self, opening=False, skip_first_bar=False):
        """启动轴。攻击键从头按到尾, 只在放R前松手。

        循环轴已经拆到 loop_axis() 了, 这里只剩 opening=True 一条路在用;
        opening=False 的分支留着备查 (绯洛穗原轴的循环形态)。
        """
        axis = 'opening' if opening else 'loop'
        self.logger.info(f'suisui {axis} axis: hold attack -> E(land) -> Q -> forte3 -> R')
        # F 处决不归她管 —— 这条轴里没有处决位, 别让框架在切人时替她按掉
        self.check_f_on_switch = False
        axis_start = time.time() if opening else self.switch_in_anchor()

        self.task.mouse_down()
        try:
            # 没放醒春潮就没上天, 那一下"按E落地"会变成把她重新顶上天
            airborne = True
            if opening:
                if self.hold_until_e_or_misty(self.OPEN_E_WAIT_TIMEOUT) == 'misty':
                    self.adopt_running_misty(axis_start)
                    airborne = False
                else:
                    # 【必须打到】启动轴的第一个强化E(醒春潮)。判据是"高亮被消耗掉" ——
                    # 不用 has_cd: 后面那一下落地E 还要再按一次同一个键, 说明它并不是
                    # 简单进冷却, has_cd 判不准 (秧秧那边用 has_cd 实测 7/7 全判错)
                    self.require_cast('醒春潮E',
                                      send=self.send_resonance_key,
                                      landed=lambda: not self.e_ready())
                    self.enter_misty_state()
                    self.sleep(self.FIRST_BAR_TIME, check_combat=False)
            elif not skip_first_bar:
                # 循环轴用绝对时刻: FIRST_BAR_TIME_INTRO 量的是"变奏入场 -> 该按E"的间隔,
                # 基准必须是上场那一刻
                self.sleep(max(0.0, axis_start + self.FIRST_BAR_TIME_INTRO - time.time()),
                           check_combat=False)

            if airborne:
                self.send_resonance_key()  # 按E落地
                # 落地之后按住攻击键打一段地面连段。
                # 【原轴这里是切主C(绯雪)打一下再切回来, 已按要求拿掉】
                self.sleep(self.E_LAND_TO_SWITCH, check_combat=False)

            self.send_echo_key()  # Q
            self.sleep(self.BACK_TO_R, check_combat=False)
            self.wait_forte3()    # 保底: 三格回路能量满才准放R
        finally:
            self.task.mouse_up()

        cast = self.cast_field()
        if cast:
            self.sleep(self.POST_LIB_SETTLE, check_combat=False)
        else:
            self.logger.warning('suisui: liberation not ready at R time, leaving without field')
        self.leave(assume_intro=cast)

    def leave(self, assume_intro=False):
        """离场: 按数字键直接切千咲, 绕开 switch_next_char() 内部那几下多余的普攻。

        Args:
            assume_intro: 直接认定协奏是满的。只有"刚放完R"那条路能这么认 ——
                那时协奏基本一定满, 而能量环读数滞后会把 has_intro 误判成 False。
        """
        if not self.direct_switch(assume_intro=assume_intro):
            self.switch_next_char()

    def wait_forte3(self, tap=False):
        """保底: 三格回路能量(芳菲信600)没满就接着打, 满了立刻停手。

        Args:
            tap: True = 每轮点一下普攻 (循环轴用, 手是松着的);
                 False = 只轮询不动手 (启动轴用, 攻击键已经按住了, 再 click 会打断长按)。

        【这里不能用无上限的 require()】: 芳菲信只在濯雨时存在, 窗口一关直接清零,
        等下去永远等不到。两道逃生闸:
          1. 芳菲信"见过又不见了" —— 窗口已经关了。这条不依赖 misty_start 记得对不对,
             是唯一能兜住"计时基准整个记错"的判据;
          2. 窗口只剩 LIB_CAST_RESERVE 秒 —— 再等就来不及放R和切人了。
        """
        start = time.time()
        gauge_seen = False
        gauge_gone = 0
        last_f = -1.0
        while self.time_elapsed_accounting_for_freeze(start) < self.FORTE3_WAIT:
            if self.forte3_available():
                self.logger.info(f'suisui forte3 full after '
                                 f'{self.time_elapsed_accounting_for_freeze(start):.1f}s')
                return True
            if self.gauge_present():
                gauge_seen = True
                gauge_gone = 0
            elif gauge_seen:
                gauge_gone += 1
                if gauge_gone >= self.GAUGE_GONE_CONFIRM:
                    self.logger.warning('suisui: forte gauge wiped, misty is already over '
                                        '(misty_start was wrong), casting R now')
                    return False
            left = self.misty_left()
            if 0 < self.misty_start and left <= self.LIB_CAST_RESERVE:
                self.logger.warning(f'suisui: misty closing ({left:.1f}s left) without forte3, '
                                    f'casting R now before the gauge wipes')
                return False
            # 处决: 全队只有这一处, 而且【只在点按那条路(循环轴)】。
            # 启动轴 tap=False 时鼠标是按住的, 而 f_break() 内部是
            #   while ...: send_key('f'); self.click()
            # 那个 click() 会把长按打断 —— 上游给赞妮/菲比重写 f_break 返回 False
            # 就是栽在"连打左键打断开场动作"上
            elapsed = self.time_elapsed_accounting_for_freeze(start)
            if (tap and self.F_BREAK_IN_FORTE_WAIT and elapsed >= self.F_BREAK_MIN_DELAY
                    and elapsed - last_f >= self.F_BREAK_INTERVAL):
                last_f = elapsed
                if self.f_break():
                    self.logger.info(f'suisui: f break at {elapsed:.2f}s '
                                     f'(misty {self.misty_left():.1f}s left)')

            if tap:
                self.click()
                self.sleep(self.LOOP_TAP_INTERVAL, check_combat=False)
            else:
                self.sleep(0.1, check_combat=False)
        self.logger.warning(f'suisui forte3 still not full after {self.FORTE3_WAIT:.1f}s, '
                            f'casting anyway')
        return False

    def cast_field(self):
        """共鸣解放「山河水境」: 30秒领域, 效应上限+3。"""
        if not self.liberation_available():
            return False
        # click_f=False: 默认 True 的意思是"大招动画期间每 0.1 秒发一次F"。
        # 她的R动画 4.3 秒, 等于替全队按掉四十来次处决
        if self.click_liberation(wait_if_cd_ready=0.3, click_f=False):
            self.logger.info('suisui field deployed')
            return True
        return False

    # ------------------------------------------------------------------ 判定

    def hold_until_e_or_misty(self, timeout):
        """启动轴开头按住攻击键攒水云息, 等两件事里先发生的那个。按下/松开由调用方管。

        第二个条件: 空手开场时芳菲信不可能涨 —— 它只在濯雨时存在。所以"等E的过程中
        芳菲信涨起来了"只有一个解释: 这次进场其实是带变奏的, 只是记账没传过来。
        框架的 switch_healer() -> switch_other_char() 就是这么一条路: 它只改
        is_current_char, 既不设 has_intro 也不走 handoff_to()。

        Returns:
            'e'      E亮了 —— 正常的空手开场, 接着放醒春潮
            'misty'  已经在濯雨时里了, 醒春潮不能按
            ''       两个都没等到, 按超时处理(照原样放醒春潮)
        """
        start = time.time()
        gauge_hits = 0
        while True:
            elapsed = self.time_elapsed_accounting_for_freeze(start)
            if elapsed >= timeout:
                break
            if self.e_ready():
                self.logger.info(f'suisui opening: e ready after {elapsed:.1f}s')
                return 'e'
            if elapsed >= self.MISTY_DETECT_MIN and self.gauge_present():
                gauge_hits += 1
                if gauge_hits >= self.GAUGE_CONFIRM:
                    self.logger.warning(f'suisui opening: forte gauge filling at {elapsed:.1f}s '
                                        f'-> already in misty, the intro handoff was lost')
                    return 'misty'
            else:
                gauge_hits = 0
            self.sleep(self.OPEN_POLL)
        self.logger.info(f'suisui opening: timed out waiting for e ({timeout:.1f}s)')
        return ''

    def e_ready(self):
        """E亮了没有 —— 两个信号取先亮的那个。e_forte 是框架通用的"E充满"标记,
        suisui_e1 是她自己那张E技能格图标。取"或"只可能更早不可能更晚。"""
        return bool(self.is_e_forte_full()) or bool(self.task.find_one(Labels.suisui_e1))

    def gauge_present(self):
        """芳菲信到没到 400 档。两张图取或: 400 和 600 在图上是两个状态,
        只查 forte2 会在满 600 的那几秒读成"没有"。"""
        return bool(self.task.find_one(Labels.suisui_forte2, threshold=self.FORTE2_THRESHOLD)) \
            or bool(self.task.find_one(Labels.suisui_forte3, threshold=self.FORTE3_THRESHOLD))

    def forte3_available(self):
        """芳菲信是否满600。两道保险防误判导致提前开R:
          1. 连读 FORTE3_CONFIRM 帧都命中才认 —— 【这几帧是连着读完的, 中间不做别的】,
             靠外层循环去凑命中次数会白白多等一轮;
          2. 刚进濯雨时不足 MIN_MISTY_BEFORE_LIB 秒直接判否(物理上不可能满)。
        """
        if 0 < self.misty_start and (time.time() - self.misty_start) < self.MIN_MISTY_BEFORE_LIB:
            return False
        for i in range(self.FORTE3_CONFIRM):
            if not self.task.find_one(Labels.suisui_forte3, threshold=self.FORTE3_THRESHOLD):
                return False
            if i + 1 < self.FORTE3_CONFIRM:
                self.task.next_frame()  # 换一帧再读, 否则两次读的是同一张图
        return True

    # ------------------------------------------------------------------ 濯雨时记账

    def adopt_running_misty(self, started_at):
        """认领一段已经在跑的濯雨时(带变奏进来但记账丢了的那种)。

        起点只能取"上场那一刻"这个近似 —— 真正的起点是变奏技能生效那一瞬, 拿不到。
        宁可估早不估晚: 估早了最多提前去放R, 估晚了会一路等到芳菲信被清零, 整轮报废。
        """
        self.misty_start = started_at
        self.logger.info(f'suisui: adopting the misty already running, '
                         f'{self.misty_left():.1f}s left counting from switch-in')

    def enter_misty_state(self):
        self.misty_start = time.time()

    def in_misty(self):
        return self.misty_start > 0 and self.misty_left() > self.LIB_CAST_RESERVE

    def misty_left(self):
        """濯雨时还剩多少秒。用墙钟: 这是游戏侧的15秒, 不能扣动画冻结时间。"""
        if self.misty_start <= 0:
            return -1
        return self.MISTY_WINDOW - (time.time() - self.misty_start)

    def switch_out(self, con_full=False):
        if con_full or self.current_con == 1:
            self.misty_start = -1  # 延奏会退出濯雨时
        super().switch_out(con_full=con_full)

    # ------------------------------------------------------------------ 小工具

    def switch_in_anchor(self):
        """循环轴的计时基准: 头像认出"切人完成"的那一刻 (handoff_to 写的
        last_switch_in_time), 而不是 do_perform 被调用那一刻 —— 两者之间隔着框架的
        交接记账、上个角色的返回、任务循环再调到穗穗, 这段延迟是变长的。
        """
        now = time.time()
        anchored = self.last_switch_in_time
        gap = now - anchored if anchored > 0 else -1
        if 0 <= gap <= self.SWITCH_ANCHOR_MAX:
            self.logger.info(f'suisui: anchored on switch-in, {gap:.2f}s ago')
            return anchored
        self.logger.info(f'suisui: switch-in timestamp unusable (gap {gap:.2f}s), using now')
        return now
