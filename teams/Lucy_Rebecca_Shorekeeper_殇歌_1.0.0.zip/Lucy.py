import time
from src.char.BaseChar import BaseChar, SwitchPriority

class Lucy(BaseChar):
    FORTE_TIMEOUT = 8.5
    LIB_CD_WAIT = 1.5
    ATTACK_DURATION = 1.2
    NORMAL_ATTACK_DURATION = 0.1
    HEAVY_ATTACK_DURATION = 0.6
    CLICK_INTERVAL = 0.1
    HEAVY_INTERVAL = 0.3          # 每次重击间隔改为 0.3s
    PRE_LIB_WAIT = 0.3            # 开大前等待改为 0.3s
    LIB_CLICK_COUNT = 11
    LIB_CHARGE_TIMEOUT = 18.0
    HEAVY_COUNT = 3               # 强化重击次数 3

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.outrotime = -1
        self.dodge_count = 0

    def auto_dodge(self, condition):
        clicked = False
        if self.time_elapsed_accounting_for_freeze(self.outrotime) < 30 and self.dodge_count > 0:
            start = time.time()
            while time.time() - start < 1.5:
                if not condition():
                    break
                self.continues_right_click(0.05)
                self.sleep(0.05)
                clicked = True
                self.task.next_frame()
        if clicked:
            self.dodge_count -= 1
            self.logger.info('Lucy auto dodge success!')
        return clicked

    def do_perform(self):
        # 1. 按E
        if self.resonance_available():
            self.click_resonance()
            time.sleep(0.3)

        # 2. 按Q
        if self.echo_available():
            self.logger.info("Lucy using Echo (Q)")
            self.click_echo(time_out=0.5)
            time.sleep(0.3)

        # 3. 普攻攒鼠标能量，直到强化重击高亮
        while not self.is_mouse_forte_full():
            self.auto_dodge(lambda: self.is_staggered() if hasattr(self, 'is_staggered') else False)
            self.continues_normal_attack(self.NORMAL_ATTACK_DURATION)
            if self.resonance_available():
                self.click_resonance()
            time.sleep(0.1)

        # 4. 执行 3 次强化重击，每次间隔 0.3s
        self.perform_enhanced_heavy()

        # 5. 开大前等待 0.3s
        time.sleep(self.PRE_LIB_WAIT)

        # 6. 攒大招能量（若未满）
        if not self.liberation_available():
            self.logger.info("Lucy liberation not ready, charging...")
            start_time = time.time()
            while not self.liberation_available():
                self.auto_dodge(lambda: self.is_staggered() if hasattr(self, 'is_staggered') else False)
                if time.time() - start_time > self.LIB_CHARGE_TIMEOUT:
                    self.logger.warning("Lucy failed to charge liberation within timeout, skip.")
                    break
                self.continues_normal_attack(self.NORMAL_ATTACK_DURATION)
                if self.resonance_available():
                    self.click_resonance()
                time.sleep(0.1)

        # 7. 开大
        if self.liberation_available():
            self.click_liberation(send_click=True, wait_if_cd_ready=self.LIB_CD_WAIT)
            self.record_liberation_use()
            self.logger.info('Lucy perform lib: Started')
            for _ in range(self.LIB_CLICK_COUNT):
                self.click()
                self.sleep(self.CLICK_INTERVAL, check_combat=False)
            self.logger.info('Lucy perform lib: Ended')
        else:
            self.logger.warning("Lucy liberation still unavailable, skipping lib.")

        return self.switch_next_char()

    def perform_enhanced_heavy(self):
        """执行 3 次强化重击，每次间隔 0.3s"""
        if self.is_mouse_forte_full():
            for i in range(self.HEAVY_COUNT):
                self.heavy_attack(self.HEAVY_ATTACK_DURATION)
                self.logger.info(f'Lucy perform enhanced heavy attack {i+1}')
                if i < self.HEAVY_COUNT - 1:
                    self.sleep(self.HEAVY_INTERVAL, check_combat=False)

    # 以下辅助方法保留不变（不再被调用）
    def perform_standard(self):
        if self.is_forte_full():
            self.logger.info("Lucy forte is already full, skip standard build-up.")
            return False
        start_time = time.time()
        while not self.is_forte_full():
            if time.time() - start_time > self.FORTE_TIMEOUT:
                self.logger.warning("Lucy failed to fill forte, timeout reached.")
                break
            if self.resonance_available():
                self.click_resonance()
            self.heavy_attack(self.HEAVY_ATTACK_DURATION)
            if self.resonance_available():
                self.click_resonance()
        self.continues_normal_attack(self.NORMAL_ATTACK_DURATION)
        return True

    def perform_combat(self):
        if not self.is_forte_full():
            self.logger.info("Lucy forte not full, skip combat.")
            return False
        self.f_break()
        if self.echo_available():
            self.click_echo(time_out=0)
        self.perform_enhanced_heavy()
        self.continues_normal_attack(self.NORMAL_ATTACK_DURATION)
        return True

    def perform_liberation(self):
        if self.resonance_available():
            self.click_resonance()
        if self.echo_available():
            self.click_echo(time_out=0)
        self.f_break()
        self.perform_enhanced_heavy()
        if self.liberation_available():
            self.click_liberation(send_click=True, wait_if_cd_ready=self.LIB_CD_WAIT)
            self.record_liberation_use()
            self.logger.info('Lucy perform lib: Started')
            for _ in range(self.LIB_CLICK_COUNT):
                self.click()
                self.sleep(self.CLICK_INTERVAL, check_combat=False)
            self.logger.info('Lucy perform lib: Ended')
        self.logger.debug("Liberation not available, skipping.")
        return True

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        if has_intro and current_char and current_char.char_name in {'char_rebecca'}:
            return SwitchPriority.MUST
        return super().get_switch_priority(current_char, has_intro, target_low_con)
